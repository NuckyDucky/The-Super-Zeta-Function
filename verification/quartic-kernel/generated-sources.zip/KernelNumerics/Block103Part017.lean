import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_7_band6 : bandStats 16133543 16144227 3674 242 = (-12, 121249, -505) := by decide +kernel
theorem a103_0_7_band7 : bandStats 16133543 16144227 3916 98 = (-44, -354380, -510) := by decide +kernel
theorem a103_0_7_band8 : bandStats 16133543 16144227 4014 3 = (12, 81582, -83) := by decide +kernel
theorem a103_0_8_band0 : bandStats 16144227 16154608 0 770 = (-48, -203901, -521) := by decide +kernel

end QuarticKernel.KernelPrefixes
