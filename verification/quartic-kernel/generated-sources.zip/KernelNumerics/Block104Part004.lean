import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_1_band7 : bandStats 16236649 16247920 3855 148 = (17, 156366, -486) := by decide +kernel
theorem a104_0_1_band8 : bandStats 16236649 16247920 4003 27 = (51, 147185, -279) := by decide +kernel
theorem a104_0_2_band0 : bandStats 16247920 16259233 0 711 = (-9, -261175, -503) := by decide +kernel
theorem a104_0_2_band1 : bandStats 16247920 16259233 711 698 = (-55, -342491, -525) := by decide +kernel

end QuarticKernel.KernelPrefixes
