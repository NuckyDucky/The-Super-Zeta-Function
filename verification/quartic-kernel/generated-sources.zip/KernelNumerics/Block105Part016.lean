import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_7_band1 : bandStats 16472744 16483897 742 725 = (60, 314401, -471) := by decide +kernel
theorem a105_0_7_band2 : bandStats 16472744 16483897 1467 666 = (-18, 33586, -508) := by decide +kernel
theorem a105_0_7_band3 : bandStats 16472744 16483897 2133 597 = (15, 14199, -487) := by decide +kernel
theorem a105_0_7_band4 : bandStats 16472744 16483897 2730 502 = (-23, 103272, -510) := by decide +kernel

end QuarticKernel.KernelPrefixes
