import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_7_band5 : bandStats 16302916 16313785 3272 388 = (-18, -63302, -507) := by decide +kernel
theorem a104_0_7_band6 : bandStats 16302916 16313785 3660 254 = (41, 252022, -476) := by decide +kernel
theorem a104_0_7_band7 : bandStats 16302916 16313785 3914 116 = (53, 330327, -467) := by decide +kernel
theorem a104_0_7_band8 : bandStats 16302916 16313785 4030 9 = (-3, 6924, -165) := by decide +kernel

end QuarticKernel.KernelPrefixes
