import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_13_band1 : bandStats 17293801 17306313 678 658 = (39, 341521, -479) := by decide +kernel
theorem a109_0_13_band2 : bandStats 17293801 17306313 1336 615 = (14, -32321, -492) := by decide +kernel
theorem a109_0_13_band3 : bandStats 17293801 17306313 1951 564 = (-42, -222945, -520) := by decide +kernel
theorem a109_0_13_band4 : bandStats 17293801 17306313 2515 502 = (-19, 7764, -512) := by decide +kernel

end QuarticKernel.KernelPrefixes
