import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_3_band6 : bandStats 16812961 16824831 3529 309 = (-8, -186682, -499) := by decide +kernel
theorem a107_0_3_band7 : bandStats 16812961 16824831 3838 191 = (25, 88252, -484) := by decide +kernel
theorem a107_0_3_band8 : bandStats 16812961 16824831 4029 71 = (46, 114058, -477) := by decide +kernel
theorem a107_0_3_band9 : bandStats 16812961 16824831 4100 1 = (5, 25486, -37) := by decide +kernel

end QuarticKernel.KernelPrefixes
