import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_11_band1 : bandStats 16517464 16528585 744 709 = (32, 218567, -484) := by decide +kernel
theorem a105_0_11_band2 : bandStats 16517464 16528585 1453 672 = (15, 118814, -490) := by decide +kernel
theorem a105_0_11_band3 : bandStats 16517464 16528585 2125 595 = (24, 114389, -491) := by decide +kernel
theorem a105_0_11_band4 : bandStats 16517464 16528585 2720 505 = (-35, -176784, -517) := by decide +kernel

end QuarticKernel.KernelPrefixes
