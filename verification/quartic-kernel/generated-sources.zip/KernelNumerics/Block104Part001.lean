import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_0_band4 : bandStats 16225300 16236649 2656 501 = (-17, -65010, -508) := by decide +kernel
theorem a104_0_0_band5 : bandStats 16225300 16236649 3157 399 = (-2, 76754, -498) := by decide +kernel
theorem a104_0_0_band6 : bandStats 16225300 16236649 3556 278 = (9, 33965, -493) := by decide +kernel
theorem a104_0_0_band7 : bandStats 16225300 16236649 3834 159 = (-13, -19540, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
