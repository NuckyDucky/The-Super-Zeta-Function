import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_11_band6 : bandStats 16909172 16921377 3477 316 = (93, 655473, -447) := by decide +kernel
theorem a107_0_11_band7 : bandStats 16909172 16921377 3793 212 = (-1, -118996, -497) := by decide +kernel
theorem a107_0_11_band8 : bandStats 16909172 16921377 4005 99 = (27, 162645, -479) := by decide +kernel
theorem a107_0_11_band9 : bandStats 16909172 16921377 4104 9 = (-29, -171102, -204) := by decide +kernel

end QuarticKernel.KernelPrefixes
