import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_4_band0 : bandStats 15665545 15676449 0 725 = (20, 106197, -488) := by decide +kernel
theorem a100_0_4_band1 : bandStats 15665545 15676449 725 716 = (19, 105739, -487) := by decide +kernel
theorem a100_0_4_band2 : bandStats 15665545 15676449 1441 665 = (-38, -151263, -516) := by decide +kernel
theorem a100_0_4_band3 : bandStats 15665545 15676449 2106 588 = (18, 183852, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
