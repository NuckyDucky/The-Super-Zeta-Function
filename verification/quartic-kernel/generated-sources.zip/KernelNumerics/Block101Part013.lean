import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_5_band7 : bandStats 15783064 15793543 3893 79 = (30, 284745, -445) := by decide +kernel
theorem a101_0_5_band8 : bandStats 15783064 15793543 3972 2 = (-3, -43554, -62) := by decide +kernel
theorem a101_0_6_band0 : bandStats 15793543 15804148 0 759 = (-4, -266131, -498) := by decide +kernel
theorem a101_0_6_band1 : bandStats 15793543 15804148 759 732 = (-16, -253117, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
