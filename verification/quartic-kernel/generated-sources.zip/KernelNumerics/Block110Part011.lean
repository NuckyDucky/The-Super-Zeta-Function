import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_4_band4 : bandStats 17358249 17371240 2469 494 = (-21, -183924, -514) := by decide +kernel
theorem a110_0_4_band5 : bandStats 17358249 17371240 2963 421 = (-18, -244084, -507) := by decide +kernel
theorem a110_0_4_band6 : bandStats 17358249 17371240 3384 338 = (34, 262035, -481) := by decide +kernel
theorem a110_0_4_band7 : bandStats 17358249 17371240 3722 250 = (-13, -142794, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
