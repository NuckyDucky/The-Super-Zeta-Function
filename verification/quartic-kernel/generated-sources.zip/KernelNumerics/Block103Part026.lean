import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_11_band6 : bandStats 16176184 16186753 3674 246 = (-6, -188404, -502) := by decide +kernel
theorem a103_0_11_band7 : bandStats 16176184 16186753 3920 99 = (37, 280626, -462) := by decide +kernel
theorem a103_0_11_band8 : bandStats 16176184 16186753 4019 4 = (-19, -105042, -124) := by decide +kernel
theorem a103_0_12_band0 : bandStats 16186753 16197641 0 761 = (1, -252007, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
