import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_0_band4 : bandStats 15621799 15632657 2714 489 = (51, 256281, -474) := by decide +kernel
theorem a100_0_0_band5 : bandStats 15621799 15632657 3203 377 = (-36, -326475, -515) := by decide +kernel
theorem a100_0_0_band6 : bandStats 15621799 15632657 3580 250 = (-15, -130894, -506) := by decide +kernel
theorem a100_0_0_band7 : bandStats 15621799 15632657 3830 115 = (21, 188905, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
