import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_5_band2 : bandStats 17191708 17204380 1324 622 = (9, 11362, -493) := by decide +kernel
theorem a109_0_5_band3 : bandStats 17191708 17204380 1946 564 = (44, 333022, -476) := by decide +kernel
theorem a109_0_5_band4 : bandStats 17191708 17204380 2510 504 = (39, 239580, -483) := by decide +kernel
theorem a109_0_5_band5 : bandStats 17191708 17204380 3014 420 = (2, -153137, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
