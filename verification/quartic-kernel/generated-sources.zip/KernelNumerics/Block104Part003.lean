import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_1_band3 : bandStats 16236649 16247920 2102 585 = (-1, 231740, -500) := by decide +kernel
theorem a104_0_1_band4 : bandStats 16236649 16247920 2687 497 = (-20, -132067, -508) := by decide +kernel
theorem a104_0_1_band5 : bandStats 16236649 16247920 3184 394 = (27, 52513, -485) := by decide +kernel
theorem a104_0_1_band6 : bandStats 16236649 16247920 3578 277 = (38, 203680, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
