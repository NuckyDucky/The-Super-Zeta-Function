import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_15_band1 : bandStats 16562465 16565089 2924 1146 = (3, -7238, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
