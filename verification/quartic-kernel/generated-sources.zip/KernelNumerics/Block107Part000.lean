import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_0_band0 : bandStats 16777216 16788905 0 692 = (28, 233234, -481) := by decide +kernel
theorem a107_0_0_band1 : bandStats 16777216 16788905 692 693 = (36, 122601, -482) := by decide +kernel
theorem a107_0_0_band2 : bandStats 16777216 16788905 1385 640 = (-18, -77269, -506) := by decide +kernel
theorem a107_0_0_band3 : bandStats 16777216 16788905 2025 588 = (1, 161842, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
