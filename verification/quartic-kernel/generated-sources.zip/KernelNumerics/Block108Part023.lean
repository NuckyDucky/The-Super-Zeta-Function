import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_9_band2 : bandStats 17064568 17077139 1312 617 = (0, -220961, -500) := by decide +kernel
theorem a108_0_9_band3 : bandStats 17064568 17077139 1929 569 = (44, 347576, -474) := by decide +kernel
theorem a108_0_9_band4 : bandStats 17064568 17077139 2498 490 = (3, -1538, -497) := by decide +kernel
theorem a108_0_9_band5 : bandStats 17064568 17077139 2988 422 = (1, 25270, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
