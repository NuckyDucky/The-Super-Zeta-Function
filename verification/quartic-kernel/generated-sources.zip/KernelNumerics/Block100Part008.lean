import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_3_band5 : bandStats 15654595 15665545 3183 381 = (9, -155624, -495) := by decide +kernel
theorem a100_0_3_band6 : bandStats 15654595 15665545 3564 255 = (48, 160685, -470) := by decide +kernel
theorem a100_0_3_band7 : bandStats 15654595 15665545 3819 125 = (-9, 60443, -492) := by decide +kernel
theorem a100_0_3_band8 : bandStats 15654595 15665545 3944 13 = (3, 141069, -203) := by decide +kernel

end QuarticKernel.KernelPrefixes
