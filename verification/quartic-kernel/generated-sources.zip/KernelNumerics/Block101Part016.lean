import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_7_band1 : bandStats 15804148 15814849 767 732 = (-15, -96576, -510) := by decide +kernel
theorem a101_0_7_band2 : bandStats 15804148 15814849 1499 674 = (-15, -164711, -506) := by decide +kernel
theorem a101_0_7_band3 : bandStats 15804148 15814849 2173 598 = (34, 130517, -476) := by decide +kernel
theorem a101_0_7_band4 : bandStats 15804148 15814849 2771 500 = (10, 136399, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
