import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_1_band2 : bandStats 17681689 17693964 1367 645 = (61, 360999, -467) := by decide +kernel
theorem a112_0_1_band3 : bandStats 17681689 17693964 2012 582 = (-20, -118394, -509) := by decide +kernel
theorem a112_0_1_band4 : bandStats 17681689 17693964 2594 512 = (-26, -17503, -515) := by decide +kernel
theorem a112_0_1_band5 : bandStats 17681689 17693964 3106 426 = (-3, -60023, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
