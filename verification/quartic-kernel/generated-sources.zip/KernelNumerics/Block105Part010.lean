import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_4_band4 : bandStats 16439305 16450449 2734 496 = (25, 305272, -486) := by decide +kernel
theorem a105_0_4_band5 : bandStats 16439305 16450449 3230 392 = (2, -68154, -497) := by decide +kernel
theorem a105_0_4_band6 : bandStats 16439305 16450449 3622 275 = (46, 391553, -473) := by decide +kernel
theorem a105_0_4_band7 : bandStats 16439305 16450449 3897 139 = (29, 180160, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
