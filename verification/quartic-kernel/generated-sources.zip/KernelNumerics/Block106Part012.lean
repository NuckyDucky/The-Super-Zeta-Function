import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_5_band3 : bandStats 16621161 16632849 2038 585 = (-16, -124708, -511) := by decide +kernel
theorem a106_0_5_band4 : bandStats 16621161 16632849 2623 507 = (32, 322686, -483) := by decide +kernel
theorem a106_0_5_band5 : bandStats 16621161 16632849 3130 407 = (-54, -268444, -527) := by decide +kernel
theorem a106_0_5_band6 : bandStats 16621161 16632849 3537 299 = (67, 460717, -464) := by decide +kernel

end QuarticKernel.KernelPrefixes
