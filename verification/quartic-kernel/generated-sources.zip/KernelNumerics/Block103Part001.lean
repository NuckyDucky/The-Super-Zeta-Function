import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_0_band4 : bandStats 16058028 16068483 2845 493 = (61, 402468, -467) := by decide +kernel
theorem a103_0_0_band5 : bandStats 16058028 16068483 3338 369 = (-16, -88433, -509) := by decide +kernel
theorem a103_0_0_band6 : bandStats 16058028 16068483 3707 225 = (6, 5368, -495) := by decide +kernel
theorem a103_0_0_band7 : bandStats 16058028 16068483 3932 76 = (59, 209058, -457) := by decide +kernel

end QuarticKernel.KernelPrefixes
