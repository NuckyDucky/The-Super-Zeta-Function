import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_6_band2 : bandStats 15687521 15698545 1426 660 = (3, -110451, -496) := by decide +kernel
theorem a100_0_6_band3 : bandStats 15687521 15698545 2086 587 = (-29, 33992, -516) := by decide +kernel
theorem a100_0_6_band4 : bandStats 15687521 15698545 2673 495 = (8, -241555, -494) := by decide +kernel
theorem a100_0_6_band5 : bandStats 15687521 15698545 3168 385 = (33, 254457, -480) := by decide +kernel

end QuarticKernel.KernelPrefixes
