import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_8_band0 : bandStats 15709524 15720712 0 734 = (21, 203299, -487) := by decide +kernel
theorem a100_0_8_band1 : bandStats 15709524 15720712 734 690 = (-67, -383036, -533) := by decide +kernel
theorem a100_0_8_band2 : bandStats 15709524 15720712 1424 649 = (-8, 117153, -503) := by decide +kernel
theorem a100_0_8_band3 : bandStats 15709524 15720712 2073 580 = (29, 65253, -473) := by decide +kernel

end QuarticKernel.KernelPrefixes
