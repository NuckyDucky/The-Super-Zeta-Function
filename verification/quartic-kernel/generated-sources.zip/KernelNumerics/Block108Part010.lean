import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_4_band0 : bandStats 17000872 17013348 0 683 = (-9, -28046, -502) := by decide +kernel
theorem a108_0_4_band1 : bandStats 17000872 17013348 683 654 = (10, -133223, -491) := by decide +kernel
theorem a108_0_4_band2 : bandStats 17000872 17013348 1337 615 = (-11, -379775, -506) := by decide +kernel
theorem a108_0_4_band3 : bandStats 17000872 17013348 1952 571 = (22, -29458, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
