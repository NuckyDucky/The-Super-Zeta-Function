import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_13_band2 : bandStats 16712356 16723764 1429 656 = (12, 123819, -493) := by decide +kernel
theorem a106_0_13_band3 : bandStats 16712356 16723764 2085 594 = (-25, -308310, -514) := by decide +kernel
theorem a106_0_13_band4 : bandStats 16712356 16723764 2679 506 = (-34, -112596, -516) := by decide +kernel
theorem a106_0_13_band5 : bandStats 16712356 16723764 3185 407 = (36, 154110, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
