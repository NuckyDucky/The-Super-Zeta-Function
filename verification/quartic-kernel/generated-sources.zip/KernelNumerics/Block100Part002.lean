import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_0_band8 : bandStats 15621799 15632657 3945 8 = (28, 173516, -144) := by decide +kernel
theorem a100_0_1_band0 : bandStats 15632657 15643584 0 730 = (11, 106622, -493) := by decide +kernel
theorem a100_0_1_band1 : bandStats 15632657 15643584 730 705 = (-15, -169584, -503) := by decide +kernel
theorem a100_0_1_band2 : bandStats 15632657 15643584 1435 653 = (-3, -63708, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
