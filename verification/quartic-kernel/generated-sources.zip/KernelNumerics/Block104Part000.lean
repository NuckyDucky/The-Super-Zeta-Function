import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_0_band0 : bandStats 16225300 16236649 0 719 = (-38, -215333, -517) := by decide +kernel
theorem a104_0_0_band1 : bandStats 16225300 16236649 719 700 = (12, 179898, -493) := by decide +kernel
theorem a104_0_0_band2 : bandStats 16225300 16236649 1419 648 = (-52, -242665, -525) := by decide +kernel
theorem a104_0_0_band3 : bandStats 16225300 16236649 2067 589 = (-14, -32635, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
