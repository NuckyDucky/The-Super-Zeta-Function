import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_7_band5 : bandStats 15966616 15977127 3297 376 = (-18, -110305, -510) := by decide +kernel
theorem a102_0_7_band6 : bandStats 15966616 15977127 3673 234 = (-88, -455811, -542) := by decide +kernel
theorem a102_0_7_band7 : bandStats 15966616 15977127 3907 88 = (-40, -172556, -507) := by decide +kernel
theorem a102_0_7_band8 : bandStats 15966616 15977127 3995 2 = (-6, -34115, -66) := by decide +kernel

end QuarticKernel.KernelPrefixes
