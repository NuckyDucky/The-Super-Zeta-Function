import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_7_band2 : bandStats 17217044 17229732 1325 614 = (-31, -398188, -515) := by decide +kernel
theorem a109_0_7_band3 : bandStats 17217044 17229732 1939 561 = (-9, 58728, -504) := by decide +kernel
theorem a109_0_7_band4 : bandStats 17217044 17229732 2500 492 = (17, 82787, -481) := by decide +kernel
theorem a109_0_7_band5 : bandStats 17217044 17229732 2992 421 = (30, 363046, -483) := by decide +kernel

end QuarticKernel.KernelPrefixes
