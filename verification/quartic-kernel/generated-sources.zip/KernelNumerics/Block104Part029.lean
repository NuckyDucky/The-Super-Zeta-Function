import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_12_band8 : bandStats 16357993 16369161 4022 23 = (6, 72613, -277) := by decide +kernel
theorem a104_0_13_band0 : bandStats 16369161 16380404 0 717 = (-4, 48252, -502) := by decide +kernel
theorem a104_0_13_band1 : bandStats 16369161 16380404 717 715 = (20, 197385, -487) := by decide +kernel
theorem a104_0_13_band2 : bandStats 16369161 16380404 1432 663 = (-20, 23130, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
