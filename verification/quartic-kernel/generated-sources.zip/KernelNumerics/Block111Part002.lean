import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_0_band8 : bandStats 17487268 17499832 4027 129 = (9, 139573, -494) := by decide +kernel
theorem a111_0_0_band9 : bandStats 17487268 17499832 4156 27 = (21, 261277, -343) := by decide +kernel
theorem a111_0_1_band0 : bandStats 17499832 17512524 0 685 = (-36, -265167, -516) := by decide +kernel
theorem a111_0_1_band1 : bandStats 17499832 17512524 685 649 = (-9, 82001, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
