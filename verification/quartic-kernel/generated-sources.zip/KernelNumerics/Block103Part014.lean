import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_6_band3 : bandStats 16122599 16133543 2144 593 = (-17, -145297, -504) := by decide +kernel
theorem a103_0_6_band4 : bandStats 16122599 16133543 2737 499 = (-51, -419842, -521) := by decide +kernel
theorem a103_0_6_band5 : bandStats 16122599 16133543 3236 384 = (-60, -456270, -524) := by decide +kernel
theorem a103_0_6_band6 : bandStats 16122599 16133543 3620 260 = (-6, -64274, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
