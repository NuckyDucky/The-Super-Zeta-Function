import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_7_band1 : bandStats 15966616 15977127 766 738 = (-12, 5974, -506) := by decide +kernel
theorem a102_0_7_band2 : bandStats 15966616 15977127 1504 687 = (15, 72718, -489) := by decide +kernel
theorem a102_0_7_band3 : bandStats 15966616 15977127 2191 609 = (-7, -85441, -498) := by decide +kernel
theorem a102_0_7_band4 : bandStats 15966616 15977127 2800 497 = (-91, -486915, -542) := by decide +kernel

end QuarticKernel.KernelPrefixes
