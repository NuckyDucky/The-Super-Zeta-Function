import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_1_band6 : bandStats 17681689 17693964 3532 330 = (18, 214364, -491) := by decide +kernel
theorem a112_0_1_band7 : bandStats 17681689 17693964 3862 223 = (-13, -33811, -503) := by decide +kernel
theorem a112_0_1_band8 : bandStats 17681689 17693964 4085 109 = (22, 173914, -486) := by decide +kernel
theorem a112_0_1_band9 : bandStats 17681689 17693964 4194 12 = (-24, -182633, -242) := by decide +kernel

end QuarticKernel.KernelPrefixes
