import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_10_band3 : bandStats 17255744 17268625 1898 561 = (18, 214909, -490) := by decide +kernel
theorem a109_0_10_band4 : bandStats 17255744 17268625 2459 501 = (-36, 25317, -523) := by decide +kernel
theorem a109_0_10_band5 : bandStats 17255744 17268625 2960 422 = (-12, -43595, -504) := by decide +kernel
theorem a109_0_10_band6 : bandStats 17255744 17268625 3382 339 = (-9, 50668, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
