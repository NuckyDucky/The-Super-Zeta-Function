import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_1_band7 : bandStats 16576312 16587505 3899 148 = (16, -110428, -488) := by decide +kernel
theorem a106_0_1_band8 : bandStats 16576312 16587505 4047 25 = (5, 39525, -293) := by decide +kernel
theorem a106_0_2_band0 : bandStats 16587505 16598631 0 739 = (15, 139497, -491) := by decide +kernel
theorem a106_0_2_band1 : bandStats 16587505 16598631 739 719 = (42, 206205, -477) := by decide +kernel

end QuarticKernel.KernelPrefixes
