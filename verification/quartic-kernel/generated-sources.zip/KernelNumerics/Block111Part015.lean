import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_6_band0 : bandStats 17563240 17575617 0 675 = (28, 400654, -484) := by decide +kernel
theorem a111_0_6_band1 : bandStats 17563240 17575617 675 669 = (24, 13427, -487) := by decide +kernel
theorem a111_0_6_band2 : bandStats 17563240 17575617 1344 632 = (-1, 30787, -499) := by decide +kernel
theorem a111_0_6_band3 : bandStats 17563240 17575617 1976 586 = (3, -15208, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
