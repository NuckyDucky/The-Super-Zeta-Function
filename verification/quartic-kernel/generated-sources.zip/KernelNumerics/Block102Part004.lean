import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_1_band7 : bandStats 15902992 15913464 3906 81 = (18, 103710, -447) := by decide +kernel
theorem a102_0_1_band8 : bandStats 15902992 15913464 3987 2 = (6, 38475, -62) := by decide +kernel
theorem a102_0_2_band0 : bandStats 15913464 15924100 0 761 = (-21, -97997, -511) := by decide +kernel
theorem a102_0_2_band1 : bandStats 15913464 15924100 761 730 = (-68, -485622, -532) := by decide +kernel

end QuarticKernel.KernelPrefixes
