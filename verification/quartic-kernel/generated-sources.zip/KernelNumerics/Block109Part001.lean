import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_0_band4 : bandStats 17128563 17141056 2520 492 = (23, -70538, -489) := by decide +kernel
theorem a109_0_0_band5 : bandStats 17128563 17141056 3012 423 = (-2, -23697, -498) := by decide +kernel
theorem a109_0_0_band6 : bandStats 17128563 17141056 3435 332 = (-28, -171447, -513) := by decide +kernel
theorem a109_0_0_band7 : bandStats 17128563 17141056 3767 228 = (1, -124870, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
