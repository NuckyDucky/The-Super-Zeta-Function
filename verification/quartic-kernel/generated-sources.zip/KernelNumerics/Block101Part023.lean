import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_10_band2 : bandStats 15836300 15847153 1474 667 = (-1, 42860, -497) := by decide +kernel
theorem a101_0_10_band3 : bandStats 15836300 15847153 2141 592 = (-23, -77433, -513) := by decide +kernel
theorem a101_0_10_band4 : bandStats 15836300 15847153 2733 493 = (17, 73907, -489) := by decide +kernel
theorem a101_0_10_band5 : bandStats 15836300 15847153 3226 379 = (-2, 176352, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
