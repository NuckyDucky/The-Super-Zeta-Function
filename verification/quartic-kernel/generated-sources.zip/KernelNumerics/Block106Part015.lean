import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_6_band6 : bandStats 16632849 16644624 3533 299 = (-27, -126446, -511) := by decide +kernel
theorem a106_0_6_band7 : bandStats 16632849 16644624 3832 183 = (-22, -165635, -510) := by decide +kernel
theorem a106_0_6_band8 : bandStats 16632849 16644624 4015 63 = (6, 27938, -458) := by decide +kernel
theorem a106_0_6_band9 : bandStats 16632849 16644624 4078 1 = (-4, -61207, -41) := by decide +kernel

end QuarticKernel.KernelPrefixes
