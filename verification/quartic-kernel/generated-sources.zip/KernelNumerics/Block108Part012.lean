import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_4_band8 : bandStats 17000872 17013348 3987 118 = (25, -121644, -485) := by decide +kernel
theorem a108_0_4_band9 : bandStats 17000872 17013348 4105 19 = (8, 64640, -280) := by decide +kernel
theorem a108_0_5_band0 : bandStats 17013348 17025936 0 663 = (56, 325242, -469) := by decide +kernel
theorem a108_0_5_band1 : bandStats 17013348 17025936 663 654 = (13, -9927, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
