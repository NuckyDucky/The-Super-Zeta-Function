import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_4_band0 : bandStats 16270272 16281249 0 762 = (28, 61438, -485) := by decide +kernel
theorem a104_0_4_band1 : bandStats 16270272 16281249 762 728 = (-51, -376374, -523) := by decide +kernel
theorem a104_0_4_band2 : bandStats 16270272 16281249 1490 666 = (21, 253122, -487) := by decide +kernel
theorem a104_0_4_band3 : bandStats 16270272 16281249 2156 597 = (-15, 5592, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
