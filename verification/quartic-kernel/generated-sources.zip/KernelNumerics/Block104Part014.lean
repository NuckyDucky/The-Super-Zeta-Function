import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_6_band2 : bandStats 16292008 16302916 1488 674 = (11, 166008, -495) := by decide +kernel
theorem a104_0_6_band3 : bandStats 16292008 16302916 2162 598 = (-16, -123761, -506) := by decide +kernel
theorem a104_0_6_band4 : bandStats 16292008 16302916 2760 502 = (12, 115709, -494) := by decide +kernel
theorem a104_0_6_band5 : bandStats 16292008 16302916 3262 385 = (27, 183954, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
