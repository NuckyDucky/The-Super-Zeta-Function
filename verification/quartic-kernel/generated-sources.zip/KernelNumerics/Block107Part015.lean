import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_6_band0 : bandStats 16848744 16860752 0 688 = (6, 82987, -495) := by decide +kernel
theorem a107_0_6_band1 : bandStats 16848744 16860752 688 678 = (-24, -341035, -514) := by decide +kernel
theorem a107_0_6_band2 : bandStats 16848744 16860752 1366 640 = (-35, -136083, -518) := by decide +kernel
theorem a107_0_6_band3 : bandStats 16848744 16860752 2006 579 = (-22, -137749, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
