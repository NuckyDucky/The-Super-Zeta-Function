import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_2_band0 : bandStats 17512524 17525139 0 665 = (6, -280734, -495) := by decide +kernel
theorem a111_0_2_band1 : bandStats 17512524 17525139 665 661 = (36, 141813, -484) := by decide +kernel
theorem a111_0_2_band2 : bandStats 17512524 17525139 1326 632 = (-14, -143384, -504) := by decide +kernel
theorem a111_0_2_band3 : bandStats 17512524 17525139 1958 572 = (-2, -38337, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
