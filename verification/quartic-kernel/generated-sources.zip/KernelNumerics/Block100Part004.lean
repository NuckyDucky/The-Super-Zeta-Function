import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_1_band7 : bandStats 15632657 15643584 3814 127 = (25, 86858, -479) := by decide +kernel
theorem a100_0_1_band8 : bandStats 15632657 15643584 3941 14 = (20, 89384, -211) := by decide +kernel
theorem a100_0_2_band0 : bandStats 15643584 15654595 0 734 = (69, 468022, -464) := by decide +kernel
theorem a100_0_2_band1 : bandStats 15643584 15654595 734 713 = (-18, -106378, -510) := by decide +kernel

end QuarticKernel.KernelPrefixes
