import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_4_band8 : bandStats 15772464 15783064 3970 2 = (-6, -84194, -71) := by decide +kernel
theorem a101_0_5_band0 : bandStats 15783064 15793543 0 764 = (8, -61313, -495) := by decide +kernel
theorem a101_0_5_band1 : bandStats 15783064 15793543 764 746 = (28, -12464, -487) := by decide +kernel
theorem a101_0_5_band2 : bandStats 15783064 15793543 1510 686 = (-19, -73540, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
