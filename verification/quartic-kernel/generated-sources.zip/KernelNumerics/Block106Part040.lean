import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_2_band4 : bandStats 16760115 16771524 2684 509 = (38, 322380, -479) := by decide +kernel
theorem a106_1_2_band5 : bandStats 16760115 16771524 3193 407 = (3, -37403, -496) := by decide +kernel
theorem a106_1_2_band6 : bandStats 16760115 16771524 3600 291 = (40, 74406, -477) := by decide +kernel
theorem a106_1_2_band7 : bandStats 16760115 16771524 3891 164 = (-13, 11811, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
