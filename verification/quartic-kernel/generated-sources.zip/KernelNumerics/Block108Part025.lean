import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_10_band0 : bandStats 17077139 17089955 0 675 = (-16, -39710, -505) := by decide +kernel
theorem a108_0_10_band1 : bandStats 17077139 17089955 675 642 = (-57, -488880, -527) := by decide +kernel
theorem a108_0_10_band2 : bandStats 17077139 17089955 1317 611 = (14, 97331, -490) := by decide +kernel
theorem a108_0_10_band3 : bandStats 17077139 17089955 1928 558 = (-7, -331599, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
