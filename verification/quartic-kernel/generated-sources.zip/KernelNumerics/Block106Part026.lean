import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_11_band4 : bandStats 16689817 16700993 2724 508 = (-14, -38278, -504) := by decide +kernel
theorem a106_0_11_band5 : bandStats 16689817 16700993 3232 401 = (52, 373170, -472) := by decide +kernel
theorem a106_0_11_band6 : bandStats 16689817 16700993 3633 276 = (41, 307592, -475) := by decide +kernel
theorem a106_0_11_band7 : bandStats 16689817 16700993 3909 150 = (-63, -467548, -527) := by decide +kernel

end QuarticKernel.KernelPrefixes
