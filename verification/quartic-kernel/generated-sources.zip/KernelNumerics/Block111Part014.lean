import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_5_band6 : bandStats 17550601 17563240 3463 333 = (-6, -74552, -499) := by decide +kernel
theorem a111_0_5_band7 : bandStats 17550601 17563240 3796 235 = (-30, -109484, -508) := by decide +kernel
theorem a111_0_5_band8 : bandStats 17550601 17563240 4031 131 = (-32, 90212, -508) := by decide +kernel
theorem a111_0_5_band9 : bandStats 17550601 17563240 4162 28 = (-20, -155518, -353) := by decide +kernel

end QuarticKernel.KernelPrefixes
