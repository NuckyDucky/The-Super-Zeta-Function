import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_8_band8 : bandStats 17409844 17422924 3963 155 = (20, -128854, -485) := by decide +kernel
theorem a110_0_8_band9 : bandStats 17409844 17422924 4118 54 = (7, 40221, -457) := by decide +kernel
theorem a110_0_8_band10 : bandStats 17409844 17422924 4172 2 = (7, 42091, -56) := by decide +kernel
theorem a110_0_9_band0 : bandStats 17422924 17436003 0 652 = (-49, -595242, -524) := by decide +kernel

end QuarticKernel.KernelPrefixes
