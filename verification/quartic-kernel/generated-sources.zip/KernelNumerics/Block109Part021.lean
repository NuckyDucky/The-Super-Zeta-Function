import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_8_band4 : bandStats 17229732 17242627 2462 500 = (66, 466067, -465) := by decide +kernel
theorem a109_0_8_band5 : bandStats 17229732 17242627 2962 422 = (-25, -315774, -511) := by decide +kernel
theorem a109_0_8_band6 : bandStats 17229732 17242627 3384 337 = (46, 375007, -471) := by decide +kernel
theorem a109_0_8_band7 : bandStats 17229732 17242627 3721 245 = (-44, -352967, -519) := by decide +kernel

end QuarticKernel.KernelPrefixes
