import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_0_band0 : bandStats 17128563 17141056 0 668 = (-1, -123644, -500) := by decide +kernel
theorem a109_0_0_band1 : bandStats 17128563 17141056 668 656 = (9, 197050, -495) := by decide +kernel
theorem a109_0_0_band2 : bandStats 17128563 17141056 1324 626 = (-6, -177994, -499) := by decide +kernel
theorem a109_0_0_band3 : bandStats 17128563 17141056 1950 570 = (-45, -455087, -521) := by decide +kernel

end QuarticKernel.KernelPrefixes
