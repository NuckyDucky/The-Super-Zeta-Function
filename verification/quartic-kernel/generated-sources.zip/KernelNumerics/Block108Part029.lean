import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_11_band6 : bandStats 17089955 17102424 3423 331 = (69, 534039, -463) := by decide +kernel
theorem a108_0_11_band7 : bandStats 17089955 17102424 3754 232 = (1, -26150, -496) := by decide +kernel
theorem a108_0_11_band8 : bandStats 17089955 17102424 3986 125 = (-36, -275671, -514) := by decide +kernel
theorem a108_0_11_band9 : bandStats 17089955 17102424 4111 24 = (-24, -46266, -346) := by decide +kernel

end QuarticKernel.KernelPrefixes
