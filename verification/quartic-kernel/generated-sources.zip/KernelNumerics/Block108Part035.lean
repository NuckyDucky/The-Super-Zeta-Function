import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_14_band0 : bandStats 17127811 17128563 0 4138 = (-56, -13244, -314) := by decide +kernel

end QuarticKernel.KernelPrefixes
