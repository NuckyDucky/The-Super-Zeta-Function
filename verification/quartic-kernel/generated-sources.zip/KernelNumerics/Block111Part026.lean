import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_10_band4 : bandStats 17613139 17625544 2571 508 = (27, 280415, -487) := by decide +kernel
theorem a111_0_10_band5 : bandStats 17613139 17625544 3079 425 = (40, 269505, -476) := by decide +kernel
theorem a111_0_10_band6 : bandStats 17613139 17625544 3504 335 = (35, 268056, -480) := by decide +kernel
theorem a111_0_10_band7 : bandStats 17613139 17625544 3839 226 = (18, -84000, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
