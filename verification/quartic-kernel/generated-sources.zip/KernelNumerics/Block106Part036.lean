import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_0_band6 : bandStats 16737643 16748999 3615 286 = (-14, -197138, -503) := by decide +kernel
theorem a106_1_0_band7 : bandStats 16737643 16748999 3901 158 = (-44, -182737, -522) := by decide +kernel
theorem a106_1_0_band8 : bandStats 16737643 16748999 4059 33 = (2, 95530, -349) := by decide +kernel
theorem a106_1_1_band0 : bandStats 16748999 16760115 0 761 = (28, 185770, -483) := by decide +kernel

end QuarticKernel.KernelPrefixes
