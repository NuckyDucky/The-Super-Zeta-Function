import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_13_band6 : bandStats 16933903 16946248 3460 323 = (-14, -241405, -505) := by decide +kernel
theorem a107_0_13_band7 : bandStats 16933903 16946248 3783 214 = (-32, -232517, -514) := by decide +kernel
theorem a107_0_13_band8 : bandStats 16933903 16946248 3997 106 = (18, 26942, -477) := by decide +kernel
theorem a107_0_13_band9 : bandStats 16933903 16946248 4103 13 = (0, 101789, -232) := by decide +kernel

end QuarticKernel.KernelPrefixes
