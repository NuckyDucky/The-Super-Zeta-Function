import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_12_band3 : bandStats 16700993 16712356 2101 596 = (23, 41317, -487) := by decide +kernel
theorem a106_0_12_band4 : bandStats 16700993 16712356 2697 507 = (-44, -268733, -520) := by decide +kernel
theorem a106_0_12_band5 : bandStats 16700993 16712356 3204 401 = (45, 133984, -477) := by decide +kernel
theorem a106_0_12_band6 : bandStats 16700993 16712356 3605 287 = (27, 197392, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
