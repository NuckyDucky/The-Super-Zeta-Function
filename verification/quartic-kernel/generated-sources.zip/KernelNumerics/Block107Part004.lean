import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_1_band6 : bandStats 16788905 16800999 3497 309 = (-7, -82042, -500) := by decide +kernel
theorem a107_0_1_band7 : bandStats 16788905 16800999 3806 202 = (-33, -316781, -515) := by decide +kernel
theorem a107_0_1_band8 : bandStats 16788905 16800999 4008 86 = (5, -194919, -485) := by decide +kernel
theorem a107_0_1_band9 : bandStats 16788905 16800999 4094 4 = (-16, -97064, -122) := by decide +kernel

end QuarticKernel.KernelPrefixes
