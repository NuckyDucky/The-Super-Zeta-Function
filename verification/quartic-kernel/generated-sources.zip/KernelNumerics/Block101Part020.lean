import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_8_band8 : bandStats 15814849 15825464 3975 3 = (-3, 41907, -88) := by decide +kernel
theorem a101_0_9_band0 : bandStats 15825464 15836300 0 745 = (4, -29527, -496) := by decide +kernel
theorem a101_0_9_band1 : bandStats 15825464 15836300 745 718 = (-19, 94657, -508) := by decide +kernel
theorem a101_0_9_band2 : bandStats 15825464 15836300 1463 667 = (-19, -55582, -507) := by decide +kernel

end QuarticKernel.KernelPrefixes
