import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_4_band8 : bandStats 16609849 16621161 4042 34 = (71, 485221, -310) := by decide +kernel
theorem a106_0_5_band0 : bandStats 16621161 16632849 0 696 = (-41, -280584, -520) := by decide +kernel
theorem a106_0_5_band1 : bandStats 16621161 16632849 696 696 = (30, 19478, -483) := by decide +kernel
theorem a106_0_5_band2 : bandStats 16621161 16632849 1392 646 = (1, 8088, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
