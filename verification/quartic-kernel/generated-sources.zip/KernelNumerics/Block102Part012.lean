import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_5_band3 : bandStats 15945249 15955864 2180 599 = (-16, -130947, -508) := by decide +kernel
theorem a102_0_5_band4 : bandStats 15945249 15955864 2779 502 = (13, -6907, -493) := by decide +kernel
theorem a102_0_5_band5 : bandStats 15945249 15955864 3281 373 = (-73, -369794, -538) := by decide +kernel
theorem a102_0_5_band6 : bandStats 15945249 15955864 3654 242 = (28, 169829, -486) := by decide +kernel

end QuarticKernel.KernelPrefixes
