import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_5_band7 : bandStats 16281249 16292008 3913 115 = (-18, -262251, -500) := by decide +kernel
theorem a104_0_5_band8 : bandStats 16281249 16292008 4028 8 = (1, 6098, -167) := by decide +kernel
theorem a104_0_6_band0 : bandStats 16292008 16302916 0 760 = (-17, -293587, -507) := by decide +kernel
theorem a104_0_6_band1 : bandStats 16292008 16302916 760 728 = (15, 128732, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
