import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_9_band6 : bandStats 16884841 16896999 3492 313 = (-2, -62813, -496) := by decide +kernel
theorem a107_0_9_band7 : bandStats 16884841 16896999 3805 207 = (15, 58834, -488) := by decide +kernel
theorem a107_0_9_band8 : bandStats 16884841 16896999 4012 92 = (28, 327686, -480) := by decide +kernel
theorem a107_0_9_band9 : bandStats 16884841 16896999 4104 6 = (5, 35835, -149) := by decide +kernel

end QuarticKernel.KernelPrefixes
