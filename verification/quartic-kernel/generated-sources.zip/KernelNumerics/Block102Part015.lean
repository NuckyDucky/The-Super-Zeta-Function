import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_6_band6 : bandStats 15955864 15966616 3643 244 = (-3, 98972, -500) := by decide +kernel
theorem a102_0_6_band7 : bandStats 15955864 15966616 3887 104 = (39, 386530, -477) := by decide +kernel
theorem a102_0_6_band8 : bandStats 15955864 15966616 3991 4 = (12, 60566, -100) := by decide +kernel
theorem a102_0_7_band0 : bandStats 15966616 15977127 0 766 = (-88, -535496, -543) := by decide +kernel

end QuarticKernel.KernelPrefixes
