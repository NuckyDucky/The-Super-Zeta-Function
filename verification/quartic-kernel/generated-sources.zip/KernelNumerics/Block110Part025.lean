import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_9_band9 : bandStats 17422924 17436003 4116 58 = (64, 411394, -459) := by decide +kernel
theorem a110_0_9_band10 : bandStats 17422924 17436003 4174 1 = (0, -10356, -36) := by decide +kernel
theorem a110_0_10_band0 : bandStats 17436003 17449008 0 648 = (57, 342949, -471) := by decide +kernel
theorem a110_0_10_band1 : bandStats 17436003 17449008 648 640 = (-2, -56195, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
