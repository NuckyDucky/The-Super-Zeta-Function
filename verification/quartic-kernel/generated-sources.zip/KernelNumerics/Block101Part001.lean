import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_0_band4 : bandStats 15728640 15739632 2671 495 = (-33, -320318, -514) := by decide +kernel
theorem a101_0_0_band5 : bandStats 15728640 15739632 3166 387 = (17, 137717, -489) := by decide +kernel
theorem a101_0_0_band6 : bandStats 15728640 15739632 3553 264 = (-44, -137591, -518) := by decide +kernel
theorem a101_0_0_band7 : bandStats 15728640 15739632 3817 133 = (-15, -380218, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
