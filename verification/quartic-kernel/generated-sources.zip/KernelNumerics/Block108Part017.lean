import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_6_band8 : bandStats 17025936 17038833 3944 141 = (-25, -320707, -504) := by decide +kernel
theorem a108_0_6_band9 : bandStats 17025936 17038833 4085 42 = (-3, -94048, -441) := by decide +kernel
theorem a108_0_7_band0 : bandStats 17038833 17051683 0 644 = (4, -3258, -497) := by decide +kernel
theorem a108_0_7_band1 : bandStats 17038833 17051683 644 644 = (-71, -532457, -535) := by decide +kernel

end QuarticKernel.KernelPrefixes
