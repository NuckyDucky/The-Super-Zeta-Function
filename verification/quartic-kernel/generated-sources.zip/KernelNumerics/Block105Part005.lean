import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_2_band2 : bandStats 16416841 16428113 1425 663 = (10, -188292, -494) := by decide +kernel
theorem a105_0_2_band3 : bandStats 16416841 16428113 2088 591 = (6, -87561, -500) := by decide +kernel
theorem a105_0_2_band4 : bandStats 16416841 16428113 2679 504 = (-24, -252575, -511) := by decide +kernel
theorem a105_0_2_band5 : bandStats 16416841 16428113 3183 401 = (3, -87132, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
