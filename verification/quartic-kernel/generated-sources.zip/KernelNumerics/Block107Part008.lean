import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_3_band2 : bandStats 16812961 16824831 1398 648 = (-7, 119322, -502) := by decide +kernel
theorem a107_0_3_band3 : bandStats 16812961 16824831 2046 574 = (-31, -162945, -516) := by decide +kernel
theorem a107_0_3_band4 : bandStats 16812961 16824831 2620 503 = (-37, -77722, -516) := by decide +kernel
theorem a107_0_3_band5 : bandStats 16812961 16824831 3123 406 = (7, -23220, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
