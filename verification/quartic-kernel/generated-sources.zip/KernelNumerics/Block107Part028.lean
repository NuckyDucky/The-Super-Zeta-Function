import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_11_band2 : bandStats 16909172 16921377 1352 626 = (32, 343190, -482) := by decide +kernel
theorem a107_0_11_band3 : bandStats 16909172 16921377 1978 577 = (15, 105282, -490) := by decide +kernel
theorem a107_0_11_band4 : bandStats 16909172 16921377 2555 504 = (60, 352597, -469) := by decide +kernel
theorem a107_0_11_band5 : bandStats 16909172 16921377 3059 418 = (26, 182444, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
