import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_5_band3 : bandStats 15676449 15687521 2094 582 = (15, -46997, -491) := by decide +kernel
theorem a100_0_5_band4 : bandStats 15676449 15687521 2676 490 = (-18, -205514, -506) := by decide +kernel
theorem a100_0_5_band5 : bandStats 15676449 15687521 3166 384 = (5, -80535, -497) := by decide +kernel
theorem a100_0_5_band6 : bandStats 15676449 15687521 3550 262 = (28, 114334, -483) := by decide +kernel

end QuarticKernel.KernelPrefixes
