import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_6_band2 : bandStats 16632849 16644624 1394 643 = (-6, 163847, -502) := by decide +kernel
theorem a106_0_6_band3 : bandStats 16632849 16644624 2037 584 = (-14, -8642, -496) := by decide +kernel
theorem a106_0_6_band4 : bandStats 16632849 16644624 2621 503 = (2, 25394, -499) := by decide +kernel
theorem a106_0_6_band5 : bandStats 16632849 16644624 3124 409 = (-45, -292309, -522) := by decide +kernel

end QuarticKernel.KernelPrefixes
