import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_4_band8 : bandStats 17179180 17191708 3995 127 = (12, -7121, -493) := by decide +kernel
theorem a109_0_4_band9 : bandStats 17179180 17191708 4122 24 = (14, 253606, -322) := by decide +kernel
theorem a109_0_5_band0 : bandStats 17191708 17204380 0 677 = (-29, -298713, -512) := by decide +kernel
theorem a109_0_5_band1 : bandStats 17191708 17204380 677 647 = (46, 383341, -473) := by decide +kernel

end QuarticKernel.KernelPrefixes
