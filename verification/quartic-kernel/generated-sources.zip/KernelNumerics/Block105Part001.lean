import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_0_band4 : bandStats 16394314 16405384 2717 511 = (29, 64762, -484) := by decide +kernel
theorem a105_0_0_band5 : bandStats 16394314 16405384 3228 394 = (37, 165647, -478) := by decide +kernel
theorem a105_0_0_band6 : bandStats 16394314 16405384 3622 271 = (22, 173459, -484) := by decide +kernel
theorem a105_0_0_band7 : bandStats 16394314 16405384 3893 138 = (0, 25479, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
