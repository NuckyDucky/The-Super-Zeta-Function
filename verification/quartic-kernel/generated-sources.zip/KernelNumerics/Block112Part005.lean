import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_2_band0 : bandStats 17693964 17706316 0 704 = (4, -123892, -498) := by decide +kernel
theorem a112_0_2_band1 : bandStats 17693964 17706316 704 672 = (-37, -72545, -512) := by decide +kernel
theorem a112_0_2_band2 : bandStats 17693964 17706316 1376 632 = (29, 223670, -486) := by decide +kernel
theorem a112_0_2_band3 : bandStats 17693964 17706316 2008 585 = (-47, -322344, -519) := by decide +kernel

end QuarticKernel.KernelPrefixes
