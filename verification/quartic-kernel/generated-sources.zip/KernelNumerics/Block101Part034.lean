import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_15_band1 : bandStats 15890404 15892481 3330 656 = (-27, -26949, -313) := by decide +kernel

end QuarticKernel.KernelPrefixes
