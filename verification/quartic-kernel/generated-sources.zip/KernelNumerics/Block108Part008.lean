import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_3_band2 : bandStats 16988451 17000872 1323 626 = (-36, -114199, -517) := by decide +kernel
theorem a108_0_3_band3 : bandStats 16988451 17000872 1949 568 = (41, 265536, -480) := by decide +kernel
theorem a108_0_3_band4 : bandStats 16988451 17000872 2517 491 = (-1, -22044, -502) := by decide +kernel
theorem a108_0_3_band5 : bandStats 16988451 17000872 3008 420 = (-2, 193147, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
