import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_5_band3 : bandStats 15783064 15793543 2196 604 = (1, 123523, -501) := by decide +kernel
theorem a101_0_5_band4 : bandStats 15783064 15793543 2800 493 = (61, 213595, -469) := by decide +kernel
theorem a101_0_5_band5 : bandStats 15783064 15793543 3293 371 = (20, 87009, -490) := by decide +kernel
theorem a101_0_5_band6 : bandStats 15783064 15793543 3664 229 = (9, -13666, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
