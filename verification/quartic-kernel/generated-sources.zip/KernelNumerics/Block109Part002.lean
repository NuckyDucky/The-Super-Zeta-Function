import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_0_band8 : bandStats 17128563 17141056 3995 123 = (57, 432894, -470) := by decide +kernel
theorem a109_0_0_band9 : bandStats 17128563 17141056 4118 22 = (-5, -134919, -312) := by decide +kernel
theorem a109_0_1_band0 : bandStats 17141056 17153620 0 675 = (32, 235919, -483) := by decide +kernel
theorem a109_0_1_band1 : bandStats 17141056 17153620 675 655 = (30, 168392, -480) := by decide +kernel

end QuarticKernel.KernelPrefixes
