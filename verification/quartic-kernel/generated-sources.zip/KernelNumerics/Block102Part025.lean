import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_11_band4 : bandStats 16007539 16017769 2871 495 = (16, 308893, -491) := by decide +kernel
theorem a102_0_11_band5 : bandStats 16007539 16017769 3366 364 = (3, -79990, -496) := by decide +kernel
theorem a102_0_11_band6 : bandStats 16007539 16017769 3730 212 = (-10, -179945, -500) := by decide +kernel
theorem a102_0_11_band7 : bandStats 16007539 16017769 3942 60 = (-17, -113390, -454) := by decide +kernel

end QuarticKernel.KernelPrefixes
