import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_10_band7 : bandStats 17255744 17268625 3721 245 = (-19, -43000, -505) := by decide +kernel
theorem a109_0_10_band8 : bandStats 17255744 17268625 3966 145 = (-37, -244688, -512) := by decide +kernel
theorem a109_0_10_band9 : bandStats 17255744 17268625 4111 44 = (-31, -129658, -480) := by decide +kernel
theorem a109_0_11_band0 : bandStats 17268625 17281300 0 672 = (11, 3815, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
