import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_13_band0 : bandStats 16028136 16038361 0 804 = (-11, -174376, -504) := by decide +kernel
theorem a102_0_13_band1 : bandStats 16028136 16038361 804 760 = (69, 286550, -465) := by decide +kernel
theorem a102_0_13_band2 : bandStats 16028136 16038361 1564 707 = (-12, -6043, -504) := by decide +kernel
theorem a102_0_13_band3 : bandStats 16028136 16038361 2271 605 = (-15, -32631, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
