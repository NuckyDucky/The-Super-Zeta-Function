import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_2_band0 : bandStats 16760115 16771524 0 716 = (52, 205335, -475) := by decide +kernel
theorem a106_1_2_band1 : bandStats 16760115 16771524 716 705 = (40, 148215, -477) := by decide +kernel
theorem a106_1_2_band2 : bandStats 16760115 16771524 1421 669 = (6, 178383, -494) := by decide +kernel
theorem a106_1_2_band3 : bandStats 16760115 16771524 2090 594 = (46, 28998, -477) := by decide +kernel

end QuarticKernel.KernelPrefixes
