import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_1_band2 : bandStats 17141056 17153620 1330 619 = (45, 189020, -476) := by decide +kernel
theorem a109_0_1_band3 : bandStats 17141056 17153620 1949 568 = (21, 166098, -489) := by decide +kernel
theorem a109_0_1_band4 : bandStats 17141056 17153620 2517 497 = (-48, -321118, -526) := by decide +kernel
theorem a109_0_1_band5 : bandStats 17141056 17153620 3014 421 = (53, 214203, -471) := by decide +kernel

end QuarticKernel.KernelPrefixes
