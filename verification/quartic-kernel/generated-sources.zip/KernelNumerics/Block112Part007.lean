import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_2_band8 : bandStats 17693964 17706316 4082 111 = (-2, 180016, -492) := by decide +kernel
theorem a112_0_2_band9 : bandStats 17693964 17706316 4193 14 = (15, 110794, -227) := by decide +kernel
theorem a112_0_3_band0 : bandStats 17706316 17718416 0 696 = (-30, -124818, -513) := by decide +kernel
theorem a112_0_3_band1 : bandStats 17706316 17718416 696 687 = (23, 84849, -487) := by decide +kernel

end QuarticKernel.KernelPrefixes
