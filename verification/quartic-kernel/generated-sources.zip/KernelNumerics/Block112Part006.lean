import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_2_band4 : bandStats 17693964 17706316 2593 513 = (6, 40804, -488) := by decide +kernel
theorem a112_0_2_band5 : bandStats 17693964 17706316 3106 426 = (-49, -167939, -522) := by decide +kernel
theorem a112_0_2_band6 : bandStats 17693964 17706316 3532 327 = (-10, -2228, -500) := by decide +kernel
theorem a112_0_2_band7 : bandStats 17693964 17706316 3859 223 = (-62, -420419, -531) := by decide +kernel

end QuarticKernel.KernelPrefixes
