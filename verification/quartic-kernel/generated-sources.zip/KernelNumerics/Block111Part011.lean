import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_4_band4 : bandStats 17537860 17550601 2503 509 = (-73, -546429, -529) := by decide +kernel
theorem a111_0_4_band5 : bandStats 17537860 17550601 3012 427 = (3, 27715, -497) := by decide +kernel
theorem a111_0_4_band6 : bandStats 17537860 17550601 3439 341 = (-24, -9728, -513) := by decide +kernel
theorem a111_0_4_band7 : bandStats 17537860 17550601 3780 241 = (8, -199066, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
