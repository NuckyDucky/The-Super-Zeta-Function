import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_9_band2 : bandStats 16884841 16896999 1367 632 = (8, -79515, -494) := by decide +kernel
theorem a107_0_9_band3 : bandStats 16884841 16896999 1999 576 = (1, -17437, -501) := by decide +kernel
theorem a107_0_9_band4 : bandStats 16884841 16896999 2575 500 = (1, 28250, -500) := by decide +kernel
theorem a107_0_9_band5 : bandStats 16884841 16896999 3075 417 = (-6, -43900, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
