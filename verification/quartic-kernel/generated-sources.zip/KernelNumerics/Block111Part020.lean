import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_8_band0 : bandStats 17588209 17600724 0 670 = (1, 51102, -497) := by decide +kernel
theorem a111_0_8_band1 : bandStats 17588209 17600724 670 669 = (23, 212000, -490) := by decide +kernel
theorem a111_0_8_band2 : bandStats 17588209 17600724 1339 633 = (-18, -376128, -509) := by decide +kernel
theorem a111_0_8_band3 : bandStats 17588209 17600724 1972 576 = (-31, -174462, -515) := by decide +kernel

end QuarticKernel.KernelPrefixes
