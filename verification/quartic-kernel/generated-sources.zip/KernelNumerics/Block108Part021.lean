import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_8_band4 : bandStats 17051683 17064568 2461 494 = (-13, -127695, -498) := by decide +kernel
theorem a108_0_8_band5 : bandStats 17051683 17064568 2955 419 = (-5, -43847, -501) := by decide +kernel
theorem a108_0_8_band6 : bandStats 17051683 17064568 3374 335 = (-48, -110287, -523) := by decide +kernel
theorem a108_0_8_band7 : bandStats 17051683 17064568 3709 241 = (-16, -233457, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
