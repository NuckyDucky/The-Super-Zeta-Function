import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_8_band4 : bandStats 15814849 15825464 2767 497 = (38, 235827, -478) := by decide +kernel
theorem a101_0_8_band5 : bandStats 15814849 15825464 3264 374 = (31, 62584, -480) := by decide +kernel
theorem a101_0_8_band6 : bandStats 15814849 15825464 3638 241 = (11, 178719, -493) := by decide +kernel
theorem a101_0_8_band7 : bandStats 15814849 15825464 3879 96 = (26, 95579, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
