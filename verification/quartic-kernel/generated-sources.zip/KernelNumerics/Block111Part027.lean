import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_10_band8 : bandStats 17613139 17625544 4065 116 = (23, 5091, -477) := by decide +kernel
theorem a111_0_10_band9 : bandStats 17613139 17625544 4181 17 = (27, 170504, -259) := by decide +kernel
theorem a111_0_11_band0 : bandStats 17625544 17638201 0 685 = (-21, -205004, -509) := by decide +kernel
theorem a111_0_11_band1 : bandStats 17625544 17638201 685 660 = (-26, -250679, -511) := by decide +kernel

end QuarticKernel.KernelPrefixes
