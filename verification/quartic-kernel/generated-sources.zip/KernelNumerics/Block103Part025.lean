import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_11_band2 : bandStats 16176184 16186753 1498 687 = (31, 195660, -484) := by decide +kernel
theorem a103_0_11_band3 : bandStats 16176184 16186753 2185 607 = (5, 23586, -495) := by decide +kernel
theorem a103_0_11_band4 : bandStats 16176184 16186753 2792 500 = (37, 290516, -480) := by decide +kernel
theorem a103_0_11_band5 : bandStats 16176184 16186753 3292 382 = (40, 178556, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
