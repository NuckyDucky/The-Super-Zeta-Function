import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_0_band8 : bandStats 15728640 15739632 3950 17 = (-22, -251367, -263) := by decide +kernel
theorem a101_0_1_band0 : bandStats 15739632 15750561 0 744 = (-13, -36682, -502) := by decide +kernel
theorem a101_0_1_band1 : bandStats 15739632 15750561 744 709 = (9, -38544, -496) := by decide +kernel
theorem a101_0_1_band2 : bandStats 15739632 15750561 1453 664 = (-36, -151137, -516) := by decide +kernel

end QuarticKernel.KernelPrefixes
