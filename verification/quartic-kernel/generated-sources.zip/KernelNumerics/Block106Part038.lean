import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_1_band5 : bandStats 16748999 16760115 3259 396 = (43, 212793, -475) := by decide +kernel
theorem a106_1_1_band6 : bandStats 16748999 16760115 3655 273 = (37, 160947, -478) := by decide +kernel
theorem a106_1_1_band7 : bandStats 16748999 16760115 3928 144 = (47, 166614, -471) := by decide +kernel
theorem a106_1_1_band8 : bandStats 16748999 16760115 4072 21 = (36, 208364, -246) := by decide +kernel

end QuarticKernel.KernelPrefixes
