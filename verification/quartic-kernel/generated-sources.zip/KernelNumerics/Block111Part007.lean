import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_2_band8 : bandStats 17512524 17525139 4031 128 = (68, 592789, -461) := by decide +kernel
theorem a111_0_2_band9 : bandStats 17512524 17525139 4159 27 = (-20, -133498, -361) := by decide +kernel
theorem a111_0_3_band0 : bandStats 17525139 17537860 0 683 = (-10, -314893, -504) := by decide +kernel
theorem a111_0_3_band1 : bandStats 17525139 17537860 683 656 = (-2, 53017, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
