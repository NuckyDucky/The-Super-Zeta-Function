import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_2_band2 : bandStats 15913464 15924100 1491 680 = (-27, -246114, -512) := by decide +kernel
theorem a102_0_2_band3 : bandStats 15913464 15924100 2171 601 = (-8, -219916, -495) := by decide +kernel
theorem a102_0_2_band4 : bandStats 15913464 15924100 2772 496 = (19, 26157, -489) := by decide +kernel
theorem a102_0_2_band5 : bandStats 15913464 15924100 3268 379 = (-14, -62557, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
