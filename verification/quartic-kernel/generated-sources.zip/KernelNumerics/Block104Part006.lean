import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_2_band6 : bandStats 16247920 16259233 3558 282 = (-33, -163843, -514) := by decide +kernel
theorem a104_0_2_band7 : bandStats 16247920 16259233 3840 157 = (-13, -128446, -500) := by decide +kernel
theorem a104_0_2_band8 : bandStats 16247920 16259233 3997 35 = (14, 62265, -362) := by decide +kernel
theorem a104_0_3_band0 : bandStats 16259233 16270272 0 749 = (-37, -258314, -516) := by decide +kernel

end QuarticKernel.KernelPrefixes
