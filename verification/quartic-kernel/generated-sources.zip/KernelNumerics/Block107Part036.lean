import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_14_band4 : bandStats 16946248 16951979 4067 50 = (14, 16071, -213) := by decide +kernel

end QuarticKernel.KernelPrefixes
