import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_11_band0 : bandStats 16689817 16700993 0 749 = (5, -74133, -495) := by decide +kernel
theorem a106_0_11_band1 : bandStats 16689817 16700993 749 712 = (60, 378208, -468) := by decide +kernel
theorem a106_0_11_band2 : bandStats 16689817 16700993 1461 666 = (20, 209066, -488) := by decide +kernel
theorem a106_0_11_band3 : bandStats 16689817 16700993 2127 597 = (0, -103007, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
