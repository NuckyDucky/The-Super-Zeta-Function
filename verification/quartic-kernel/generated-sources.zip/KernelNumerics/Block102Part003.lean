import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_1_band3 : bandStats 15902992 15913464 2206 604 = (5, 141012, -498) := by decide +kernel
theorem a102_0_1_band4 : bandStats 15902992 15913464 2810 496 = (-20, -248889, -506) := by decide +kernel
theorem a102_0_1_band5 : bandStats 15902992 15913464 3306 369 = (35, 34819, -479) := by decide +kernel
theorem a102_0_1_band6 : bandStats 15902992 15913464 3675 231 = (31, 13010, -480) := by decide +kernel

end QuarticKernel.KernelPrefixes
