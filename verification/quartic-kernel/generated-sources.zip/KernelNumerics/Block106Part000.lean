import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_0_band0 : bandStats 16565089 16576312 0 726 = (15, 115585, -489) := by decide +kernel
theorem a106_0_0_band1 : bandStats 16565089 16576312 726 721 = (-35, -270171, -517) := by decide +kernel
theorem a106_0_0_band2 : bandStats 16565089 16576312 1447 671 = (54, 281371, -471) := by decide +kernel
theorem a106_0_0_band3 : bandStats 16565089 16576312 2118 593 = (-38, -130171, -520) := by decide +kernel

end QuarticKernel.KernelPrefixes
