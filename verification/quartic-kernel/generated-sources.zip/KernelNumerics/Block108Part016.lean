import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_6_band4 : bandStats 17025936 17038833 2453 498 = (28, 10885, -487) := by decide +kernel
theorem a108_0_6_band5 : bandStats 17025936 17038833 2951 417 = (16, 18739, -489) := by decide +kernel
theorem a108_0_6_band6 : bandStats 17025936 17038833 3368 333 = (-30, -270009, -513) := by decide +kernel
theorem a108_0_6_band7 : bandStats 17025936 17038833 3701 243 = (-8, -163397, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
