import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_10_band0 : bandStats 17613139 17625544 0 680 = (40, 432553, -479) := by decide +kernel
theorem a111_0_10_band1 : bandStats 17613139 17625544 680 673 = (-52, -181439, -524) := by decide +kernel
theorem a111_0_10_band2 : bandStats 17613139 17625544 1353 637 = (-26, -183640, -510) := by decide +kernel
theorem a111_0_10_band3 : bandStats 17613139 17625544 1990 581 = (-3, -6487, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
