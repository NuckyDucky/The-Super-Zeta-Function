import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_10_band8 : bandStats 17077139 17089955 3966 134 = (-4, -140317, -496) := by decide +kernel
theorem a108_0_10_band9 : bandStats 17077139 17089955 4100 33 = (32, 356310, -361) := by decide +kernel
theorem a108_0_11_band0 : bandStats 17089955 17102424 0 657 = (0, -26914, -499) := by decide +kernel
theorem a108_0_11_band1 : bandStats 17089955 17102424 657 655 = (48, 173936, -473) := by decide +kernel

end QuarticKernel.KernelPrefixes
