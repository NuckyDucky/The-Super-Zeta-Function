import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_10_band3 : bandStats 16165384 16176184 2191 595 = (-26, -148727, -502) := by decide +kernel
theorem a103_0_10_band4 : bandStats 16165384 16176184 2786 500 = (18, 185029, -490) := by decide +kernel
theorem a103_0_10_band5 : bandStats 16165384 16176184 3286 379 = (-25, -4602, -511) := by decide +kernel
theorem a103_0_10_band6 : bandStats 16165384 16176184 3665 248 = (-21, -192682, -507) := by decide +kernel

end QuarticKernel.KernelPrefixes
