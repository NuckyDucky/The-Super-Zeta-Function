import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_15_band0 : bandStats 16735292 16737643 0 3141 = (-11, -7435, -506) := by decide +kernel
theorem a106_0_15_band1 : bandStats 16735292 16737643 3141 950 = (-20, -39228, -413) := by decide +kernel
theorem a106_1_0_band0 : bandStats 16737643 16748999 0 735 = (-25, -217589, -511) := by decide +kernel
theorem a106_1_0_band1 : bandStats 16737643 16748999 735 713 = (5, 198047, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
