import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_7_band5 : bandStats 15804148 15814849 3271 371 = (55, 418883, -475) := by decide +kernel
theorem a101_0_7_band6 : bandStats 15804148 15814849 3642 237 = (-46, -152349, -519) := by decide +kernel
theorem a101_0_7_band7 : bandStats 15804148 15814849 3879 94 = (21, 50833, -464) := by decide +kernel
theorem a101_0_7_band8 : bandStats 15804148 15814849 3973 3 = (11, 51043, -83) := by decide +kernel

end QuarticKernel.KernelPrefixes
