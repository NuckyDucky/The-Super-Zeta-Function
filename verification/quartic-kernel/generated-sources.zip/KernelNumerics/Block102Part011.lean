import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_4_band8 : bandStats 15934641 15945249 3990 3 = (-1, 13404, -89) := by decide +kernel
theorem a102_0_5_band0 : bandStats 15945249 15955864 0 760 = (-16, -227477, -507) := by decide +kernel
theorem a102_0_5_band1 : bandStats 15945249 15955864 760 744 = (41, 105642, -482) := by decide +kernel
theorem a102_0_5_band2 : bandStats 15945249 15955864 1504 676 = (11, 61659, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
