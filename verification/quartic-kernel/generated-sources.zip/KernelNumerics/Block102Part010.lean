import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_4_band4 : bandStats 15934641 15945249 2781 501 = (15, 63672, -492) := by decide +kernel
theorem a102_0_4_band5 : bandStats 15934641 15945249 3282 375 = (-16, -182698, -504) := by decide +kernel
theorem a102_0_4_band6 : bandStats 15934641 15945249 3657 239 = (-30, 33449, -512) := by decide +kernel
theorem a102_0_4_band7 : bandStats 15934641 15945249 3896 94 = (13, -27823, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
