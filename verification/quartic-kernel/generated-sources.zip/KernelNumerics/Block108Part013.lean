import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_5_band2 : bandStats 17013348 17025936 1317 618 = (33, 248930, -482) := by decide +kernel
theorem a108_0_5_band3 : bandStats 17013348 17025936 1935 563 = (-20, -191013, -507) := by decide +kernel
theorem a108_0_5_band4 : bandStats 17013348 17025936 2498 500 = (51, 156980, -472) := by decide +kernel
theorem a108_0_5_band5 : bandStats 17013348 17025936 2998 420 = (34, 108889, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
