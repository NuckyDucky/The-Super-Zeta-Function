import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_3_band1 : bandStats 16428113 16439305 741 714 = (-74, -411157, -536) := by decide +kernel
theorem a105_0_3_band2 : bandStats 16428113 16439305 1455 658 = (8, 71516, -494) := by decide +kernel
theorem a105_0_3_band3 : bandStats 16428113 16439305 2113 597 = (-10, 37336, -494) := by decide +kernel
theorem a105_0_3_band4 : bandStats 16428113 16439305 2710 513 = (8, -97100, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
