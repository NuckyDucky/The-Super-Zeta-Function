import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_4_band4 : bandStats 17000872 17013348 2523 496 = (23, 147522, -481) := by decide +kernel
theorem a108_0_4_band5 : bandStats 17000872 17013348 3019 420 = (36, 335239, -480) := by decide +kernel
theorem a108_0_4_band6 : bandStats 17000872 17013348 3439 324 = (9, -84080, -492) := by decide +kernel
theorem a108_0_4_band7 : bandStats 17000872 17013348 3763 224 = (-14, -296392, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
