import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_12_band0 : bandStats 16528585 16539939 0 742 = (9, -61427, -495) := by decide +kernel
theorem a105_0_12_band1 : bandStats 16528585 16539939 742 706 = (-8, -138514, -499) := by decide +kernel
theorem a105_0_12_band2 : bandStats 16528585 16539939 1448 661 = (-19, 47464, -508) := by decide +kernel
theorem a105_0_12_band3 : bandStats 16528585 16539939 2109 590 = (3, 10405, -487) := by decide +kernel

end QuarticKernel.KernelPrefixes
