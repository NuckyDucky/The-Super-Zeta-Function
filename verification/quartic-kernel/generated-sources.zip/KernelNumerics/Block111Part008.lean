import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_3_band2 : bandStats 17525139 17537860 1339 608 = (7, 108287, -494) := by decide +kernel
theorem a111_0_3_band3 : bandStats 17525139 17537860 1947 567 = (15, 184348, -490) := by decide +kernel
theorem a111_0_3_band4 : bandStats 17525139 17537860 2514 506 = (6, 172134, -495) := by decide +kernel
theorem a111_0_3_band5 : bandStats 17525139 17537860 3020 425 = (17, 250350, -487) := by decide +kernel

end QuarticKernel.KernelPrefixes
