import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_13_band7 : bandStats 15868835 15879689 3860 116 = (-43, -181678, -515) := by decide +kernel
theorem a101_0_13_band8 : bandStats 15868835 15879689 3976 8 = (-30, -153946, -172) := by decide +kernel
theorem a101_0_14_band0 : bandStats 15879689 15890404 0 738 = (-11, -98130, -503) := by decide +kernel
theorem a101_0_14_band1 : bandStats 15879689 15890404 738 739 = (-12, 66067, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
