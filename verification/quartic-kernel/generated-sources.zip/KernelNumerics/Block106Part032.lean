import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_14_band1 : bandStats 16723764 16735292 736 699 = (42, 181823, -477) := by decide +kernel
theorem a106_0_14_band2 : bandStats 16723764 16735292 1435 656 = (21, 309307, -487) := by decide +kernel
theorem a106_0_14_band3 : bandStats 16723764 16735292 2091 588 = (-13, -23368, -510) := by decide +kernel
theorem a106_0_14_band4 : bandStats 16723764 16735292 2679 504 = (-48, -115214, -523) := by decide +kernel

end QuarticKernel.KernelPrefixes
