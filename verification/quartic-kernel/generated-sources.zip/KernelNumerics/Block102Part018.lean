import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_8_band0 : bandStats 15977127 15987228 0 803 = (28, 99914, -482) := by decide +kernel
theorem a102_0_8_band1 : bandStats 15977127 15987228 803 778 = (-28, -190279, -510) := by decide +kernel
theorem a102_0_8_band2 : bandStats 15977127 15987228 1581 700 = (2, 86679, -496) := by decide +kernel
theorem a102_0_8_band3 : bandStats 15977127 15987228 2281 607 = (-21, -34731, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
