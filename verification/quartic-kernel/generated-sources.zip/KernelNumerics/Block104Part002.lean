import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_0_band8 : bandStats 16225300 16236649 3993 36 = (1, 105631, -371) := by decide +kernel
theorem a104_0_1_band0 : bandStats 16236649 16247920 0 741 = (-12, -68966, -504) := by decide +kernel
theorem a104_0_1_band1 : bandStats 16236649 16247920 741 703 = (33, 237168, -482) := by decide +kernel
theorem a104_0_1_band2 : bandStats 16236649 16247920 1444 658 = (-14, -100842, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
