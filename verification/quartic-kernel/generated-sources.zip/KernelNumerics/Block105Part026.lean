import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_11_band5 : bandStats 16517464 16528585 3225 396 = (-25, -198182, -509) := by decide +kernel
theorem a105_0_11_band6 : bandStats 16517464 16528585 3621 276 = (26, 113094, -485) := by decide +kernel
theorem a105_0_11_band7 : bandStats 16517464 16528585 3897 144 = (24, 42817, -482) := by decide +kernel
theorem a105_0_11_band8 : bandStats 16517464 16528585 4041 24 = (22, 197434, -282) := by decide +kernel

end QuarticKernel.KernelPrefixes
