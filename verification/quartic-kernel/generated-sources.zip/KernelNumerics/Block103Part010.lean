import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_4_band5 : bandStats 16100284 16111484 3180 390 = (-9, -220215, -502) := by decide +kernel
theorem a103_0_4_band6 : bandStats 16100284 16111484 3570 273 = (-30, -41637, -514) := by decide +kernel
theorem a103_0_4_band7 : bandStats 16100284 16111484 3843 145 = (24, 66265, -484) := by decide +kernel
theorem a103_0_4_band8 : bandStats 16100284 16111484 3988 25 = (-25, -90680, -306) := by decide +kernel

end QuarticKernel.KernelPrefixes
