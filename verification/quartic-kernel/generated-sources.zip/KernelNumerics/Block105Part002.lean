import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_0_band8 : bandStats 16394314 16405384 4031 19 = (32, 113512, -252) := by decide +kernel
theorem a105_0_1_band0 : bandStats 16405384 16416841 0 731 = (7, 165577, -494) := by decide +kernel
theorem a105_0_1_band1 : bandStats 16405384 16416841 731 700 = (21, 86136, -491) := by decide +kernel
theorem a105_0_1_band2 : bandStats 16405384 16416841 1431 647 = (37, 114074, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
