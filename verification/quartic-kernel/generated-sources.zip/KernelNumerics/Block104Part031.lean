import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_13_band7 : bandStats 16369161 16380404 3870 150 = (1, 24907, -497) := by decide +kernel
theorem a104_0_13_band8 : bandStats 16369161 16380404 4020 27 = (-19, -59206, -332) := by decide +kernel
theorem a104_0_14_band0 : bandStats 16380404 16391553 0 746 = (-6, -294970, -502) := by decide +kernel
theorem a104_0_14_band1 : bandStats 16380404 16391553 746 718 = (-7, -15730, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
