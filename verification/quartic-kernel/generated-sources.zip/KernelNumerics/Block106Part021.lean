import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_9_band2 : bandStats 16667484 16678756 1466 661 = (-9, -102389, -503) := by decide +kernel
theorem a106_0_9_band3 : bandStats 16667484 16678756 2127 594 = (-1, 22141, -502) := by decide +kernel
theorem a106_0_9_band4 : bandStats 16667484 16678756 2721 503 = (-20, -38113, -511) := by decide +kernel
theorem a106_0_9_band5 : bandStats 16667484 16678756 3224 399 = (21, 229681, -486) := by decide +kernel

end QuarticKernel.KernelPrefixes
