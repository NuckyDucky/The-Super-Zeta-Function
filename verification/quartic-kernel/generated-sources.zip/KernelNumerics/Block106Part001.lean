import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_0_band4 : bandStats 16565089 16576312 2711 502 = (-2, -82091, -500) := by decide +kernel
theorem a106_0_0_band5 : bandStats 16565089 16576312 3213 402 = (-36, -236785, -514) := by decide +kernel
theorem a106_0_0_band6 : bandStats 16565089 16576312 3615 281 = (12, 152733, -492) := by decide +kernel
theorem a106_0_0_band7 : bandStats 16565089 16576312 3896 149 = (24, 260484, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
