import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_2_band6 : bandStats 16416841 16428113 3584 281 = (6, 49521, -492) := by decide +kernel
theorem a105_0_2_band7 : bandStats 16416841 16428113 3865 155 = (-20, -315731, -506) := by decide +kernel
theorem a105_0_2_band8 : bandStats 16416841 16428113 4020 33 = (-24, -140804, -358) := by decide +kernel
theorem a105_0_3_band0 : bandStats 16428113 16439305 0 741 = (34, 140216, -480) := by decide +kernel

end QuarticKernel.KernelPrefixes
