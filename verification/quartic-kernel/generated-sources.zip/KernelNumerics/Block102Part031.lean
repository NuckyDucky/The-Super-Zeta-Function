import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_14_band4 : bandStats 16038361 16048564 2873 496 = (-57, -202056, -526) := by decide +kernel
theorem a102_0_14_band5 : bandStats 16038361 16048564 3369 363 = (37, 255452, -482) := by decide +kernel
theorem a102_0_14_band6 : bandStats 16038361 16048564 3732 215 = (-34, -25600, -515) := by decide +kernel
theorem a102_0_14_band7 : bandStats 16038361 16048564 3947 59 = (32, -27296, -414) := by decide +kernel

end QuarticKernel.KernelPrefixes
