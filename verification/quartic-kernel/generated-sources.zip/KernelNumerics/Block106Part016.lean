import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_7_band0 : bandStats 16644624 16656209 0 711 = (33, 109614, -483) := by decide +kernel
theorem a106_0_7_band1 : bandStats 16644624 16656209 711 701 = (-60, -353371, -527) := by decide +kernel
theorem a106_0_7_band2 : bandStats 16644624 16656209 1412 657 = (-67, -493092, -532) := by decide +kernel
theorem a106_0_7_band3 : bandStats 16644624 16656209 2069 586 = (-6, -66147, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
