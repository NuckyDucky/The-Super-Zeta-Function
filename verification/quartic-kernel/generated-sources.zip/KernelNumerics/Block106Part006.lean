import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_2_band6 : bandStats 16587505 16598631 3630 276 = (-8, 30412, -503) := by decide +kernel
theorem a106_0_2_band7 : bandStats 16587505 16598631 3906 145 = (-41, -267430, -520) := by decide +kernel
theorem a106_0_2_band8 : bandStats 16587505 16598631 4051 23 = (19, 41847, -278) := by decide +kernel
theorem a106_0_3_band0 : bandStats 16598631 16609849 0 737 = (27, 131775, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
