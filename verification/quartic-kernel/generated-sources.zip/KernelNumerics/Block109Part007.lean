import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_2_band8 : bandStats 17153620 17166439 3962 141 = (10, -104534, -491) := by decide +kernel
theorem a109_0_2_band9 : bandStats 17153620 17166439 4103 40 = (7, 158926, -426) := by decide +kernel
theorem a109_0_3_band0 : bandStats 17166439 17179180 0 673 = (-20, -134733, -507) := by decide +kernel
theorem a109_0_3_band1 : bandStats 17166439 17179180 673 648 = (-15, -76440, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
