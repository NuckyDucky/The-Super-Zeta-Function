import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_1_band3 : bandStats 15739632 15750561 2117 588 = (-11, 46995, -508) := by decide +kernel
theorem a101_0_1_band4 : bandStats 15739632 15750561 2705 492 = (0, -184679, -496) := by decide +kernel
theorem a101_0_1_band5 : bandStats 15739632 15750561 3197 381 = (-33, -162357, -515) := by decide +kernel
theorem a101_0_1_band6 : bandStats 15739632 15750561 3578 256 = (-33, -171594, -515) := by decide +kernel

end QuarticKernel.KernelPrefixes
