import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_4_band8 : bandStats 17537860 17550601 4021 135 = (-64, -414306, -529) := by decide +kernel
theorem a111_0_4_band9 : bandStats 17537860 17550601 4156 33 = (3, 75889, -390) := by decide +kernel
theorem a111_0_5_band0 : bandStats 17550601 17563240 0 691 = (4, -89464, -494) := by decide +kernel
theorem a111_0_5_band1 : bandStats 17550601 17563240 691 655 = (12, 33481, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
