import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_8_band4 : bandStats 16313785 16324696 2753 512 = (-7, -147280, -502) := by decide +kernel
theorem a104_0_8_band5 : bandStats 16313785 16324696 3265 385 = (41, 355779, -478) := by decide +kernel
theorem a104_0_8_band6 : bandStats 16313785 16324696 3650 258 = (6, 22805, -495) := by decide +kernel
theorem a104_0_8_band7 : bandStats 16313785 16324696 3908 122 = (6, 178280, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
