import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_6_band6 : bandStats 15687521 15698545 3553 260 = (-21, -115479, -506) := by decide +kernel
theorem a100_0_6_band7 : bandStats 15687521 15698545 3813 132 = (-9, -125054, -497) := by decide +kernel
theorem a100_0_6_band8 : bandStats 15687521 15698545 3945 17 = (-43, -294698, -268) := by decide +kernel
theorem a100_0_7_band0 : bandStats 15698545 15709524 0 732 = (-46, -106426, -522) := by decide +kernel

end QuarticKernel.KernelPrefixes
