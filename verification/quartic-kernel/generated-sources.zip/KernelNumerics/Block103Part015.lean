import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_6_band7 : bandStats 16122599 16133543 3880 124 = (2, 7106, -486) := by decide +kernel
theorem a103_0_6_band8 : bandStats 16122599 16133543 4004 12 = (7, 81630, -195) := by decide +kernel
theorem a103_0_7_band0 : bandStats 16133543 16144227 0 776 = (9, 141145, -495) := by decide +kernel
theorem a103_0_7_band1 : bandStats 16133543 16144227 776 739 = (-5, -144691, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
