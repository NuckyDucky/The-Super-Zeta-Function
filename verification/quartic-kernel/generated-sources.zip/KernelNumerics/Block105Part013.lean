import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_5_band7 : bandStats 16450449 16461520 3884 147 = (-9, -115903, -497) := by decide +kernel
theorem a105_0_5_band8 : bandStats 16450449 16461520 4031 26 = (-12, -85272, -317) := by decide +kernel
theorem a105_0_6_band0 : bandStats 16461520 16472744 0 746 = (-58, -411912, -527) := by decide +kernel
theorem a105_0_6_band1 : bandStats 16461520 16472744 746 713 = (29, 224397, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
