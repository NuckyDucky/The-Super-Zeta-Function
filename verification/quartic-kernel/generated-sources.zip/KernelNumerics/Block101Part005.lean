import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_2_band2 : bandStats 15750561 15761460 1459 665 = (-4, -140042, -500) := by decide +kernel
theorem a101_0_2_band3 : bandStats 15750561 15761460 2124 591 = (71, 382164, -462) := by decide +kernel
theorem a101_0_2_band4 : bandStats 15750561 15761460 2715 493 = (3, -97366, -496) := by decide +kernel
theorem a101_0_2_band5 : bandStats 15750561 15761460 3208 381 = (12, 97372, -490) := by decide +kernel

end QuarticKernel.KernelPrefixes
