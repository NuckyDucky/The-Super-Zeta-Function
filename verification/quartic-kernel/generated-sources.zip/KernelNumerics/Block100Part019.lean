import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_8_band4 : bandStats 15709524 15720712 2653 492 = (29, 369911, -482) := by decide +kernel
theorem a100_0_8_band5 : bandStats 15709524 15720712 3145 384 = (0, -53932, -500) := by decide +kernel
theorem a100_0_8_band6 : bandStats 15709524 15720712 3529 270 = (-15, -101248, -506) := by decide +kernel
theorem a100_0_8_band7 : bandStats 15709524 15720712 3799 141 = (10, 96468, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
