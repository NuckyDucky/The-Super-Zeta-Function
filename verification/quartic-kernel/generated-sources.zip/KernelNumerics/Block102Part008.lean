import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_3_band5 : bandStats 15924100 15934641 3302 371 = (-5, -11192, -501) := by decide +kernel
theorem a102_0_3_band6 : bandStats 15924100 15934641 3673 232 = (-1, 12780, -496) := by decide +kernel
theorem a102_0_3_band7 : bandStats 15924100 15934641 3905 85 = (16, 63211, -481) := by decide +kernel
theorem a102_0_3_band8 : bandStats 15924100 15934641 3990 1 = (19, 83030, -30) := by decide +kernel

end QuarticKernel.KernelPrefixes
