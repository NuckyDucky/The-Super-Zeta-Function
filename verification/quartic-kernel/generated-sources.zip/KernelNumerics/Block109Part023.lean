import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_9_band2 : bandStats 17242627 17255744 1284 602 = (-23, -342216, -509) := by decide +kernel
theorem a109_0_9_band3 : bandStats 17242627 17255744 1886 549 = (-11, -103134, -505) := by decide +kernel
theorem a109_0_9_band4 : bandStats 17242627 17255744 2435 498 = (-31, -159524, -516) := by decide +kernel
theorem a109_0_9_band5 : bandStats 17242627 17255744 2933 426 = (-5, -144385, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
