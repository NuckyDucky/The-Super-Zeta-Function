import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_0_band0 : bandStats 16951979 16964289 0 691 = (-3, -47600, -500) := by decide +kernel
theorem a108_0_0_band1 : bandStats 16951979 16964289 691 657 = (21, 325992, -486) := by decide +kernel
theorem a108_0_0_band2 : bandStats 16951979 16964289 1348 633 = (-10, -41904, -505) := by decide +kernel
theorem a108_0_0_band3 : bandStats 16951979 16964289 1981 571 = (-33, -161547, -512) := by decide +kernel

end QuarticKernel.KernelPrefixes
