import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_5_band3 : bandStats 16450449 16461520 2105 597 = (-20, -375888, -511) := by decide +kernel
theorem a105_0_5_band4 : bandStats 16450449 16461520 2702 507 = (-37, -132342, -516) := by decide +kernel
theorem a105_0_5_band5 : bandStats 16450449 16461520 3209 399 = (53, 161559, -470) := by decide +kernel
theorem a105_0_5_band6 : bandStats 16450449 16461520 3608 276 = (30, 69931, -486) := by decide +kernel

end QuarticKernel.KernelPrefixes
