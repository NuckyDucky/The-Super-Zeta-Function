import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_1_band0 : bandStats 16068483 16078900 0 790 = (33, 247000, -482) := by decide +kernel
theorem a103_0_1_band1 : bandStats 16068483 16078900 790 749 = (28, -59841, -481) := by decide +kernel
theorem a103_0_1_band2 : bandStats 16068483 16078900 1539 692 = (53, 282312, -472) := by decide +kernel
theorem a103_0_1_band3 : bandStats 16068483 16078900 2231 603 = (-5, 7547, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
