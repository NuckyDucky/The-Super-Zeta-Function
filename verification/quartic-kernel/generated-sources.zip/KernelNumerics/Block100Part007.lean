import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_3_band1 : bandStats 15654595 15665545 748 705 = (-7, -52677, -501) := by decide +kernel
theorem a100_0_3_band2 : bandStats 15654595 15665545 1453 656 = (-20, -35121, -510) := by decide +kernel
theorem a100_0_3_band3 : bandStats 15654595 15665545 2109 583 = (-20, -131181, -502) := by decide +kernel
theorem a100_0_3_band4 : bandStats 15654595 15665545 2692 491 = (-13, -68026, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
