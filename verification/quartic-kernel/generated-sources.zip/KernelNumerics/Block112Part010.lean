import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_4_band0 : bandStats 17718416 17730595 0 713 = (31, 453214, -484) := by decide +kernel
theorem a112_0_4_band1 : bandStats 17718416 17730595 713 687 = (10, 118481, -492) := by decide +kernel
theorem a112_0_4_band2 : bandStats 17718416 17730595 1400 647 = (4, 169260, -493) := by decide +kernel
theorem a112_0_4_band3 : bandStats 17718416 17730595 2047 582 = (-20, -274994, -510) := by decide +kernel

end QuarticKernel.KernelPrefixes
