import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_8_band4 : bandStats 16872697 16884841 2560 499 = (-16, 60136, -506) := by decide +kernel
theorem a107_0_8_band5 : bandStats 16872697 16884841 3059 418 = (-25, -109493, -511) := by decide +kernel
theorem a107_0_8_band6 : bandStats 16872697 16884841 3477 315 = (9, 207845, -497) := by decide +kernel
theorem a107_0_8_band7 : bandStats 16872697 16884841 3792 211 = (20, 260735, -487) := by decide +kernel

end QuarticKernel.KernelPrefixes
