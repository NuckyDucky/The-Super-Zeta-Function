import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_4_band8 : bandStats 16824831 16836576 4033 68 = (52, 339453, -432) := by decide +kernel
theorem a107_0_4_band9 : bandStats 16824831 16836576 4101 2 = (23, 138958, -60) := by decide +kernel
theorem a107_0_5_band0 : bandStats 16836576 16848744 0 697 = (44, 299278, -476) := by decide +kernel
theorem a107_0_5_band1 : bandStats 16836576 16848744 697 668 = (-24, -134198, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
