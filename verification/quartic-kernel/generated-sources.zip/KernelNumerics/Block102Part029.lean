import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_13_band4 : bandStats 16028136 16038361 2876 494 = (2, -11297, -497) := by decide +kernel
theorem a102_0_13_band5 : bandStats 16028136 16038361 3370 366 = (0, 49599, -498) := by decide +kernel
theorem a102_0_13_band6 : bandStats 16028136 16038361 3736 210 = (-30, -104466, -512) := by decide +kernel
theorem a102_0_13_band7 : bandStats 16028136 16038361 3946 58 = (21, 80048, -406) := by decide +kernel

end QuarticKernel.KernelPrefixes
