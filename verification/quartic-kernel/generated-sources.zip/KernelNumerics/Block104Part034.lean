import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_15_band1 : bandStats 16391553 16394314 2766 1267 = (66, 97079, -465) := by decide +kernel
theorem a104_0_15_band2 : bandStats 16391553 16394314 4033 15 = (-8, -7698, -54) := by decide +kernel

end QuarticKernel.KernelPrefixes
