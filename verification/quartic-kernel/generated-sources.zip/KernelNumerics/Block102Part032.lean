import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_15_band0 : bandStats 16048564 16058028 0 849 = (-1, 48707, -497) := by decide +kernel
theorem a102_0_15_band1 : bandStats 16048564 16058028 849 824 = (-7, 1485, -501) := by decide +kernel
theorem a102_0_15_band2 : bandStats 16048564 16058028 1673 734 = (12, 155625, -490) := by decide +kernel
theorem a102_0_15_band3 : bandStats 16048564 16058028 2407 639 = (58, 324700, -471) := by decide +kernel

end QuarticKernel.KernelPrefixes
