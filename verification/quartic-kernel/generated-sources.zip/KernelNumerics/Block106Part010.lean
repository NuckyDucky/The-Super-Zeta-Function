import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_4_band4 : bandStats 16609849 16621161 2700 502 = (59, 364341, -469) := by decide +kernel
theorem a106_0_4_band5 : bandStats 16609849 16621161 3202 399 = (14, 89412, -489) := by decide +kernel
theorem a106_0_4_band6 : bandStats 16609849 16621161 3601 283 = (-27, -7401, -512) := by decide +kernel
theorem a106_0_4_band7 : bandStats 16609849 16621161 3884 158 = (36, 218655, -477) := by decide +kernel

end QuarticKernel.KernelPrefixes
