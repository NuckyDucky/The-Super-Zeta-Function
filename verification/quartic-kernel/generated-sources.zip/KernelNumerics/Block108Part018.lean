import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_7_band2 : bandStats 17038833 17051683 1288 601 = (37, 211182, -479) := by decide +kernel
theorem a108_0_7_band3 : bandStats 17038833 17051683 1889 559 = (-5, -57470, -500) := by decide +kernel
theorem a108_0_7_band4 : bandStats 17038833 17051683 2448 503 = (23, 92159, -493) := by decide +kernel
theorem a108_0_7_band5 : bandStats 17038833 17051683 2951 421 = (-8, 35562, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
