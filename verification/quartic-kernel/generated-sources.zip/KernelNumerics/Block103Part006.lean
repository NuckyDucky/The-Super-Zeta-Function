import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_2_band7 : bandStats 16078900 16089444 3918 91 = (-1, 101865, -496) := by decide +kernel
theorem a103_0_2_band8 : bandStats 16078900 16089444 4009 2 = (19, 142690, -56) := by decide +kernel
theorem a103_0_3_band0 : bandStats 16089444 16100284 0 753 = (10, 205576, -494) := by decide +kernel
theorem a103_0_3_band1 : bandStats 16089444 16100284 753 732 = (54, 303864, -468) := by decide +kernel

end QuarticKernel.KernelPrefixes
