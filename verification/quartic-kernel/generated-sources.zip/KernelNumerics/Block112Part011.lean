import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_4_band4 : bandStats 17718416 17730595 2629 512 = (-1, 83745, -498) := by decide +kernel
theorem a112_0_4_band5 : bandStats 17718416 17730595 3141 420 = (32, 309686, -482) := by decide +kernel
theorem a112_0_4_band6 : bandStats 17718416 17730595 3561 326 = (6, -106265, -493) := by decide +kernel
theorem a112_0_4_band7 : bandStats 17718416 17730595 3887 216 = (-12, -4580, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
