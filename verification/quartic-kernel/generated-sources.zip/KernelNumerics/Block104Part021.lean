import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_9_band3 : bandStats 16324696 16335775 2132 595 = (-9, -246081, -493) := by decide +kernel
theorem a104_0_9_band4 : bandStats 16324696 16335775 2727 499 = (-12, 42193, -504) := by decide +kernel
theorem a104_0_9_band5 : bandStats 16324696 16335775 3226 393 = (23, 168643, -487) := by decide +kernel
theorem a104_0_9_band6 : bandStats 16324696 16335775 3619 267 = (14, -3410, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
