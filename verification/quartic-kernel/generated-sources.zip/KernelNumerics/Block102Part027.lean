import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_12_band4 : bandStats 16017769 16028136 2847 500 = (-20, -225109, -509) := by decide +kernel
theorem a102_0_12_band5 : bandStats 16017769 16028136 3347 365 = (12, 88797, -490) := by decide +kernel
theorem a102_0_12_band6 : bandStats 16017769 16028136 3712 222 = (-58, -315415, -525) := by decide +kernel
theorem a102_0_12_band7 : bandStats 16017769 16028136 3934 69 = (2, -103531, -460) := by decide +kernel

end QuarticKernel.KernelPrefixes
