import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_8_band8 : bandStats 15709524 15720712 3940 24 = (22, 152414, -279) := by decide +kernel
theorem a100_0_9_band0 : bandStats 15720712 15728640 0 1017 = (1, 52705, -501) := by decide +kernel
theorem a100_0_9_band1 : bandStats 15720712 15728640 1017 943 = (39, 305851, -480) := by decide +kernel
theorem a100_0_9_band2 : bandStats 15720712 15728640 1960 808 = (-16, -127857, -507) := by decide +kernel

end QuarticKernel.KernelPrefixes
