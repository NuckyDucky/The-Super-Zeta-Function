import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_12_band3 : bandStats 17281300 17293801 1962 577 = (-28, -338141, -508) := by decide +kernel
theorem a109_0_12_band4 : bandStats 17281300 17293801 2539 493 = (16, 118296, -492) := by decide +kernel
theorem a109_0_12_band5 : bandStats 17281300 17293801 3032 428 = (13, 26807, -492) := by decide +kernel
theorem a109_0_12_band6 : bandStats 17281300 17293801 3460 333 = (42, 256755, -476) := by decide +kernel

end QuarticKernel.KernelPrefixes
