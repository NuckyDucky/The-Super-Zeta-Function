import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_1_band2 : bandStats 17499832 17512524 1334 618 = (-7, -24294, -501) := by decide +kernel
theorem a111_0_1_band3 : bandStats 17499832 17512524 1952 569 = (29, 433557, -482) := by decide +kernel
theorem a111_0_1_band4 : bandStats 17499832 17512524 2521 499 = (-6, -223632, -504) := by decide +kernel
theorem a111_0_1_band5 : bandStats 17499832 17512524 3020 428 = (3, -148781, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
