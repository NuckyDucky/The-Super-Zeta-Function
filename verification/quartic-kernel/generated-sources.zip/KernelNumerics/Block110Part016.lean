import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_6_band4 : bandStats 17384116 17396999 2484 503 = (8, -61412, -493) := by decide +kernel
theorem a110_0_6_band5 : bandStats 17384116 17396999 2987 423 = (-4, -86179, -500) := by decide +kernel
theorem a110_0_6_band6 : bandStats 17384116 17396999 3410 337 = (-13, -77580, -507) := by decide +kernel
theorem a110_0_6_band7 : bandStats 17384116 17396999 3747 242 = (0, 7932, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
