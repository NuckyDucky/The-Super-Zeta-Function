import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_10_band4 : bandStats 15997409 16007539 2910 493 = (78, 362063, -461) := by decide +kernel
theorem a102_0_10_band5 : bandStats 15997409 16007539 3403 352 = (9, 89144, -492) := by decide +kernel
theorem a102_0_10_band6 : bandStats 15997409 16007539 3755 201 = (21, 209320, -489) := by decide +kernel
theorem a102_0_10_band7 : bandStats 15997409 16007539 3956 44 = (13, 196237, -350) := by decide +kernel

end QuarticKernel.KernelPrefixes
