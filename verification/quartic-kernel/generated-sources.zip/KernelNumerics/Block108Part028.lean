import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_11_band2 : bandStats 17089955 17102424 1312 615 = (46, 453812, -475) := by decide +kernel
theorem a108_0_11_band3 : bandStats 17089955 17102424 1927 572 = (-35, -377297, -518) := by decide +kernel
theorem a108_0_11_band4 : bandStats 17089955 17102424 2499 505 = (-43, -311085, -524) := by decide +kernel
theorem a108_0_11_band5 : bandStats 17089955 17102424 3004 419 = (51, 467642, -473) := by decide +kernel

end QuarticKernel.KernelPrefixes
