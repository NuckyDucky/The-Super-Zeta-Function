import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_12_band7 : bandStats 17281300 17293801 3793 226 = (-10, -180723, -501) := by decide +kernel
theorem a109_0_12_band8 : bandStats 17281300 17293801 4019 119 = (-18, -108005, -510) := by decide +kernel
theorem a109_0_12_band9 : bandStats 17281300 17293801 4138 20 = (18, 138747, -284) := by decide +kernel
theorem a109_0_13_band0 : bandStats 17293801 17306313 0 678 = (-16, 112775, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
