import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_10_band2 : bandStats 17436003 17449008 1288 605 = (-18, -142763, -509) := by decide +kernel
theorem a110_0_10_band3 : bandStats 17436003 17449008 1893 557 = (-2, 40328, -499) := by decide +kernel
theorem a110_0_10_band4 : bandStats 17436003 17449008 2450 502 = (28, 277360, -483) := by decide +kernel
theorem a110_0_10_band5 : bandStats 17436003 17449008 2952 428 = (6, 272631, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
