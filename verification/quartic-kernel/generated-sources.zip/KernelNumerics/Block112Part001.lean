import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_0_band4 : bandStats 17669428 17681689 2610 515 = (-21, -127130, -509) := by decide +kernel
theorem a112_0_0_band5 : bandStats 17669428 17681689 3125 423 = (15, 148385, -490) := by decide +kernel
theorem a112_0_0_band6 : bandStats 17669428 17681689 3548 326 = (16, 127285, -487) := by decide +kernel
theorem a112_0_0_band7 : bandStats 17669428 17681689 3874 216 = (15, 79763, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
