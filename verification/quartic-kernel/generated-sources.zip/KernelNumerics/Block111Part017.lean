import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_6_band8 : bandStats 17563240 17575617 4060 115 = (-1, -213818, -494) := by decide +kernel
theorem a111_0_6_band9 : bandStats 17563240 17575617 4175 17 = (3, -4700, -274) := by decide +kernel
theorem a111_0_7_band0 : bandStats 17575617 17588209 0 692 = (-46, -297956, -522) := by decide +kernel
theorem a111_0_7_band1 : bandStats 17575617 17588209 692 663 = (-12, 65333, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
