import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_12_band0 : bandStats 16921377 16933903 0 672 = (-20, -225045, -507) := by decide +kernel
theorem a107_0_12_band1 : bandStats 16921377 16933903 672 656 = (-3, -47194, -502) := by decide +kernel
theorem a107_0_12_band2 : bandStats 16921377 16933903 1328 616 = (15, 33901, -490) := by decide +kernel
theorem a107_0_12_band3 : bandStats 16921377 16933903 1944 563 = (-34, -444801, -514) := by decide +kernel

end QuarticKernel.KernelPrefixes
