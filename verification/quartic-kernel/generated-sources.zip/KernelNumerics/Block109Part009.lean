import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_3_band6 : bandStats 17166439 17179180 3419 333 = (-22, -159599, -509) := by decide +kernel
theorem a109_0_3_band7 : bandStats 17166439 17179180 3752 233 = (-10, -263085, -500) := by decide +kernel
theorem a109_0_3_band8 : bandStats 17166439 17179180 3985 130 = (9, 95666, -494) := by decide +kernel
theorem a109_0_3_band9 : bandStats 17166439 17179180 4115 29 = (37, 166879, -338) := by decide +kernel

end QuarticKernel.KernelPrefixes
