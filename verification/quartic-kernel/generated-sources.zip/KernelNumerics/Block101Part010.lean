import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_4_band4 : bandStats 15772464 15783064 2777 491 = (36, 248716, -480) := by decide +kernel
theorem a101_0_4_band5 : bandStats 15772464 15783064 3268 373 = (-1, -18932, -496) := by decide +kernel
theorem a101_0_4_band6 : bandStats 15772464 15783064 3641 235 = (-37, -237273, -518) := by decide +kernel
theorem a101_0_4_band7 : bandStats 15772464 15783064 3876 94 = (7, 87817, -490) := by decide +kernel

end QuarticKernel.KernelPrefixes
