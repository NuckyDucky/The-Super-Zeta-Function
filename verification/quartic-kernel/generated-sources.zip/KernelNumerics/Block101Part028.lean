import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_12_band4 : bandStats 15857980 15868835 2733 493 = (-30, -58378, -514) := by decide +kernel
theorem a101_0_12_band5 : bandStats 15857980 15868835 3226 384 = (14, 210718, -488) := by decide +kernel
theorem a101_0_12_band6 : bandStats 15857980 15868835 3610 249 = (18, 41481, -487) := by decide +kernel
theorem a101_0_12_band7 : bandStats 15857980 15868835 3859 116 = (-11, 7250, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
