import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_8_band8 : bandStats 16483897 16495089 4032 29 = (-21, -94646, -337) := by decide +kernel
theorem a105_0_9_band0 : bandStats 16495089 16506384 0 742 = (30, 42620, -483) := by decide +kernel
theorem a105_0_9_band1 : bandStats 16495089 16506384 742 712 = (-25, -264919, -512) := by decide +kernel
theorem a105_0_9_band2 : bandStats 16495089 16506384 1454 663 = (-48, -365673, -521) := by decide +kernel

end QuarticKernel.KernelPrefixes
