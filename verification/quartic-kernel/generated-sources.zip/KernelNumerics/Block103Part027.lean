import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_12_band1 : bandStats 16186753 16197641 761 729 = (9, 54069, -491) := by decide +kernel
theorem a103_0_12_band2 : bandStats 16186753 16197641 1490 672 = (17, 126753, -488) := by decide +kernel
theorem a103_0_12_band3 : bandStats 16186753 16197641 2162 600 = (62, 294243, -468) := by decide +kernel
theorem a103_0_12_band4 : bandStats 16186753 16197641 2762 496 = (-18, -86708, -507) := by decide +kernel

end QuarticKernel.KernelPrefixes
