import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_5_band4 : bandStats 16111484 16122599 2687 500 = (-46, -340946, -520) := by decide +kernel
theorem a103_0_5_band5 : bandStats 16111484 16122599 3187 394 = (-30, -148587, -515) := by decide +kernel
theorem a103_0_5_band6 : bandStats 16111484 16122599 3581 272 = (-47, -315400, -521) := by decide +kernel
theorem a103_0_5_band7 : bandStats 16111484 16122599 3853 140 = (-31, -127903, -512) := by decide +kernel

end QuarticKernel.KernelPrefixes
