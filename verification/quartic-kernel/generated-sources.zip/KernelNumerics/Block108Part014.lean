import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_5_band6 : bandStats 17013348 17025936 3418 329 = (36, 207315, -481) := by decide +kernel
theorem a108_0_5_band7 : bandStats 17013348 17025936 3747 230 = (18, 255439, -490) := by decide +kernel
theorem a108_0_5_band8 : bandStats 17013348 17025936 3977 125 = (6, -56171, -486) := by decide +kernel
theorem a108_0_5_band9 : bandStats 17013348 17025936 4102 24 = (-5, -51598, -331) := by decide +kernel

end QuarticKernel.KernelPrefixes
