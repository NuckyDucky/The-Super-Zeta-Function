import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_1_band1 : bandStats 16748999 16760115 761 722 = (-16, -251832, -507) := by decide +kernel
theorem a106_1_1_band2 : bandStats 16748999 16760115 1483 670 = (66, 144939, -464) := by decide +kernel
theorem a106_1_1_band3 : bandStats 16748999 16760115 2153 600 = (7, -158341, -494) := by decide +kernel
theorem a106_1_1_band4 : bandStats 16748999 16760115 2753 506 = (29, 73285, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
