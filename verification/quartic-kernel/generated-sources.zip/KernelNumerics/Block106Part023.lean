import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_10_band1 : bandStats 16678756 16689817 734 734 = (-20, -88112, -507) := by decide +kernel
theorem a106_0_10_band2 : bandStats 16678756 16689817 1468 677 = (61, 387259, -468) := by decide +kernel
theorem a106_0_10_band3 : bandStats 16678756 16689817 2145 602 = (44, 18739, -477) := by decide +kernel
theorem a106_0_10_band4 : bandStats 16678756 16689817 2747 508 = (-11, 15086, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
