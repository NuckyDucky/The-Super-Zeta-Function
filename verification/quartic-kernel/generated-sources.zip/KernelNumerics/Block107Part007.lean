import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_2_band8 : bandStats 16800999 16812961 4013 83 = (-30, -226023, -498) := by decide +kernel
theorem a107_0_2_band9 : bandStats 16800999 16812961 4096 4 = (-11, -107226, -130) := by decide +kernel
theorem a107_0_3_band0 : bandStats 16812961 16824831 0 713 = (-4, -39146, -499) := by decide +kernel
theorem a107_0_3_band1 : bandStats 16812961 16824831 713 685 = (4, -16880, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
