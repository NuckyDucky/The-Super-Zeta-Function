import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_3_band1 : bandStats 15761460 15772464 727 716 = (-48, -318417, -523) := by decide +kernel
theorem a101_0_3_band2 : bandStats 15761460 15772464 1443 662 = (59, 478856, -471) := by decide +kernel
theorem a101_0_3_band3 : bandStats 15761460 15772464 2105 586 = (-45, -295971, -516) := by decide +kernel
theorem a101_0_3_band4 : bandStats 15761460 15772464 2691 493 = (-13, 40409, -507) := by decide +kernel

end QuarticKernel.KernelPrefixes
