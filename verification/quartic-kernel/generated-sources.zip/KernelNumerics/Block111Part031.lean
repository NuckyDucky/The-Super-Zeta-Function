import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_12_band4 : bandStats 17638201 17650504 2573 515 = (-45, -218386, -513) := by decide +kernel
theorem a111_0_12_band5 : bandStats 17638201 17650504 3088 429 = (54, 319131, -471) := by decide +kernel
theorem a111_0_12_band6 : bandStats 17638201 17650504 3517 327 = (1, 32270, -496) := by decide +kernel
theorem a111_0_12_band7 : bandStats 17638201 17650504 3844 226 = (23, 163537, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
