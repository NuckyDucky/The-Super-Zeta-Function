import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_10_band6 : bandStats 15836300 15847153 3605 252 = (25, 37696, -485) := by decide +kernel
theorem a101_0_10_band7 : bandStats 15836300 15847153 3857 115 = (6, 22740, -487) := by decide +kernel
theorem a101_0_10_band8 : bandStats 15836300 15847153 3972 8 = (17, 153620, -148) := by decide +kernel
theorem a101_0_11_band0 : bandStats 15847153 15857980 0 735 = (-21, -123065, -509) := by decide +kernel

end QuarticKernel.KernelPrefixes
