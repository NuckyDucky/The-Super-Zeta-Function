import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_12_band4 : bandStats 17462184 17475124 2461 503 = (-10, 73935, -508) := by decide +kernel
theorem a110_0_12_band5 : bandStats 17462184 17475124 2964 427 = (7, 22803, -493) := by decide +kernel
theorem a110_0_12_band6 : bandStats 17462184 17475124 3391 340 = (-40, 60875, -518) := by decide +kernel
theorem a110_0_12_band7 : bandStats 17462184 17475124 3731 249 = (-24, -307577, -511) := by decide +kernel

end QuarticKernel.KernelPrefixes
