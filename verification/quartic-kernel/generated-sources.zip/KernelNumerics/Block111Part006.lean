import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_2_band4 : bandStats 17512524 17525139 2530 504 = (-17, -53157, -510) := by decide +kernel
theorem a111_0_2_band5 : bandStats 17512524 17525139 3034 423 = (-59, -471965, -529) := by decide +kernel
theorem a111_0_2_band6 : bandStats 17512524 17525139 3457 339 = (46, 350627, -474) := by decide +kernel
theorem a111_0_2_band7 : bandStats 17512524 17525139 3796 235 = (21, 120681, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
