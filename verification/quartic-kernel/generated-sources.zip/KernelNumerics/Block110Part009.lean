import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_3_band6 : bandStats 17345295 17358249 3376 344 = (-14, -154202, -504) := by decide +kernel
theorem a110_0_3_band7 : bandStats 17345295 17358249 3720 247 = (-4, -105146, -504) := by decide +kernel
theorem a110_0_3_band8 : bandStats 17345295 17358249 3967 150 = (-34, -413424, -515) := by decide +kernel
theorem a110_0_3_band9 : bandStats 17345295 17358249 4117 49 = (-22, -255162, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
