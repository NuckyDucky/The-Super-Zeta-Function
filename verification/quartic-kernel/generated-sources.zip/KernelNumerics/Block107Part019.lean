import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_7_band6 : bandStats 16860752 16872697 3511 313 = (33, 273469, -479) := by decide +kernel
theorem a107_0_7_band7 : bandStats 16860752 16872697 3824 198 = (51, 418335, -472) := by decide +kernel
theorem a107_0_7_band8 : bandStats 16860752 16872697 4022 82 = (-19, -145169, -496) := by decide +kernel
theorem a107_0_7_band9 : bandStats 16860752 16872697 4104 3 = (-1, -36240, -98) := by decide +kernel

end QuarticKernel.KernelPrefixes
