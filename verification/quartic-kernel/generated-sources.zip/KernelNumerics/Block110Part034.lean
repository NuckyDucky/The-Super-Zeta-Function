import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_13_band2 : bandStats 17475124 17487268 1400 645 = (-26, -210887, -509) := by decide +kernel
theorem a110_0_13_band3 : bandStats 17475124 17487268 2045 585 = (-13, -14891, -502) := by decide +kernel
theorem a110_0_13_band4 : bandStats 17475124 17487268 2630 509 = (-27, -351900, -511) := by decide +kernel
theorem a110_0_13_band5 : bandStats 17475124 17487268 3139 421 = (24, 43386, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
