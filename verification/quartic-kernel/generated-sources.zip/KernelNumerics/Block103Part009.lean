import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_4_band1 : bandStats 16100284 16111484 743 701 = (3, 3468, -499) := by decide +kernel
theorem a103_0_4_band2 : bandStats 16100284 16111484 1444 656 = (15, 23459, -491) := by decide +kernel
theorem a103_0_4_band3 : bandStats 16100284 16111484 2100 584 = (4, 38697, -501) := by decide +kernel
theorem a103_0_4_band4 : bandStats 16100284 16111484 2684 496 = (-2, -86256, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
