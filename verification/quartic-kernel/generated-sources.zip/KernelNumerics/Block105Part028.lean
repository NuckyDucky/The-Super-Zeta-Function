import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_12_band4 : bandStats 16528585 16539939 2699 503 = (-7, 3304, -499) := by decide +kernel
theorem a105_0_12_band5 : bandStats 16528585 16539939 3202 397 = (36, 87284, -480) := by decide +kernel
theorem a105_0_12_band6 : bandStats 16528585 16539939 3599 282 = (-20, -50665, -506) := by decide +kernel
theorem a105_0_12_band7 : bandStats 16528585 16539939 3881 154 = (17, 141619, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
