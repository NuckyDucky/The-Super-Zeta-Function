import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_0_band0 : bandStats 16394314 16405384 0 725 = (24, 5580, -484) := by decide +kernel
theorem a105_0_0_band1 : bandStats 16394314 16405384 725 720 = (5, -21715, -492) := by decide +kernel
theorem a105_0_0_band2 : bandStats 16394314 16405384 1445 672 = (6, -115453, -496) := by decide +kernel
theorem a105_0_0_band3 : bandStats 16394314 16405384 2117 600 = (72, 263637, -465) := by decide +kernel

end QuarticKernel.KernelPrefixes
