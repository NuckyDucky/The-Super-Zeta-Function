import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_12_band4 : bandStats 16921377 16933903 2507 498 = (-78, -736623, -539) := by decide +kernel
theorem a107_0_12_band5 : bandStats 16921377 16933903 3005 415 = (12, 85098, -493) := by decide +kernel
theorem a107_0_12_band6 : bandStats 16921377 16933903 3420 327 = (-6, -101126, -502) := by decide +kernel
theorem a107_0_12_band7 : bandStats 16921377 16933903 3747 227 = (-10, -105029, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
