import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_12_band0 : bandStats 15857980 15868835 0 750 = (8, 160719, -493) := by decide +kernel
theorem a101_0_12_band1 : bandStats 15857980 15868835 750 715 = (-14, -66272, -504) := by decide +kernel
theorem a101_0_12_band2 : bandStats 15857980 15868835 1465 670 = (-4, 153243, -500) := by decide +kernel
theorem a101_0_12_band3 : bandStats 15857980 15868835 2135 598 = (13, 146021, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
