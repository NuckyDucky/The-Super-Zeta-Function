import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_3_band2 : bandStats 17706316 17718416 1383 650 = (5, 34886, -497) := by decide +kernel
theorem a112_0_3_band3 : bandStats 17706316 17718416 2033 594 = (37, -1985, -480) := by decide +kernel
theorem a112_0_3_band4 : bandStats 17706316 17718416 2627 519 = (3, -121519, -498) := by decide +kernel
theorem a112_0_3_band5 : bandStats 17706316 17718416 3146 430 = (-3, 114954, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
