import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_0_band0 : bandStats 15621799 15632657 0 748 = (5, 131451, -495) := by decide +kernel
theorem a100_0_0_band1 : bandStats 15621799 15632657 748 719 = (12, -142781, -493) := by decide +kernel
theorem a100_0_0_band2 : bandStats 15621799 15632657 1467 662 = (66, 385064, -466) := by decide +kernel
theorem a100_0_0_band3 : bandStats 15621799 15632657 2129 585 = (4, -18782, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
