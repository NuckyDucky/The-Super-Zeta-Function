import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_1_band2 : bandStats 16788905 16800999 1377 631 = (28, 63853, -484) := by decide +kernel
theorem a107_0_1_band3 : bandStats 16788905 16800999 2008 574 = (-31, -251527, -507) := by decide +kernel
theorem a107_0_1_band4 : bandStats 16788905 16800999 2582 503 = (34, 138620, -479) := by decide +kernel
theorem a107_0_1_band5 : bandStats 16788905 16800999 3085 412 = (0, -76915, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
