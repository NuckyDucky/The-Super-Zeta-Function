import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_1_band3 : bandStats 16576312 16587505 2128 595 = (-44, -214029, -517) := by decide +kernel
theorem a106_0_1_band4 : bandStats 16576312 16587505 2723 505 = (31, 154871, -484) := by decide +kernel
theorem a106_0_1_band5 : bandStats 16576312 16587505 3228 397 = (-14, 38518, -505) := by decide +kernel
theorem a106_0_1_band6 : bandStats 16576312 16587505 3625 274 = (-19, -216529, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
