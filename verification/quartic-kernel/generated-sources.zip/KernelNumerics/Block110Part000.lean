import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_0_band0 : bandStats 17306986 17319507 0 679 = (28, 54461, -485) := by decide +kernel
theorem a110_0_0_band1 : bandStats 17306986 17319507 679 659 = (49, 277791, -471) := by decide +kernel
theorem a110_0_0_band2 : bandStats 17306986 17319507 1338 627 = (34, 363547, -479) := by decide +kernel
theorem a110_0_0_band3 : bandStats 17306986 17319507 1965 567 = (9, -70089, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
