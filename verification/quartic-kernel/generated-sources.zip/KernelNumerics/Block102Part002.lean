import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_0_band8 : bandStats 15892481 15902992 3986 1 = (3, -1210, -39) := by decide +kernel
theorem a102_0_1_band0 : bandStats 15902992 15913464 0 767 = (-33, -188373, -514) := by decide +kernel
theorem a102_0_1_band1 : bandStats 15902992 15913464 767 752 = (24, 99005, -486) := by decide +kernel
theorem a102_0_1_band2 : bandStats 15902992 15913464 1519 687 = (74, 420533, -460) := by decide +kernel

end QuarticKernel.KernelPrefixes
