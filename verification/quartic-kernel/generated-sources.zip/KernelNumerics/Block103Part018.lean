import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_8_band1 : bandStats 16144227 16154608 770 756 = (81, 598854, -461) := by decide +kernel
theorem a103_0_8_band2 : bandStats 16144227 16154608 1526 699 = (58, 280989, -469) := by decide +kernel
theorem a103_0_8_band3 : bandStats 16144227 16154608 2225 613 = (18, 118569, -493) := by decide +kernel
theorem a103_0_8_band4 : bandStats 16144227 16154608 2838 501 = (36, 270766, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
