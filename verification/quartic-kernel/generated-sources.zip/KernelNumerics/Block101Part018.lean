import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_8_band0 : bandStats 15814849 15825464 0 757 = (36, 174505, -482) := by decide +kernel
theorem a101_0_8_band1 : bandStats 15814849 15825464 757 737 = (-13, -1046, -500) := by decide +kernel
theorem a101_0_8_band2 : bandStats 15814849 15825464 1494 678 = (52, 218313, -472) := by decide +kernel
theorem a101_0_8_band3 : bandStats 15814849 15825464 2172 595 = (4, 23401, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
