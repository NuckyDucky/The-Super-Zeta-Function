import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_13_band6 : bandStats 17650504 17663080 3486 334 = (21, 214937, -486) := by decide +kernel
theorem a111_0_13_band7 : bandStats 17650504 17663080 3820 232 = (-5, -192618, -499) := by decide +kernel
theorem a111_0_13_band8 : bandStats 17650504 17663080 4052 126 = (-12, -75883, -496) := by decide +kernel
theorem a111_0_13_band9 : bandStats 17650504 17663080 4178 24 = (14, 173038, -310) := by decide +kernel

end QuarticKernel.KernelPrefixes
