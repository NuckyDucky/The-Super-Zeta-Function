import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_6_band2 : bandStats 15793543 15804148 1491 675 = (-27, -188633, -513) := by decide +kernel
theorem a101_0_6_band3 : bandStats 15793543 15804148 2166 596 = (21, -149792, -492) := by decide +kernel
theorem a101_0_6_band4 : bandStats 15793543 15804148 2762 497 = (75, 256954, -461) := by decide +kernel
theorem a101_0_6_band5 : bandStats 15793543 15804148 3259 373 = (-13, -178829, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
