import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_3_band5 : bandStats 15761460 15772464 3184 383 = (-64, -320442, -527) := by decide +kernel
theorem a101_0_3_band6 : bandStats 15761460 15772464 3567 262 = (-73, -457119, -536) := by decide +kernel
theorem a101_0_3_band7 : bandStats 15761460 15772464 3829 128 = (-32, -120882, -512) := by decide +kernel
theorem a101_0_3_band8 : bandStats 15761460 15772464 3957 14 = (-64, -257709, -254) := by decide +kernel

end QuarticKernel.KernelPrefixes
