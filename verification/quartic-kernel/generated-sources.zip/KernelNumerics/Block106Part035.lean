import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_0_band2 : bandStats 16737643 16748999 1448 665 = (-8, -70289, -502) := by decide +kernel
theorem a106_1_0_band3 : bandStats 16737643 16748999 2113 593 = (-2, -50448, -493) := by decide +kernel
theorem a106_1_0_band4 : bandStats 16737643 16748999 2706 508 = (-44, -302261, -519) := by decide +kernel
theorem a106_1_0_band5 : bandStats 16737643 16748999 3214 401 = (-43, -238106, -519) := by decide +kernel

end QuarticKernel.KernelPrefixes
