import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_10_band6 : bandStats 16506384 16517464 3636 270 = (2, 151500, -494) := by decide +kernel
theorem a105_0_10_band7 : bandStats 16506384 16517464 3906 139 = (-38, -193217, -514) := by decide +kernel
theorem a105_0_10_band8 : bandStats 16506384 16517464 4045 19 = (15, 8682, -252) := by decide +kernel
theorem a105_0_11_band0 : bandStats 16517464 16528585 0 744 = (6, 90486, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
