import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_12_band4 : bandStats 16357993 16369161 2712 500 = (5, 55872, -495) := by decide +kernel
theorem a104_0_12_band5 : bandStats 16357993 16369161 3212 396 = (11, 101950, -493) := by decide +kernel
theorem a104_0_12_band6 : bandStats 16357993 16369161 3608 272 = (11, 116551, -495) := by decide +kernel
theorem a104_0_12_band7 : bandStats 16357993 16369161 3880 142 = (29, 282323, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
