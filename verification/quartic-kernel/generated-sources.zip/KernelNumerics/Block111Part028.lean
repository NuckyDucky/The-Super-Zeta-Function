import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_11_band2 : bandStats 17625544 17638201 1345 626 = (-22, -142706, -510) := by decide +kernel
theorem a111_0_11_band3 : bandStats 17625544 17638201 1971 572 = (-37, -255835, -519) := by decide +kernel
theorem a111_0_11_band4 : bandStats 17625544 17638201 2543 506 = (-15, 166110, -511) := by decide +kernel
theorem a111_0_11_band5 : bandStats 17625544 17638201 3049 426 = (-13, -108318, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
