import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_3_band2 : bandStats 17345295 17358249 1289 603 = (33, -35211, -481) := by decide +kernel
theorem a110_0_3_band3 : bandStats 17345295 17358249 1892 566 = (-38, -307997, -520) := by decide +kernel
theorem a110_0_3_band4 : bandStats 17345295 17358249 2458 493 = (-24, -102071, -513) := by decide +kernel
theorem a110_0_3_band5 : bandStats 17345295 17358249 2951 425 = (33, 281483, -483) := by decide +kernel

end QuarticKernel.KernelPrefixes
