import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_2_band0 : bandStats 17332417 17345295 0 664 = (-1, -78791, -497) := by decide +kernel
theorem a110_0_2_band1 : bandStats 17332417 17345295 664 643 = (-32, -136274, -513) := by decide +kernel
theorem a110_0_2_band2 : bandStats 17332417 17345295 1307 614 = (5, 175505, -498) := by decide +kernel
theorem a110_0_2_band3 : bandStats 17332417 17345295 1921 558 = (-6, 39172, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
