import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_13_band2 : bandStats 16933903 16946248 1333 631 = (-13, -183193, -505) := by decide +kernel
theorem a107_0_13_band3 : bandStats 16933903 16946248 1964 572 = (-50, 5113, -526) := by decide +kernel
theorem a107_0_13_band4 : bandStats 16933903 16946248 2536 505 = (10, 151221, -496) := by decide +kernel
theorem a107_0_13_band5 : bandStats 16933903 16946248 3041 419 = (12, 122491, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
