import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_3_band1 : bandStats 16259233 16270272 749 715 = (9, 154508, -494) := by decide +kernel
theorem a104_0_3_band2 : bandStats 16259233 16270272 1464 670 = (6, -53973, -496) := by decide +kernel
theorem a104_0_3_band3 : bandStats 16259233 16270272 2134 594 = (-42, -201088, -525) := by decide +kernel
theorem a104_0_3_band4 : bandStats 16259233 16270272 2728 499 = (31, 261333, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
