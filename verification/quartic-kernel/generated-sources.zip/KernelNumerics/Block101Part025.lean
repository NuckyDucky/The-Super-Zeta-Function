import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_11_band1 : bandStats 15847153 15857980 735 728 = (16, 49968, -488) := by decide +kernel
theorem a101_0_11_band2 : bandStats 15847153 15857980 1463 671 = (39, 108753, -479) := by decide +kernel
theorem a101_0_11_band3 : bandStats 15847153 15857980 2134 594 = (26, 156106, -490) := by decide +kernel
theorem a101_0_11_band4 : bandStats 15847153 15857980 2728 494 = (-34, -12596, -516) := by decide +kernel

end QuarticKernel.KernelPrefixes
