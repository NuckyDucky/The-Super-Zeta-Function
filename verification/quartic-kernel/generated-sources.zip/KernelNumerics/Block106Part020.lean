import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_8_band7 : bandStats 16656209 16667484 3899 153 = (32, 103174, -478) := by decide +kernel
theorem a106_0_8_band8 : bandStats 16656209 16667484 4052 30 = (-24, -49997, -341) := by decide +kernel
theorem a106_0_9_band0 : bandStats 16667484 16678756 0 755 = (-21, -164650, -507) := by decide +kernel
theorem a106_0_9_band1 : bandStats 16667484 16678756 755 711 = (8, 108669, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
