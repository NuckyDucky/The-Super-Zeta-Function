import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_5_band0 : bandStats 16111484 16122599 0 720 = (1, -9853, -499) := by decide +kernel
theorem a103_0_5_band1 : bandStats 16111484 16122599 720 708 = (40, 460077, -479) := by decide +kernel
theorem a103_0_5_band2 : bandStats 16111484 16122599 1428 668 = (-36, -116243, -516) := by decide +kernel
theorem a103_0_5_band3 : bandStats 16111484 16122599 2096 591 = (-53, -332365, -519) := by decide +kernel

end QuarticKernel.KernelPrefixes
