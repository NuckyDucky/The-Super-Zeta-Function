import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_14_band7 : bandStats 16208675 16219809 3859 144 = (40, 114407, -474) := by decide +kernel
theorem a103_0_14_band8 : bandStats 16208675 16219809 4003 24 = (53, 341609, -278) := by decide +kernel
theorem a103_0_15_band0 : bandStats 16219809 16225300 0 1481 = (34, 131266, -480) := by decide +kernel
theorem a103_0_15_band1 : bandStats 16219809 16225300 1481 1258 = (-21, -57690, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
