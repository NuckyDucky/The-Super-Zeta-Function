import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_0_band0 : bandStats 15892481 15902992 0 782 = (4, 34108, -494) := by decide +kernel
theorem a102_0_0_band1 : bandStats 15892481 15902992 782 739 = (7, 48907, -495) := by decide +kernel
theorem a102_0_0_band2 : bandStats 15892481 15902992 1521 688 = (-41, -168834, -520) := by decide +kernel
theorem a102_0_0_band3 : bandStats 15892481 15902992 2209 598 = (37, 372622, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
