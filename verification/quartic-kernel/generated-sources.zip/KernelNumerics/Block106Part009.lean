import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_4_band0 : bandStats 16609849 16621161 0 748 = (84, 536206, -456) := by decide +kernel
theorem a106_0_4_band1 : bandStats 16609849 16621161 748 701 = (30, 276078, -483) := by decide +kernel
theorem a106_0_4_band2 : bandStats 16609849 16621161 1449 660 = (15, 69837, -490) := by decide +kernel
theorem a106_0_4_band3 : bandStats 16609849 16621161 2109 591 = (28, 300403, -487) := by decide +kernel

end QuarticKernel.KernelPrefixes
