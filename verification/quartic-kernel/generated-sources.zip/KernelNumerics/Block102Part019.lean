import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_8_band4 : bandStats 15977127 15987228 2888 496 = (34, 124575, -480) := by decide +kernel
theorem a102_0_8_band5 : bandStats 15977127 15987228 3384 358 = (1, 68685, -494) := by decide +kernel
theorem a102_0_8_band6 : bandStats 15977127 15987228 3742 207 = (17, 166842, -487) := by decide +kernel
theorem a102_0_8_band7 : bandStats 15977127 15987228 3949 49 = (36, 138929, -366) := by decide +kernel

end QuarticKernel.KernelPrefixes
