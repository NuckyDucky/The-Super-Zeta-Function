import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_2_band3 : bandStats 16078900 16089444 2201 606 = (66, 390625, -465) := by decide +kernel
theorem a103_0_2_band4 : bandStats 16078900 16089444 2807 498 = (16, 40989, -490) := by decide +kernel
theorem a103_0_2_band5 : bandStats 16078900 16089444 3305 376 = (26, 165631, -489) := by decide +kernel
theorem a103_0_2_band6 : bandStats 16078900 16089444 3681 237 = (6, 139295, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
