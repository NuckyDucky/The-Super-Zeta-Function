import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_0_band0 : bandStats 15728640 15739632 0 720 = (3, 30467, -499) := by decide +kernel
theorem a101_0_0_band1 : bandStats 15728640 15739632 720 708 = (-41, -210279, -514) := by decide +kernel
theorem a101_0_0_band2 : bandStats 15728640 15739632 1428 655 = (-3, 34329, -499) := by decide +kernel
theorem a101_0_0_band3 : bandStats 15728640 15739632 2083 588 = (6, -3257, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
