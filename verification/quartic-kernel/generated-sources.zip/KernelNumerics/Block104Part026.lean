import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_11_band5 : bandStats 16346796 16357993 3203 395 = (29, 70353, -481) := by decide +kernel
theorem a104_0_11_band6 : bandStats 16346796 16357993 3598 277 = (-55, -464043, -521) := by decide +kernel
theorem a104_0_11_band7 : bandStats 16346796 16357993 3875 145 = (19, -58518, -479) := by decide +kernel
theorem a104_0_11_band8 : bandStats 16346796 16357993 4020 24 = (1, -62601, -292) := by decide +kernel

end QuarticKernel.KernelPrefixes
