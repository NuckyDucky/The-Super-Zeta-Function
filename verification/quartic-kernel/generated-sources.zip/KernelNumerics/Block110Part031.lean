import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_12_band0 : bandStats 17462184 17475124 0 652 = (-15, -144870, -505) := by decide +kernel
theorem a110_0_12_band1 : bandStats 17462184 17475124 652 644 = (-39, -210505, -520) := by decide +kernel
theorem a110_0_12_band2 : bandStats 17462184 17475124 1296 604 = (-17, 3756, -506) := by decide +kernel
theorem a110_0_12_band3 : bandStats 17462184 17475124 1900 561 = (0, 101966, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
