import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_9_band0 : bandStats 16154608 16165384 0 763 = (-49, -280950, -524) := by decide +kernel
theorem a103_0_9_band1 : bandStats 16154608 16165384 763 721 = (23, 194997, -486) := by decide +kernel
theorem a103_0_9_band2 : bandStats 16154608 16165384 1484 678 = (-24, 91384, -511) := by decide +kernel
theorem a103_0_9_band3 : bandStats 16154608 16165384 2162 600 = (-61, -354904, -534) := by decide +kernel

end QuarticKernel.KernelPrefixes
