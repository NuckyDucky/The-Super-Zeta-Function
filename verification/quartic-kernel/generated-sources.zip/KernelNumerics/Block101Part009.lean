import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_4_band0 : bandStats 15772464 15783064 0 773 = (-3, 87020, -501) := by decide +kernel
theorem a101_0_4_band1 : bandStats 15772464 15783064 773 726 = (-10, -32911, -502) := by decide +kernel
theorem a101_0_4_band2 : bandStats 15772464 15783064 1499 678 = (-22, -152590, -510) := by decide +kernel
theorem a101_0_4_band3 : bandStats 15772464 15783064 2177 600 = (-52, -314943, -525) := by decide +kernel

end QuarticKernel.KernelPrefixes
