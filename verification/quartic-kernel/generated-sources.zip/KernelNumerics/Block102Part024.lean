import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_11_band0 : bandStats 16007539 16017769 0 775 = (21, 225141, -486) := by decide +kernel
theorem a102_0_11_band1 : bandStats 16007539 16017769 775 762 = (20, 28296, -489) := by decide +kernel
theorem a102_0_11_band2 : bandStats 16007539 16017769 1537 705 = (23, 137592, -488) := by decide +kernel
theorem a102_0_11_band3 : bandStats 16007539 16017769 2242 629 = (-1, 55525, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
