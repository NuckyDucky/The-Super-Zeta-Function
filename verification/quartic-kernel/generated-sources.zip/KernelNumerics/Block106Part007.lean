import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_3_band1 : bandStats 16598631 16609849 737 722 = (0, -162435, -498) := by decide +kernel
theorem a106_0_3_band2 : bandStats 16598631 16609849 1459 662 = (6, 73667, -494) := by decide +kernel
theorem a106_0_3_band3 : bandStats 16598631 16609849 2121 600 = (34, 256080, -483) := by decide +kernel
theorem a106_0_3_band4 : bandStats 16598631 16609849 2721 506 = (-13, -134990, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
