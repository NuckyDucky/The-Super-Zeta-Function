import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_11_band1 : bandStats 16346796 16357993 735 718 = (-50, -364679, -518) := by decide +kernel
theorem a104_0_11_band2 : bandStats 16346796 16357993 1453 663 = (27, 354692, -484) := by decide +kernel
theorem a104_0_11_band3 : bandStats 16346796 16357993 2116 589 = (21, 66760, -491) := by decide +kernel
theorem a104_0_11_band4 : bandStats 16346796 16357993 2705 498 = (33, 41266, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
