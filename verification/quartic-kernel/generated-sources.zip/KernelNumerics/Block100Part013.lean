import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_5_band7 : bandStats 15676449 15687521 3812 131 = (8, 8028, -492) := by decide +kernel
theorem a100_0_5_band8 : bandStats 15676449 15687521 3943 17 = (-8, -43519, -245) := by decide +kernel
theorem a100_0_6_band0 : bandStats 15687521 15698545 0 727 = (-11, -33174, -503) := by decide +kernel
theorem a100_0_6_band1 : bandStats 15687521 15698545 727 699 = (-12, -187227, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
