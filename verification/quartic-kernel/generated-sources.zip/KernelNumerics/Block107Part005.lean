import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_2_band0 : bandStats 16800999 16812961 0 686 = (24, 89362, -487) := by decide +kernel
theorem a107_0_2_band1 : bandStats 16800999 16812961 686 675 = (0, 95484, -502) := by decide +kernel
theorem a107_0_2_band2 : bandStats 16800999 16812961 1361 642 = (-29, -252769, -514) := by decide +kernel
theorem a107_0_2_band3 : bandStats 16800999 16812961 2003 580 = (7, 84750, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
