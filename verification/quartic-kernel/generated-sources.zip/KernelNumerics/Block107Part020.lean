import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_8_band0 : bandStats 16872697 16884841 0 690 = (33, 90899, -482) := by decide +kernel
theorem a107_0_8_band1 : bandStats 16872697 16884841 690 666 = (-15, -109060, -510) := by decide +kernel
theorem a107_0_8_band2 : bandStats 16872697 16884841 1356 622 = (10, 182147, -493) := by decide +kernel
theorem a107_0_8_band3 : bandStats 16872697 16884841 1978 582 = (-29, -143652, -515) := by decide +kernel

end QuarticKernel.KernelPrefixes
