import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_6_band8 : bandStats 17204380 17217044 3980 135 = (43, 383845, -468) := by decide +kernel
theorem a109_0_6_band9 : bandStats 17204380 17217044 4115 34 = (-33, -231405, -413) := by decide +kernel
theorem a109_0_7_band0 : bandStats 17217044 17229732 0 676 = (16, 197847, -491) := by decide +kernel
theorem a109_0_7_band1 : bandStats 17217044 17229732 676 649 = (23, 353562, -486) := by decide +kernel

end QuarticKernel.KernelPrefixes
