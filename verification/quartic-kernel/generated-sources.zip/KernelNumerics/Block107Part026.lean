import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_10_band4 : bandStats 16896999 16909172 2555 503 = (14, 20729, -486) := by decide +kernel
theorem a107_0_10_band5 : bandStats 16896999 16909172 3058 411 = (1, -132536, -497) := by decide +kernel
theorem a107_0_10_band6 : bandStats 16896999 16909172 3469 323 = (-55, -433169, -527) := by decide +kernel
theorem a107_0_10_band7 : bandStats 16896999 16909172 3792 211 = (25, 211249, -487) := by decide +kernel

end QuarticKernel.KernelPrefixes
