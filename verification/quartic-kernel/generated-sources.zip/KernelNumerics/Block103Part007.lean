import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_3_band2 : bandStats 16089444 16100284 1485 673 = (67, 427406, -465) := by decide +kernel
theorem a103_0_3_band3 : bandStats 16089444 16100284 2158 596 = (-20, -69543, -512) := by decide +kernel
theorem a103_0_3_band4 : bandStats 16089444 16100284 2754 495 = (63, 317508, -467) := by decide +kernel
theorem a103_0_3_band5 : bandStats 16089444 16100284 3249 385 = (-10, -32070, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
