import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_13_band6 : bandStats 16712356 16723764 3592 289 = (42, 283037, -478) := by decide +kernel
theorem a106_0_13_band7 : bandStats 16712356 16723764 3881 167 = (-89, -593071, -543) := by decide +kernel
theorem a106_0_13_band8 : bandStats 16712356 16723764 4048 41 = (-1, 152963, -389) := by decide +kernel
theorem a106_0_14_band0 : bandStats 16723764 16735292 0 736 = (-66, -299470, -531) := by decide +kernel

end QuarticKernel.KernelPrefixes
