import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_3_band6 : bandStats 16089444 16100284 3634 255 = (74, 350772, -458) := by decide +kernel
theorem a103_0_3_band7 : bandStats 16089444 16100284 3889 115 = (14, 113630, -483) := by decide +kernel
theorem a103_0_3_band8 : bandStats 16089444 16100284 4004 8 = (21, -18388, -149) := by decide +kernel
theorem a103_0_4_band0 : bandStats 16100284 16111484 0 743 = (4, 92464, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
