import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_12_band0 : bandStats 16357993 16369161 0 747 = (-31, -52026, -513) := by decide +kernel
theorem a104_0_12_band1 : bandStats 16357993 16369161 747 704 = (13, 35616, -494) := by decide +kernel
theorem a104_0_12_band2 : bandStats 16357993 16369161 1451 667 = (76, 586921, -461) := by decide +kernel
theorem a104_0_12_band3 : bandStats 16357993 16369161 2118 594 = (-22, -27771, -514) := by decide +kernel

end QuarticKernel.KernelPrefixes
