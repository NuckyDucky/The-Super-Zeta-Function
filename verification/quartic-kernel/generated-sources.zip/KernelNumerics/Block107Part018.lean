import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_7_band2 : bandStats 16860752 16872697 1381 645 = (23, 62004, -486) := by decide +kernel
theorem a107_0_7_band3 : bandStats 16860752 16872697 2026 573 = (14, 138243, -494) := by decide +kernel
theorem a107_0_7_band4 : bandStats 16860752 16872697 2599 501 = (3, -1421, -497) := by decide +kernel
theorem a107_0_7_band5 : bandStats 16860752 16872697 3100 411 = (37, 328030, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
