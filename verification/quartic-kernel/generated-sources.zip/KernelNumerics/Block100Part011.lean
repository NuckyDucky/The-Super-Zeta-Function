import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_4_band8 : bandStats 15665545 15676449 3948 11 = (12, 68300, -197) := by decide +kernel
theorem a100_0_5_band0 : bandStats 15676449 15687521 0 734 = (-6, -55568, -503) := by decide +kernel
theorem a100_0_5_band1 : bandStats 15676449 15687521 734 706 = (-7, -40161, -501) := by decide +kernel
theorem a100_0_5_band2 : bandStats 15676449 15687521 1440 654 = (-2, 166424, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
