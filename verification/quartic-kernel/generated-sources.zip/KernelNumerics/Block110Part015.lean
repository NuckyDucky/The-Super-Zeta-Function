import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_6_band0 : bandStats 17384116 17396999 0 675 = (9, 59062, -494) := by decide +kernel
theorem a110_0_6_band1 : bandStats 17384116 17396999 675 639 = (33, 458794, -481) := by decide +kernel
theorem a110_0_6_band2 : bandStats 17384116 17396999 1314 609 = (10, 60530, -495) := by decide +kernel
theorem a110_0_6_band3 : bandStats 17384116 17396999 1923 561 = (-2, -53561, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
