import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_0_band0 : bandStats 17669428 17681689 0 711 = (41, 204016, -476) := by decide +kernel
theorem a112_0_0_band1 : bandStats 17669428 17681689 711 675 = (-38, -418905, -515) := by decide +kernel
theorem a112_0_0_band2 : bandStats 17669428 17681689 1386 641 = (15, -110502, -489) := by decide +kernel
theorem a112_0_0_band3 : bandStats 17669428 17681689 2027 583 = (15, 358157, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
