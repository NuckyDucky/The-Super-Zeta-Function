import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_1_band6 : bandStats 16964289 16976284 3509 314 = (15, -19419, -491) := by decide +kernel
theorem a108_0_1_band7 : bandStats 16964289 16976284 3823 204 = (-9, 69118, -502) := by decide +kernel
theorem a108_0_1_band8 : bandStats 16964289 16976284 4027 88 = (50, 123510, -470) := by decide +kernel
theorem a108_0_1_band9 : bandStats 16964289 16976284 4115 5 = (-3, 79672, -137) := by decide +kernel

end QuarticKernel.KernelPrefixes
