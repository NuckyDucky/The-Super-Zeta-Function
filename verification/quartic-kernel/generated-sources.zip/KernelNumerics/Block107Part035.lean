import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_14_band0 : bandStats 16946248 16951979 0 1446 = (-28, -100352, -513) := by decide +kernel
theorem a107_0_14_band1 : bandStats 16946248 16951979 1446 1233 = (33, 129161, -479) := by decide +kernel
theorem a107_0_14_band2 : bandStats 16946248 16951979 2679 914 = (-13, 26474, -504) := by decide +kernel
theorem a107_0_14_band3 : bandStats 16946248 16951979 3593 474 = (1, 17626, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
