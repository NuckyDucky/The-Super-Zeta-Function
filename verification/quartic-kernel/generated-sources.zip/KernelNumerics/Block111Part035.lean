import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_14_band0 : bandStats 17663080 17669428 0 1327 = (-47, -83946, -525) := by decide +kernel
theorem a111_0_14_band1 : bandStats 17663080 17669428 1327 1205 = (25, 21351, -487) := by decide +kernel
theorem a111_0_14_band2 : bandStats 17663080 17669428 2532 937 = (-64, -104882, -533) := by decide +kernel
theorem a111_0_14_band3 : bandStats 17663080 17669428 3469 577 = (-23, -102521, -514) := by decide +kernel

end QuarticKernel.KernelPrefixes
