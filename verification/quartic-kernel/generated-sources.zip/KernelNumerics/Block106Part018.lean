import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_7_band8 : bandStats 16644624 16656209 4033 48 = (-35, -132645, -452) := by decide +kernel
theorem a106_0_8_band0 : bandStats 16656209 16667484 0 740 = (-12, -88603, -506) := by decide +kernel
theorem a106_0_8_band1 : bandStats 16656209 16667484 740 709 = (37, 258304, -480) := by decide +kernel
theorem a106_0_8_band2 : bandStats 16656209 16667484 1449 668 = (-18, -183952, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
