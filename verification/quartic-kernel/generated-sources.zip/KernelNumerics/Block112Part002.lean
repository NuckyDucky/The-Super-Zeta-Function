import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_0_band8 : bandStats 17669428 17681689 4090 104 = (2, 135365, -497) := by decide +kernel
theorem a112_0_0_band9 : bandStats 17669428 17681689 4194 10 = (18, 79380, -184) := by decide +kernel
theorem a112_0_1_band0 : bandStats 17681689 17693964 0 685 = (-50, -258097, -521) := by decide +kernel
theorem a112_0_1_band1 : bandStats 17681689 17693964 685 682 = (38, 162914, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
