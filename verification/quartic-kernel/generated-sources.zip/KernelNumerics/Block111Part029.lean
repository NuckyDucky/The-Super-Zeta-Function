import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_11_band6 : bandStats 17625544 17638201 3475 335 = (-33, -346005, -514) := by decide +kernel
theorem a111_0_11_band7 : bandStats 17625544 17638201 3810 235 = (-16, -188655, -508) := by decide +kernel
theorem a111_0_11_band8 : bandStats 17625544 17638201 4045 128 = (4, -12070, -494) := by decide +kernel
theorem a111_0_11_band9 : bandStats 17625544 17638201 4173 26 = (31, 46729, -320) := by decide +kernel

end QuarticKernel.KernelPrefixes
