import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_14_band6 : bandStats 15879689 15890404 3624 250 = (-5, -41692, -498) := by decide +kernel
theorem a101_0_14_band7 : bandStats 15879689 15890404 3874 106 = (-72, -462042, -520) := by decide +kernel
theorem a101_0_14_band8 : bandStats 15879689 15890404 3980 6 = (-9, -20795, -147) := by decide +kernel
theorem a101_0_15_band0 : bandStats 15890404 15892481 0 3330 = (-69, -88701, -535) := by decide +kernel

end QuarticKernel.KernelPrefixes
