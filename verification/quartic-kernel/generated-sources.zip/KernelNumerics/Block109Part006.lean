import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_2_band4 : bandStats 17153620 17166439 2465 496 = (-22, -77184, -506) := by decide +kernel
theorem a109_0_2_band5 : bandStats 17153620 17166439 2961 422 = (-17, -193987, -506) := by decide +kernel
theorem a109_0_2_band6 : bandStats 17153620 17166439 3383 337 = (-10, -47154, -504) := by decide +kernel
theorem a109_0_2_band7 : bandStats 17153620 17166439 3720 242 = (-36, -183235, -519) := by decide +kernel

end QuarticKernel.KernelPrefixes
