import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_14_band3 : bandStats 16208675 16219809 2096 592 = (-38, -170729, -521) := by decide +kernel
theorem a103_0_14_band4 : bandStats 16208675 16219809 2688 500 = (29, -69430, -484) := by decide +kernel
theorem a103_0_14_band5 : bandStats 16208675 16219809 3188 395 = (0, 13479, -500) := by decide +kernel
theorem a103_0_14_band6 : bandStats 16208675 16219809 3583 276 = (11, 45290, -490) := by decide +kernel

end QuarticKernel.KernelPrefixes
