import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_12_band8 : bandStats 17462184 17475124 3980 151 = (-23, -103615, -509) := by decide +kernel
theorem a110_0_12_band9 : bandStats 17462184 17475124 4131 49 = (6, 10388, -477) := by decide +kernel
theorem a110_0_13_band0 : bandStats 17475124 17487268 0 710 = (-20, -12086, -509) := by decide +kernel
theorem a110_0_13_band1 : bandStats 17475124 17487268 710 690 = (-8, -207982, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
