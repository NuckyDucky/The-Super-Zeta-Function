import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_10_band6 : bandStats 17436003 17449008 3380 341 = (0, -35261, -499) := by decide +kernel
theorem a110_0_10_band7 : bandStats 17436003 17449008 3721 250 = (-6, 145140, -502) := by decide +kernel
theorem a110_0_10_band8 : bandStats 17436003 17449008 3971 153 = (-40, -113913, -515) := by decide +kernel
theorem a110_0_10_band9 : bandStats 17436003 17449008 4124 52 = (48, 456168, -463) := by decide +kernel

end QuarticKernel.KernelPrefixes
