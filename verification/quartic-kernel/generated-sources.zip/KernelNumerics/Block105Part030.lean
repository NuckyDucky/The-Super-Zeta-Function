import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_13_band3 : bandStats 16539939 16551180 2099 600 = (9, 22678, -491) := by decide +kernel
theorem a105_0_13_band4 : bandStats 16539939 16551180 2699 507 = (19, 34249, -489) := by decide +kernel
theorem a105_0_13_band5 : bandStats 16539939 16551180 3206 402 = (-33, -178794, -514) := by decide +kernel
theorem a105_0_13_band6 : bandStats 16539939 16551180 3608 278 = (16, 57384, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
