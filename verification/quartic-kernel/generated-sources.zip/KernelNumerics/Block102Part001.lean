import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_0_band4 : bandStats 15892481 15902992 2807 493 = (-19, -31715, -508) := by decide +kernel
theorem a102_0_0_band5 : bandStats 15892481 15902992 3300 372 = (-19, -184618, -508) := by decide +kernel
theorem a102_0_0_band6 : bandStats 15892481 15902992 3672 230 = (24, 268220, -485) := by decide +kernel
theorem a102_0_0_band7 : bandStats 15892481 15902992 3902 84 = (4, 47339, -483) := by decide +kernel

end QuarticKernel.KernelPrefixes
