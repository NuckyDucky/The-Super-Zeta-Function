import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_2_band6 : bandStats 15913464 15924100 3647 241 = (-30, -286033, -515) := by decide +kernel
theorem a102_0_2_band7 : bandStats 15913464 15924100 3888 98 = (15, 110602, -473) := by decide +kernel
theorem a102_0_2_band8 : bandStats 15913464 15924100 3986 4 = (4, 37892, -104) := by decide +kernel
theorem a102_0_3_band0 : bandStats 15924100 15934641 0 781 = (2, -86412, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
