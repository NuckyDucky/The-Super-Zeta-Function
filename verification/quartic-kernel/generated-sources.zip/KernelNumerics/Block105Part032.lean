import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_14_band2 : bandStats 16551180 16562465 1454 659 = (34, 113189, -482) := by decide +kernel
theorem a105_0_14_band3 : bandStats 16551180 16562465 2113 589 = (-41, -314534, -519) := by decide +kernel
theorem a105_0_14_band4 : bandStats 16551180 16562465 2702 500 = (19, 138651, -490) := by decide +kernel
theorem a105_0_14_band5 : bandStats 16551180 16562465 3202 399 = (-5, -41908, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
