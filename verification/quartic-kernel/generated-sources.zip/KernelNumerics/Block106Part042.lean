import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_3_band3 : bandStats 16771524 16777216 3639 430 = (-22, -60061, -510) := by decide +kernel
theorem a106_1_3_band4 : bandStats 16771524 16777216 4069 27 = (24, 58417, -132) := by decide +kernel

end QuarticKernel.KernelPrefixes
