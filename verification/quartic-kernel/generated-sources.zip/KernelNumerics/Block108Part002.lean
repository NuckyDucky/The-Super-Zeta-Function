import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_0_band8 : bandStats 16951979 16964289 4004 103 = (17, 315392, -485) := by decide +kernel
theorem a108_0_0_band9 : bandStats 16951979 16964289 4107 11 = (-20, -46342, -218) := by decide +kernel
theorem a108_0_1_band0 : bandStats 16964289 16976284 0 690 = (3, 173960, -497) := by decide +kernel
theorem a108_0_1_band1 : bandStats 16964289 16976284 690 678 = (14, 6532, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
