import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_7_band6 : bandStats 17217044 17229732 3413 334 = (12, -19928, -494) := by decide +kernel
theorem a109_0_7_band7 : bandStats 17217044 17229732 3747 236 = (34, 216255, -479) := by decide +kernel
theorem a109_0_7_band8 : bandStats 17217044 17229732 3983 135 = (73, 417973, -460) := by decide +kernel
theorem a109_0_7_band9 : bandStats 17217044 17229732 4118 32 = (-15, -276692, -385) := by decide +kernel

end QuarticKernel.KernelPrefixes
