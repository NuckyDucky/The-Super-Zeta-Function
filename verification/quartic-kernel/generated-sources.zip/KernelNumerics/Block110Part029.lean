import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_11_band3 : bandStats 17449008 17462184 1886 556 = (7, 23331, -496) := by decide +kernel
theorem a110_0_11_band4 : bandStats 17449008 17462184 2442 495 = (11, -14750, -494) := by decide +kernel
theorem a110_0_11_band5 : bandStats 17449008 17462184 2937 427 = (-15, -215907, -506) := by decide +kernel
theorem a110_0_11_band6 : bandStats 17449008 17462184 3364 343 = (-24, -96931, -509) := by decide +kernel

end QuarticKernel.KernelPrefixes
