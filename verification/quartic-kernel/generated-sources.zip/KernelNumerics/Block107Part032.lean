import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_12_band8 : bandStats 16921377 16933903 3974 120 = (-41, -184551, -519) := by decide +kernel
theorem a107_0_12_band9 : bandStats 16921377 16933903 4094 21 = (10, -144201, -295) := by decide +kernel
theorem a107_0_13_band0 : bandStats 16933903 16946248 0 678 = (24, 75183, -488) := by decide +kernel
theorem a107_0_13_band1 : bandStats 16933903 16946248 678 655 = (-7, 112212, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
