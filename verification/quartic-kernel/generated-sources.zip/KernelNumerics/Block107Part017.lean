import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_6_band8 : bandStats 16848744 16860752 4015 86 = (-10, -8470, -494) := by decide +kernel
theorem a107_0_6_band9 : bandStats 16848744 16860752 4101 5 = (8, -13416, -129) := by decide +kernel
theorem a107_0_7_band0 : bandStats 16860752 16872697 0 702 = (25, -26928, -488) := by decide +kernel
theorem a107_0_7_band1 : bandStats 16860752 16872697 702 679 = (17, 174978, -486) := by decide +kernel

end QuarticKernel.KernelPrefixes
