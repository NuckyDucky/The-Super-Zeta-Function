import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_6_band2 : bandStats 15955864 15966616 1496 676 = (-55, -252264, -528) := by decide +kernel
theorem a102_0_6_band3 : bandStats 15955864 15966616 2172 593 = (35, 246756, -478) := by decide +kernel
theorem a102_0_6_band4 : bandStats 15955864 15966616 2765 502 = (-6, 470, -504) := by decide +kernel
theorem a102_0_6_band5 : bandStats 15955864 15966616 3267 376 = (-45, -226562, -516) := by decide +kernel

end QuarticKernel.KernelPrefixes
