import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_12_band5 : bandStats 16186753 16197641 3258 385 = (8, -15923, -492) := by decide +kernel
theorem a103_0_12_band6 : bandStats 16186753 16197641 3643 255 = (44, 263293, -473) := by decide +kernel
theorem a103_0_12_band7 : bandStats 16186753 16197641 3898 118 = (12, 204561, -497) := by decide +kernel
theorem a103_0_12_band8 : bandStats 16186753 16197641 4016 8 = (-9, 23277, -162) := by decide +kernel

end QuarticKernel.KernelPrefixes
