import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_0_band4 : bandStats 16951979 16964289 2552 505 = (-44, -350641, -518) := by decide +kernel
theorem a108_0_0_band5 : bandStats 16951979 16964289 3057 415 = (-48, -283088, -524) := by decide +kernel
theorem a108_0_0_band6 : bandStats 16951979 16964289 3472 321 = (-29, -171902, -511) := by decide +kernel
theorem a108_0_0_band7 : bandStats 16951979 16964289 3793 211 = (-3, -138664, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
