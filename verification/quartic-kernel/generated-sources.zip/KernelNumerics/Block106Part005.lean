import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_2_band2 : bandStats 16587505 16598631 1458 671 = (-5, -156417, -501) := by decide +kernel
theorem a106_0_2_band3 : bandStats 16587505 16598631 2129 597 = (-16, -186139, -504) := by decide +kernel
theorem a106_0_2_band4 : bandStats 16587505 16598631 2726 506 = (-13, 15754, -504) := by decide +kernel
theorem a106_0_2_band5 : bandStats 16587505 16598631 3232 398 = (24, 176070, -486) := by decide +kernel

end QuarticKernel.KernelPrefixes
