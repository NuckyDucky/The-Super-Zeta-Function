import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_0_band4 : bandStats 17306986 17319507 2532 503 = (48, 207477, -478) := by decide +kernel
theorem a110_0_0_band5 : bandStats 17306986 17319507 3035 421 = (24, 212731, -484) := by decide +kernel
theorem a110_0_0_band6 : bandStats 17306986 17319507 3456 331 = (17, 10390, -486) := by decide +kernel
theorem a110_0_0_band7 : bandStats 17306986 17319507 3787 229 = (40, 141555, -476) := by decide +kernel

end QuarticKernel.KernelPrefixes
