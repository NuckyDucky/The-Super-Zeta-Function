import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_4_band0 : bandStats 16824831 16836576 0 700 = (44, 75951, -476) := by decide +kernel
theorem a107_0_4_band1 : bandStats 16824831 16836576 700 691 = (32, 102240, -484) := by decide +kernel
theorem a107_0_4_band2 : bandStats 16824831 16836576 1391 638 = (63, 259460, -466) := by decide +kernel
theorem a107_0_4_band3 : bandStats 16824831 16836576 2029 589 = (-15, -253411, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
