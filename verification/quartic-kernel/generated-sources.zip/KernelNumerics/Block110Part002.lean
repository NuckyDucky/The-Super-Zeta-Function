import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_0_band8 : bandStats 17306986 17319507 4016 123 = (10, 148985, -491) := by decide +kernel
theorem a110_0_0_band9 : bandStats 17306986 17319507 4139 22 = (37, 438137, -287) := by decide +kernel
theorem a110_0_1_band0 : bandStats 17319507 17332417 0 656 = (5, 92651, -497) := by decide +kernel
theorem a110_0_1_band1 : bandStats 17319507 17332417 656 641 = (-33, -61808, -517) := by decide +kernel

end QuarticKernel.KernelPrefixes
