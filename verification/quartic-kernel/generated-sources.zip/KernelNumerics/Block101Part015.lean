import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_6_band6 : bandStats 15793543 15804148 3632 240 = (-48, -394349, -518) := by decide +kernel
theorem a101_0_6_band7 : bandStats 15793543 15804148 3872 100 = (-18, -40326, -510) := by decide +kernel
theorem a101_0_6_band8 : bandStats 15793543 15804148 3972 3 = (-1, -40643, -90) := by decide +kernel
theorem a101_0_7_band0 : bandStats 15804148 15814849 0 767 = (-35, -139754, -516) := by decide +kernel

end QuarticKernel.KernelPrefixes
