import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_13_band3 : bandStats 15868835 15879689 2144 590 = (-33, -324828, -514) := by decide +kernel
theorem a101_0_13_band4 : bandStats 15868835 15879689 2734 495 = (-16, -173998, -507) := by decide +kernel
theorem a101_0_13_band5 : bandStats 15868835 15879689 3229 378 = (5, -2793, -497) := by decide +kernel
theorem a101_0_13_band6 : bandStats 15868835 15879689 3607 253 = (13, -1521, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
