import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_2_band2 : bandStats 16247920 16259233 1409 657 = (-30, -231878, -511) := by decide +kernel
theorem a104_0_2_band3 : bandStats 16247920 16259233 2066 590 = (-65, -349665, -535) := by decide +kernel
theorem a104_0_2_band4 : bandStats 16247920 16259233 2656 503 = (-27, -209235, -511) := by decide +kernel
theorem a104_0_2_band5 : bandStats 16247920 16259233 3159 399 = (-59, -401873, -526) := by decide +kernel

end QuarticKernel.KernelPrefixes
