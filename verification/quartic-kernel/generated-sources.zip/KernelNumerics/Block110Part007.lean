import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_2_band8 : bandStats 17332417 17345295 3983 142 = (57, 516347, -471) := by decide +kernel
theorem a110_0_2_band9 : bandStats 17332417 17345295 4125 39 = (-2, 68132, -429) := by decide +kernel
theorem a110_0_3_band0 : bandStats 17345295 17358249 0 651 = (40, 227542, -479) := by decide +kernel
theorem a110_0_3_band1 : bandStats 17345295 17358249 651 638 = (-23, -116679, -513) := by decide +kernel

end QuarticKernel.KernelPrefixes
