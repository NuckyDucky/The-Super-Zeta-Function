import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_8_band0 : bandStats 17051683 17064568 0 667 = (11, 306268, -493) := by decide +kernel
theorem a108_0_8_band1 : bandStats 17051683 17064568 667 632 = (-23, -76980, -509) := by decide +kernel
theorem a108_0_8_band2 : bandStats 17051683 17064568 1299 607 = (-2, 77906, -499) := by decide +kernel
theorem a108_0_8_band3 : bandStats 17051683 17064568 1906 555 = (-59, -322700, -529) := by decide +kernel

end QuarticKernel.KernelPrefixes
