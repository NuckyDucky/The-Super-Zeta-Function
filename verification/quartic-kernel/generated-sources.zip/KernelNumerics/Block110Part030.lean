import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_11_band7 : bandStats 17449008 17462184 3707 254 = (-47, -364901, -520) := by decide +kernel
theorem a110_0_11_band8 : bandStats 17449008 17462184 3961 157 = (-20, -160605, -504) := by decide +kernel
theorem a110_0_11_band9 : bandStats 17449008 17462184 4118 59 = (-24, -387876, -514) := by decide +kernel
theorem a110_0_11_band10 : bandStats 17449008 17462184 4177 1 = (3, 17854, -38) := by decide +kernel

end QuarticKernel.KernelPrefixes
