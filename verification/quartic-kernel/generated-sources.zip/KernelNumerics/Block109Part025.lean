import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_9_band10 : bandStats 17242627 17255744 4152 2 = (-2, -15936, -49) := by decide +kernel
theorem a109_0_10_band0 : bandStats 17255744 17268625 0 648 = (-32, -198872, -515) := by decide +kernel
theorem a109_0_10_band1 : bandStats 17255744 17268625 648 641 = (-47, -17962, -522) := by decide +kernel
theorem a109_0_10_band2 : bandStats 17255744 17268625 1289 609 = (3, 107808, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
