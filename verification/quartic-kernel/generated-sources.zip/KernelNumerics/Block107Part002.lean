import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_0_band8 : bandStats 16777216 16788905 4028 67 = (-7, -64243, -462) := by decide +kernel
theorem a107_0_0_band9 : bandStats 16777216 16788905 4095 2 = (9, 88715, -78) := by decide +kernel
theorem a107_0_1_band0 : bandStats 16788905 16800999 0 706 = (21, 151607, -489) := by decide +kernel
theorem a107_0_1_band1 : bandStats 16788905 16800999 706 671 = (-16, -170760, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
