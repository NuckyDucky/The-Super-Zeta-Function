import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_10_band0 : bandStats 16896999 16909172 0 688 = (-52, -302158, -524) := by decide +kernel
theorem a107_0_10_band1 : bandStats 16896999 16909172 688 664 = (11, 44750, -495) := by decide +kernel
theorem a107_0_10_band2 : bandStats 16896999 16909172 1352 635 = (-8, -69745, -504) := by decide +kernel
theorem a107_0_10_band3 : bandStats 16896999 16909172 1987 568 = (33, 106955, -475) := by decide +kernel

end QuarticKernel.KernelPrefixes
