import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_13_band0 : bandStats 16197641 16208675 0 755 = (33, 35282, -482) := by decide +kernel
theorem a103_0_13_band1 : bandStats 16197641 16208675 755 709 = (23, 62463, -487) := by decide +kernel
theorem a103_0_13_band2 : bandStats 16197641 16208675 1464 667 = (-16, -214090, -506) := by decide +kernel
theorem a103_0_13_band3 : bandStats 16197641 16208675 2131 598 = (7, 10733, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
