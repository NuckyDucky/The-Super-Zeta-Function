import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_3_band6 : bandStats 17525139 17537860 3445 332 = (-10, -196479, -502) := by decide +kernel
theorem a111_0_3_band7 : bandStats 17525139 17537860 3777 239 = (2, -14283, -495) := by decide +kernel
theorem a111_0_3_band8 : bandStats 17525139 17537860 4016 138 = (2, 39467, -499) := by decide +kernel
theorem a111_0_3_band9 : bandStats 17525139 17537860 4154 33 = (8, 17628, -377) := by decide +kernel

end QuarticKernel.KernelPrefixes
