import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_3_band5 : bandStats 16598631 16609849 3227 399 = (0, 70131, -499) := by decide +kernel
theorem a106_0_3_band6 : bandStats 16598631 16609849 3626 277 = (-23, -188486, -509) := by decide +kernel
theorem a106_0_3_band7 : bandStats 16598631 16609849 3903 147 = (57, 312190, -465) := by decide +kernel
theorem a106_0_3_band8 : bandStats 16598631 16609849 4050 25 = (7, 16545, -295) := by decide +kernel

end QuarticKernel.KernelPrefixes
