import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_13_band2 : bandStats 17650504 17663080 1352 629 = (-25, -179645, -510) := by decide +kernel
theorem a111_0_13_band3 : bandStats 17650504 17663080 1981 574 = (-27, -173942, -507) := by decide +kernel
theorem a111_0_13_band4 : bandStats 17650504 17663080 2555 506 = (-45, -392206, -521) := by decide +kernel
theorem a111_0_13_band5 : bandStats 17650504 17663080 3061 425 = (5, -90387, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
