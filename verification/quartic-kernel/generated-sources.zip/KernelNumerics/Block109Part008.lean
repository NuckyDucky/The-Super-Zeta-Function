import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_3_band2 : bandStats 17166439 17179180 1321 613 = (-21, -51794, -510) := by decide +kernel
theorem a109_0_3_band3 : bandStats 17166439 17179180 1934 564 = (15, 145968, -489) := by decide +kernel
theorem a109_0_3_band4 : bandStats 17166439 17179180 2498 499 = (-36, -346812, -512) := by decide +kernel
theorem a109_0_3_band5 : bandStats 17166439 17179180 2997 422 = (1, -62416, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
