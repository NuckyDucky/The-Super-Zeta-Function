import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_7_band6 : bandStats 17575617 17588209 3484 333 = (1, 230011, -496) := by decide +kernel
theorem a111_0_7_band7 : bandStats 17575617 17588209 3817 230 = (-28, -68784, -509) := by decide +kernel
theorem a111_0_7_band8 : bandStats 17575617 17588209 4047 124 = (50, 360741, -468) := by decide +kernel
theorem a111_0_7_band9 : bandStats 17575617 17588209 4171 22 = (22, 269319, -290) := by decide +kernel

end QuarticKernel.KernelPrefixes
