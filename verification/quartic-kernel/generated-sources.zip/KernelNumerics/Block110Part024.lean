import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_9_band5 : bandStats 17422924 17436003 2938 423 = (30, 315943, -483) := by decide +kernel
theorem a110_0_9_band6 : bandStats 17422924 17436003 3361 344 = (-48, -501248, -522) := by decide +kernel
theorem a110_0_9_band7 : bandStats 17422924 17436003 3705 254 = (2, 92126, -494) := by decide +kernel
theorem a110_0_9_band8 : bandStats 17422924 17436003 3959 157 = (-6, -208270, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
