import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_1_band4 : bandStats 16068483 16078900 2834 496 = (4, -17736, -496) := by decide +kernel
theorem a103_0_1_band5 : bandStats 16068483 16078900 3330 371 = (38, 181216, -474) := by decide +kernel
theorem a103_0_1_band6 : bandStats 16068483 16078900 3701 229 = (-3, 163761, -502) := by decide +kernel
theorem a103_0_1_band7 : bandStats 16068483 16078900 3930 78 = (-11, 16652, -466) := by decide +kernel

end QuarticKernel.KernelPrefixes
