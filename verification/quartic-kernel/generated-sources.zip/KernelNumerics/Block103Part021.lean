import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_9_band4 : bandStats 16154608 16165384 2762 509 = (6, 1049, -496) := by decide +kernel
theorem a103_0_9_band5 : bandStats 16154608 16165384 3271 381 = (-4, 106784, -499) := by decide +kernel
theorem a103_0_9_band6 : bandStats 16154608 16165384 3652 249 = (4, -95597, -497) := by decide +kernel
theorem a103_0_9_band7 : bandStats 16154608 16165384 3901 112 = (18, 93355, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
