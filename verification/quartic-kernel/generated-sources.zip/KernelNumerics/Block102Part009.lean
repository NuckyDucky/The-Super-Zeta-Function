import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_4_band0 : bandStats 15934641 15945249 0 758 = (-31, -68739, -512) := by decide +kernel
theorem a102_0_4_band1 : bandStats 15934641 15945249 758 737 = (54, 438582, -470) := by decide +kernel
theorem a102_0_4_band2 : bandStats 15934641 15945249 1495 684 = (-7, -130457, -503) := by decide +kernel
theorem a102_0_4_band3 : bandStats 15934641 15945249 2179 602 = (6, -59955, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
