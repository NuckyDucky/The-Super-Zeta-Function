import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_1_band6 : bandStats 17141056 17153620 3435 329 = (16, 56818, -487) := by decide +kernel
theorem a109_0_1_band7 : bandStats 17141056 17153620 3764 230 = (16, -33539, -490) := by decide +kernel
theorem a109_0_1_band8 : bandStats 17141056 17153620 3994 124 = (18, 410498, -491) := by decide +kernel
theorem a109_0_1_band9 : bandStats 17141056 17153620 4118 23 = (51, 337490, -290) := by decide +kernel

end QuarticKernel.KernelPrefixes
