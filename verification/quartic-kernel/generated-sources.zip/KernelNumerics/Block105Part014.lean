import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_6_band2 : bandStats 16461520 16472744 1459 668 = (-65, -194769, -530) := by decide +kernel
theorem a105_0_6_band3 : bandStats 16461520 16472744 2127 594 = (51, 105551, -477) := by decide +kernel
theorem a105_0_6_band4 : bandStats 16461520 16472744 2721 501 = (23, 146254, -487) := by decide +kernel
theorem a105_0_6_band5 : bandStats 16461520 16472744 3222 396 = (-31, -258282, -512) := by decide +kernel

end QuarticKernel.KernelPrefixes
