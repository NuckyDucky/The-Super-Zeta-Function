import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_1_2_band8 : bandStats 16760115 16771524 4055 40 = (49, 330479, -371) := by decide +kernel
theorem a106_1_3_band0 : bandStats 16771524 16777216 0 1484 = (-33, -64801, -517) := by decide +kernel
theorem a106_1_3_band1 : bandStats 16771524 16777216 1484 1261 = (37, 172056, -484) := by decide +kernel
theorem a106_1_3_band2 : bandStats 16771524 16777216 2745 894 = (14, 119387, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
