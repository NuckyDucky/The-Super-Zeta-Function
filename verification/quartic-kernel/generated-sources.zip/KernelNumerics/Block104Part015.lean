import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_6_band6 : bandStats 16292008 16302916 3647 259 = (-48, -376010, -523) := by decide +kernel
theorem a104_0_6_band7 : bandStats 16292008 16302916 3906 121 = (-6, -88075, -501) := by decide +kernel
theorem a104_0_6_band8 : bandStats 16292008 16302916 4027 10 = (-6, -79697, -181) := by decide +kernel
theorem a104_0_7_band0 : bandStats 16302916 16313785 0 758 = (-46, -237298, -521) := by decide +kernel

end QuarticKernel.KernelPrefixes
