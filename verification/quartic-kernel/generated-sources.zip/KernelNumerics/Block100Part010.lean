import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_4_band4 : bandStats 15665545 15676449 2694 492 = (26, 239646, -484) := by decide +kernel
theorem a100_0_4_band5 : bandStats 15665545 15676449 3186 383 = (55, 389401, -468) := by decide +kernel
theorem a100_0_4_band6 : bandStats 15665545 15676449 3569 257 = (-6, -80091, -500) := by decide +kernel
theorem a100_0_4_band7 : bandStats 15665545 15676449 3826 122 = (-33, -329502, -511) := by decide +kernel

end QuarticKernel.KernelPrefixes
