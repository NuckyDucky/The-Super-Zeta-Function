import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_0_band0 : bandStats 17487268 17499832 0 666 = (12, -133266, -493) := by decide +kernel
theorem a111_0_0_band1 : bandStats 17487268 17499832 666 657 = (-17, -108769, -507) := by decide +kernel
theorem a111_0_0_band2 : bandStats 17487268 17499832 1323 624 = (-25, -320549, -513) := by decide +kernel
theorem a111_0_0_band3 : bandStats 17487268 17499832 1947 576 = (-13, -115777, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
