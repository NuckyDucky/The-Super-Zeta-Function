import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_9_band2 : bandStats 17600724 17613139 1371 625 = (-5, 41011, -500) := by decide +kernel
theorem a111_0_9_band3 : bandStats 17600724 17613139 1996 580 = (-14, -15758, -505) := by decide +kernel
theorem a111_0_9_band4 : bandStats 17600724 17613139 2576 506 = (0, 21304, -499) := by decide +kernel
theorem a111_0_9_band5 : bandStats 17600724 17613139 3082 428 = (55, 370910, -471) := by decide +kernel

end QuarticKernel.KernelPrefixes
