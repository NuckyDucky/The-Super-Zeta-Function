import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_1_band2 : bandStats 17319507 17332417 1297 607 = (3, 205871, -497) := by decide +kernel
theorem a110_0_1_band3 : bandStats 17319507 17332417 1904 563 = (12, 232490, -494) := by decide +kernel
theorem a110_0_1_band4 : bandStats 17319507 17332417 2467 506 = (15, 114515, -482) := by decide +kernel
theorem a110_0_1_band5 : bandStats 17319507 17332417 2973 424 = (-2, 169435, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
