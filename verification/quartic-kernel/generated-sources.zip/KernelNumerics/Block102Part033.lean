import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_15_band4 : bandStats 16048564 16058028 3046 487 = (-24, -187659, -511) := by decide +kernel
theorem a102_0_15_band5 : bandStats 16048564 16058028 3533 322 = (37, 242329, -475) := by decide +kernel
theorem a102_0_15_band6 : bandStats 16048564 16058028 3855 143 = (25, 85533, -477) := by decide +kernel
theorem a102_0_15_band7 : bandStats 16048564 16058028 3998 9 = (14, 131661, -144) := by decide +kernel

end QuarticKernel.KernelPrefixes
