import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_2_band2 : bandStats 15643584 15654595 1447 657 = (-18, -72840, -507) := by decide +kernel
theorem a100_0_2_band3 : bandStats 15643584 15654595 2104 583 = (10, 174131, -498) := by decide +kernel
theorem a100_0_2_band4 : bandStats 15643584 15654595 2687 490 = (-67, -347455, -531) := by decide +kernel
theorem a100_0_2_band5 : bandStats 15643584 15654595 3177 379 = (72, 367344, -462) := by decide +kernel

end QuarticKernel.KernelPrefixes
