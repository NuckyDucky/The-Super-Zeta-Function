import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_8_band0 : bandStats 17409844 17422924 0 653 = (-5, 28051, -500) := by decide +kernel
theorem a110_0_8_band1 : bandStats 17409844 17422924 653 637 = (51, 343983, -474) := by decide +kernel
theorem a110_0_8_band2 : bandStats 17409844 17422924 1290 598 = (-61, -437578, -528) := by decide +kernel
theorem a110_0_8_band3 : bandStats 17409844 17422924 1888 560 = (1, 157067, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
