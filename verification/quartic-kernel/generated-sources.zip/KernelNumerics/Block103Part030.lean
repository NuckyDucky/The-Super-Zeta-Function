import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_13_band4 : bandStats 16197641 16208675 2729 501 = (41, 304467, -477) := by decide +kernel
theorem a103_0_13_band5 : bandStats 16197641 16208675 3230 388 = (11, 49300, -491) := by decide +kernel
theorem a103_0_13_band6 : bandStats 16197641 16208675 3618 262 = (7, 208168, -498) := by decide +kernel
theorem a103_0_13_band7 : bandStats 16197641 16208675 3880 130 = (68, 289475, -455) := by decide +kernel

end QuarticKernel.KernelPrefixes
