import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_7_band2 : bandStats 16133543 16144227 1515 678 = (-55, -284232, -527) := by decide +kernel
theorem a103_0_7_band3 : bandStats 16133543 16144227 2193 604 = (-26, 11962, -513) := by decide +kernel
theorem a103_0_7_band4 : bandStats 16133543 16144227 2797 501 = (16, 230898, -491) := by decide +kernel
theorem a103_0_7_band5 : bandStats 16133543 16144227 3298 376 = (-37, -176484, -515) := by decide +kernel

end QuarticKernel.KernelPrefixes
