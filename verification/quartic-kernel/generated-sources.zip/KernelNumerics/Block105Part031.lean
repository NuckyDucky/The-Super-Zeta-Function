import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_13_band7 : bandStats 16539939 16551180 3886 153 = (-36, -248229, -513) := by decide +kernel
theorem a105_0_13_band8 : bandStats 16539939 16551180 4039 29 = (13, 74427, -326) := by decide +kernel
theorem a105_0_14_band0 : bandStats 16551180 16562465 0 743 = (-39, -257214, -518) := by decide +kernel
theorem a105_0_14_band1 : bandStats 16551180 16562465 743 711 = (-35, -286668, -517) := by decide +kernel

end QuarticKernel.KernelPrefixes
