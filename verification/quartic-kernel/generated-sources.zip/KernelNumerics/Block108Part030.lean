import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_12_band0 : bandStats 17102424 17115156 0 669 = (-10, -81243, -503) := by decide +kernel
theorem a108_0_12_band1 : bandStats 17102424 17115156 669 644 = (-50, -357118, -524) := by decide +kernel
theorem a108_0_12_band2 : bandStats 17102424 17115156 1313 614 = (-9, -202939, -503) := by decide +kernel
theorem a108_0_12_band3 : bandStats 17102424 17115156 1927 557 = (-20, -166776, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
