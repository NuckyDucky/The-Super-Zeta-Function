import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_12_band8 : bandStats 17638201 17650504 4070 115 = (-10, -182133, -506) := by decide +kernel
theorem a111_0_12_band9 : bandStats 17638201 17650504 4185 16 = (6, 188584, -257) := by decide +kernel
theorem a111_0_13_band0 : bandStats 17650504 17663080 0 687 = (-26, -106671, -511) := by decide +kernel
theorem a111_0_13_band1 : bandStats 17650504 17663080 687 665 = (6, -100453, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
