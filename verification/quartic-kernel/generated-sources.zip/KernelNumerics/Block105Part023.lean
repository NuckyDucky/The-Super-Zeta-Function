import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_10_band2 : bandStats 16506384 16517464 1466 671 = (-9, 16898, -504) := by decide +kernel
theorem a105_0_10_band3 : bandStats 16506384 16517464 2137 598 = (27, 284990, -489) := by decide +kernel
theorem a105_0_10_band4 : bandStats 16506384 16517464 2735 505 = (27, -51137, -485) := by decide +kernel
theorem a105_0_10_band5 : bandStats 16506384 16517464 3240 396 = (28, 300253, -485) := by decide +kernel

end QuarticKernel.KernelPrefixes
