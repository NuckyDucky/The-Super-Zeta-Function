import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_14_band2 : bandStats 16380404 16391553 1464 659 = (7, 108482, -496) := by decide +kernel
theorem a104_0_14_band3 : bandStats 16380404 16391553 2123 595 = (-9, -7217, -500) := by decide +kernel
theorem a104_0_14_band4 : bandStats 16380404 16391553 2718 502 = (-6, 14738, -502) := by decide +kernel
theorem a104_0_14_band5 : bandStats 16380404 16391553 3220 393 = (-30, -142189, -514) := by decide +kernel

end QuarticKernel.KernelPrefixes
