import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_5_band6 : bandStats 16836576 16848744 3488 312 = (15, 121367, -486) := by decide +kernel
theorem a107_0_5_band7 : bandStats 16836576 16848744 3800 205 = (32, 8265, -483) := by decide +kernel
theorem a107_0_5_band8 : bandStats 16836576 16848744 4005 93 = (-47, -213523, -517) := by decide +kernel
theorem a107_0_5_band9 : bandStats 16836576 16848744 4098 6 = (15, 133766, -139) := by decide +kernel

end QuarticKernel.KernelPrefixes
