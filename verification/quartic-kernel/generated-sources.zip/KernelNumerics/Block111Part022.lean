import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_8_band8 : bandStats 17588209 17600724 4045 126 = (7, -183789, -493) := by decide +kernel
theorem a111_0_8_band9 : bandStats 17588209 17600724 4171 24 = (-9, 23111, -333) := by decide +kernel
theorem a111_0_9_band0 : bandStats 17600724 17613139 0 702 = (16, 210920, -490) := by decide +kernel
theorem a111_0_9_band1 : bandStats 17600724 17613139 702 669 = (-16, -254343, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
