import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_10_band7 : bandStats 16165384 16176184 3913 104 = (16, 123376, -480) := by decide +kernel
theorem a103_0_10_band8 : bandStats 16165384 16176184 4017 4 = (0, -24759, -105) := by decide +kernel
theorem a103_0_11_band0 : bandStats 16176184 16186753 0 752 = (-32, -72540, -514) := by decide +kernel
theorem a103_0_11_band1 : bandStats 16176184 16186753 752 746 = (28, 142271, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
