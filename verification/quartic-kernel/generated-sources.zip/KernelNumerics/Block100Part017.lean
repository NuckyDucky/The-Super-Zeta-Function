import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_7_band5 : bandStats 15698545 15709524 3187 383 = (13, -4165, -491) := by decide +kernel
theorem a100_0_7_band6 : bandStats 15698545 15709524 3570 257 = (50, 216780, -473) := by decide +kernel
theorem a100_0_7_band7 : bandStats 15698545 15709524 3827 124 = (62, 480241, -464) := by decide +kernel
theorem a100_0_7_band8 : bandStats 15698545 15709524 3951 12 = (-9, -95851, -208) := by decide +kernel

end QuarticKernel.KernelPrefixes
