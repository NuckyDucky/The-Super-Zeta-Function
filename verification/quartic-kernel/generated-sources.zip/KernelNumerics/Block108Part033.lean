import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_13_band2 : bandStats 17115156 17127811 1311 615 = (-11, -72314, -506) := by decide +kernel
theorem a108_0_13_band3 : bandStats 17115156 17127811 1926 568 = (50, 187459, -475) := by decide +kernel
theorem a108_0_13_band4 : bandStats 17115156 17127811 2494 505 = (-2, -204546, -500) := by decide +kernel
theorem a108_0_13_band5 : bandStats 17115156 17127811 2999 423 = (-49, -338046, -523) := by decide +kernel

end QuarticKernel.KernelPrefixes
