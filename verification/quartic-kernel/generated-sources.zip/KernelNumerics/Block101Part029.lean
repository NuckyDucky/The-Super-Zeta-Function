import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_12_band8 : bandStats 15857980 15868835 3975 8 = (1, 34823, -159) := by decide +kernel
theorem a101_0_13_band0 : bandStats 15868835 15879689 0 762 = (0, 175441, -499) := by decide +kernel
theorem a101_0_13_band1 : bandStats 15868835 15879689 762 716 = (17, 126825, -492) := by decide +kernel
theorem a101_0_13_band2 : bandStats 15868835 15879689 1478 666 = (40, 253968, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
