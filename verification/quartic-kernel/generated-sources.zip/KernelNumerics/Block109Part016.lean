import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_6_band4 : bandStats 17204380 17217044 2484 497 = (2, -17117, -497) := by decide +kernel
theorem a109_0_6_band5 : bandStats 17204380 17217044 2981 424 = (-31, -316057, -514) := by decide +kernel
theorem a109_0_6_band6 : bandStats 17204380 17217044 3405 334 = (57, 413375, -468) := by decide +kernel
theorem a109_0_6_band7 : bandStats 17204380 17217044 3739 241 = (-10, 40293, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
