import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_13_band6 : bandStats 17115156 17127811 3422 330 = (-21, -267196, -509) := by decide +kernel
theorem a108_0_13_band7 : bandStats 17115156 17127811 3752 232 = (-28, 16018, -512) := by decide +kernel
theorem a108_0_13_band8 : bandStats 17115156 17127811 3984 128 = (-6, -26495, -502) := by decide +kernel
theorem a108_0_13_band9 : bandStats 17115156 17127811 4112 26 = (41, 65414, -325) := by decide +kernel

end QuarticKernel.KernelPrefixes
