import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_12_band0 : bandStats 16017769 16028136 0 786 = (4, 45723, -496) := by decide +kernel
theorem a102_0_12_band1 : bandStats 16017769 16028136 786 758 = (4, 22500, -495) := by decide +kernel
theorem a102_0_12_band2 : bandStats 16017769 16028136 1544 699 = (-71, -438588, -534) := by decide +kernel
theorem a102_0_12_band3 : bandStats 16017769 16028136 2243 604 = (22, 109933, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
