import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_9_band8 : bandStats 16154608 16165384 4013 7 = (6, 60949, -143) := by decide +kernel
theorem a103_0_10_band0 : bandStats 16165384 16176184 0 774 = (51, 339361, -472) := by decide +kernel
theorem a103_0_10_band1 : bandStats 16165384 16176184 774 739 = (-6, -985, -501) := by decide +kernel
theorem a103_0_10_band2 : bandStats 16165384 16176184 1513 678 = (-16, -339651, -506) := by decide +kernel

end QuarticKernel.KernelPrefixes
