import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_10_band2 : bandStats 16335775 16346796 1461 672 = (31, 167284, -484) := by decide +kernel
theorem a104_0_10_band3 : bandStats 16335775 16346796 2133 594 = (6, -18738, -495) := by decide +kernel
theorem a104_0_10_band4 : bandStats 16335775 16346796 2727 501 = (15, 60734, -492) := by decide +kernel
theorem a104_0_10_band5 : bandStats 16335775 16346796 3228 392 = (10, 3543, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
