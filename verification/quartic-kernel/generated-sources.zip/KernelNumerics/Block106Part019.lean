import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_8_band3 : bandStats 16656209 16667484 2117 595 = (-26, -89625, -510) := by decide +kernel
theorem a106_0_8_band4 : bandStats 16656209 16667484 2712 507 = (-16, -311002, -505) := by decide +kernel
theorem a106_0_8_band5 : bandStats 16656209 16667484 3219 401 = (8, 24248, -494) := by decide +kernel
theorem a106_0_8_band6 : bandStats 16656209 16667484 3620 279 = (0, -7036, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
