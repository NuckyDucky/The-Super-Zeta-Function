import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_7_band2 : bandStats 17575617 17588209 1355 625 = (-4, 59825, -501) := by decide +kernel
theorem a111_0_7_band3 : bandStats 17575617 17588209 1980 572 = (8, 112710, -494) := by decide +kernel
theorem a111_0_7_band4 : bandStats 17575617 17588209 2552 509 = (9, -170306, -497) := by decide +kernel
theorem a111_0_7_band5 : bandStats 17575617 17588209 3061 423 = (45, 351524, -477) := by decide +kernel

end QuarticKernel.KernelPrefixes
