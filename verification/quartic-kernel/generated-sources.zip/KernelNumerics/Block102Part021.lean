import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_9_band4 : bandStats 15987228 15997409 2872 495 = (-21, -69163, -509) := by decide +kernel
theorem a102_0_9_band5 : bandStats 15987228 15997409 3367 361 = (-50, -219784, -526) := by decide +kernel
theorem a102_0_9_band6 : bandStats 15987228 15997409 3728 212 = (-30, -87713, -510) := by decide +kernel
theorem a102_0_9_band7 : bandStats 15987228 15997409 3940 59 = (-22, -150617, -430) := by decide +kernel

end QuarticKernel.KernelPrefixes
