import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_7_band5 : bandStats 16472744 16483897 3232 393 = (48, 402309, -476) := by decide +kernel
theorem a105_0_7_band6 : bandStats 16472744 16483897 3625 274 = (40, 394050, -479) := by decide +kernel
theorem a105_0_7_band7 : bandStats 16472744 16483897 3899 140 = (-15, -230820, -505) := by decide +kernel
theorem a105_0_7_band8 : bandStats 16472744 16483897 4039 21 = (17, 89627, -259) := by decide +kernel

end QuarticKernel.KernelPrefixes
