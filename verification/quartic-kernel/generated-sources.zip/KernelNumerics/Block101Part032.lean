import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_14_band2 : bandStats 15879689 15890404 1477 676 = (26, 159848, -484) := by decide +kernel
theorem a101_0_14_band3 : bandStats 15879689 15890404 2153 595 = (10, 26404, -496) := by decide +kernel
theorem a101_0_14_band4 : bandStats 15879689 15890404 2748 496 = (-48, -375409, -521) := by decide +kernel
theorem a101_0_14_band5 : bandStats 15879689 15890404 3244 380 = (-6, -162173, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
