import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_13_band3 : bandStats 16369161 16380404 2095 595 = (-6, 56892, -498) := by decide +kernel
theorem a104_0_13_band4 : bandStats 16369161 16380404 2690 504 = (-33, -109988, -515) := by decide +kernel
theorem a104_0_13_band5 : bandStats 16369161 16380404 3194 396 = (1, 168281, -498) := by decide +kernel
theorem a104_0_13_band6 : bandStats 16369161 16380404 3590 280 = (-38, -138282, -515) := by decide +kernel

end QuarticKernel.KernelPrefixes
