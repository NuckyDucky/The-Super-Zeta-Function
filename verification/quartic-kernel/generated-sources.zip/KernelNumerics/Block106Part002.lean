import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_0_band8 : bandStats 16565089 16576312 4045 26 = (-44, -313972, -331) := by decide +kernel
theorem a106_0_1_band0 : bandStats 16576312 16587505 0 753 = (12, 280184, -493) := by decide +kernel
theorem a106_0_1_band1 : bandStats 16576312 16587505 753 710 = (-8, -78179, -500) := by decide +kernel
theorem a106_0_1_band2 : bandStats 16576312 16587505 1463 665 = (16, 194477, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
