import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_9_band3 : bandStats 16495089 16506384 2117 592 = (5, -116345, -498) := by decide +kernel
theorem a105_0_9_band4 : bandStats 16495089 16506384 2709 500 = (16, 39546, -489) := by decide +kernel
theorem a105_0_9_band5 : bandStats 16495089 16506384 3209 397 = (-62, -487303, -529) := by decide +kernel
theorem a105_0_9_band6 : bandStats 16495089 16506384 3606 280 = (6, 205040, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
