import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_7_band2 : bandStats 17396999 17409844 1294 618 = (-25, -212166, -511) := by decide +kernel
theorem a110_0_7_band3 : bandStats 17396999 17409844 1912 562 = (51, 550586, -472) := by decide +kernel
theorem a110_0_7_band4 : bandStats 17396999 17409844 2474 506 = (20, 429077, -491) := by decide +kernel
theorem a110_0_7_band5 : bandStats 17396999 17409844 2980 424 = (4, 20471, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
