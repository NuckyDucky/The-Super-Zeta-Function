import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_9_band6 : bandStats 17064568 17077139 3410 332 = (-67, -452459, -532) := by decide +kernel
theorem a108_0_9_band7 : bandStats 17064568 17077139 3742 236 = (17, 166078, -490) := by decide +kernel
theorem a108_0_9_band8 : bandStats 17064568 17077139 3978 128 = (-10, -66834, -503) := by decide +kernel
theorem a108_0_9_band9 : bandStats 17064568 17077139 4106 26 = (53, 337320, -324) := by decide +kernel

end QuarticKernel.KernelPrefixes
