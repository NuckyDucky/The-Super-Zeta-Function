import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_4_band8 : bandStats 17718416 17730595 4103 99 = (12, 150646, -487) := by decide +kernel
theorem a112_0_4_band9 : bandStats 17718416 17730595 4202 8 = (1, 56415, -171) := by decide +kernel
theorem a112_0_5_band0 : bandStats 17730595 17742825 0 696 = (18, 99197, -488) := by decide +kernel
theorem a112_0_5_band1 : bandStats 17730595 17742825 696 681 = (28, 338596, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
