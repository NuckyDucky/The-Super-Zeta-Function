import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_13_band9 : bandStats 17293801 17306313 4133 27 = (-16, -65558, -350) := by decide +kernel
theorem a109_0_14_band0 : bandStats 17306313 17306986 0 4160 = (-10, 164, -248) := by decide +kernel

end QuarticKernel.KernelPrefixes
