import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_5_band3 : bandStats 16281249 16292008 2162 604 = (77, 394634, -459) := by decide +kernel
theorem a104_0_5_band4 : bandStats 16281249 16292008 2766 503 = (-4, -29841, -500) := by decide +kernel
theorem a104_0_5_band5 : bandStats 16281249 16292008 3269 388 = (3, -82654, -495) := by decide +kernel
theorem a104_0_5_band6 : bandStats 16281249 16292008 3657 256 = (-41, -329986, -518) := by decide +kernel

end QuarticKernel.KernelPrefixes
