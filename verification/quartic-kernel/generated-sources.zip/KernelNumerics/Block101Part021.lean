import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_9_band3 : bandStats 15825464 15836300 2130 593 = (4, 38050, -497) := by decide +kernel
theorem a101_0_9_band4 : bandStats 15825464 15836300 2723 493 = (40, 249735, -477) := by decide +kernel
theorem a101_0_9_band5 : bandStats 15825464 15836300 3216 383 = (-2, -64037, -497) := by decide +kernel
theorem a101_0_9_band6 : bandStats 15825464 15836300 3599 252 = (-3, -4535, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
