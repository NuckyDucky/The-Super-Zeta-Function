import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_5_band2 : bandStats 17550601 17563240 1346 622 = (-20, -93563, -505) := by decide +kernel
theorem a111_0_5_band3 : bandStats 17550601 17563240 1968 566 = (-24, -130821, -507) := by decide +kernel
theorem a111_0_5_band4 : bandStats 17550601 17563240 2534 506 = (-5, 131298, -503) := by decide +kernel
theorem a111_0_5_band5 : bandStats 17550601 17563240 3040 423 = (-24, -182798, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
