import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_1_band2 : bandStats 16964289 16976284 1368 635 = (4, 14676, -497) := by decide +kernel
theorem a108_0_1_band3 : bandStats 16964289 16976284 2003 580 = (-66, -653006, -532) := by decide +kernel
theorem a108_0_1_band4 : bandStats 16964289 16976284 2583 510 = (-8, 75879, -502) := by decide +kernel
theorem a108_0_1_band5 : bandStats 16964289 16976284 3093 416 = (44, 290747, -477) := by decide +kernel

end QuarticKernel.KernelPrefixes
