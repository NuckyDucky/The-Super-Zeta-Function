import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_10_band5 : bandStats 16678756 16689817 3255 397 = (15, 122550, -491) := by decide +kernel
theorem a106_0_10_band6 : bandStats 16678756 16689817 3652 275 = (-14, -78567, -503) := by decide +kernel
theorem a106_0_10_band7 : bandStats 16678756 16689817 3927 139 = (3, 219225, -484) := by decide +kernel
theorem a106_0_10_band8 : bandStats 16678756 16689817 4066 19 = (-13, -42033, -270) := by decide +kernel

end QuarticKernel.KernelPrefixes
