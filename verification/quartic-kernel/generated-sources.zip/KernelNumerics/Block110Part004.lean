import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_1_band6 : bandStats 17319507 17332417 3397 336 = (-25, -168934, -512) := by decide +kernel
theorem a110_0_1_band7 : bandStats 17319507 17332417 3733 245 = (-11, 92567, -507) := by decide +kernel
theorem a110_0_1_band8 : bandStats 17319507 17332417 3978 143 = (11, -22782, -493) := by decide +kernel
theorem a110_0_1_band9 : bandStats 17319507 17332417 4121 42 = (-19, 38618, -452) := by decide +kernel

end QuarticKernel.KernelPrefixes
