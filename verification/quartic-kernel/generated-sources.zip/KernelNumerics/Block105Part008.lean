import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_3_band5 : bandStats 16428113 16439305 3223 393 = (-13, -3178, -504) := by decide +kernel
theorem a105_0_3_band6 : bandStats 16428113 16439305 3616 271 = (-28, -227726, -512) := by decide +kernel
theorem a105_0_3_band7 : bandStats 16428113 16439305 3887 144 = (6, 67978, -494) := by decide +kernel
theorem a105_0_3_band8 : bandStats 16428113 16439305 4031 23 = (-7, 29866, -288) := by decide +kernel

end QuarticKernel.KernelPrefixes
