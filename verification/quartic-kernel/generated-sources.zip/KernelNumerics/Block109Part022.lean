import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_8_band8 : bandStats 17229732 17242627 3966 144 = (-15, -119327, -504) := by decide +kernel
theorem a109_0_8_band9 : bandStats 17229732 17242627 4110 42 = (20, 916, -438) := by decide +kernel
theorem a109_0_9_band0 : bandStats 17242627 17255744 0 656 = (19, -121197, -490) := by decide +kernel
theorem a109_0_9_band1 : bandStats 17242627 17255744 656 628 = (-35, -380283, -517) := by decide +kernel

end QuarticKernel.KernelPrefixes
