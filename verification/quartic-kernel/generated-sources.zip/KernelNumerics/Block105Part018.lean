import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_8_band0 : bandStats 16483897 16495089 0 732 = (17, 53691, -491) := by decide +kernel
theorem a105_0_8_band1 : bandStats 16483897 16495089 732 703 = (-22, -200818, -509) := by decide +kernel
theorem a105_0_8_band2 : bandStats 16483897 16495089 1435 666 = (-28, -335090, -512) := by decide +kernel
theorem a105_0_8_band3 : bandStats 16483897 16495089 2101 593 = (48, 192059, -472) := by decide +kernel

end QuarticKernel.KernelPrefixes
