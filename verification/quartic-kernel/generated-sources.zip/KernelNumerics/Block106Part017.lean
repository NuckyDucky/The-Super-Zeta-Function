import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_7_band4 : bandStats 16644624 16656209 2655 504 = (-49, -353477, -525) := by decide +kernel
theorem a106_0_7_band5 : bandStats 16644624 16656209 3159 405 = (18, 56285, -489) := by decide +kernel
theorem a106_0_7_band6 : bandStats 16644624 16656209 3564 295 = (-2, -15492, -496) := by decide +kernel
theorem a106_0_7_band7 : bandStats 16644624 16656209 3859 174 = (-61, -451000, -530) := by decide +kernel

end QuarticKernel.KernelPrefixes
