import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_1_band7 : bandStats 15739632 15750561 3834 123 = (48, 268283, -476) := by decide +kernel
theorem a101_0_1_band8 : bandStats 15739632 15750561 3957 11 = (35, 86033, -174) := by decide +kernel
theorem a101_0_2_band0 : bandStats 15750561 15761460 0 743 = (32, 335348, -481) := by decide +kernel
theorem a101_0_2_band1 : bandStats 15750561 15761460 743 716 = (30, 93995, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
