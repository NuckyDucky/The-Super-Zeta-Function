import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_9_band6 : bandStats 16667484 16678756 3623 280 = (1, -60799, -497) := by decide +kernel
theorem a106_0_9_band7 : bandStats 16667484 16678756 3903 152 = (-28, -58721, -512) := by decide +kernel
theorem a106_0_9_band8 : bandStats 16667484 16678756 4055 28 = (-58, -246394, -343) := by decide +kernel
theorem a106_0_10_band0 : bandStats 16678756 16689817 0 734 = (20, 182, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
