import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_14_band0 : bandStats 16038361 16048564 0 796 = (-18, -82912, -508) := by decide +kernel
theorem a102_0_14_band1 : bandStats 16038361 16048564 796 769 = (-15, -96958, -506) := by decide +kernel
theorem a102_0_14_band2 : bandStats 16038361 16048564 1565 701 = (-18, -135300, -508) := by decide +kernel
theorem a102_0_14_band3 : bandStats 16038361 16048564 2266 607 = (84, 310574, -458) := by decide +kernel

end QuarticKernel.KernelPrefixes
