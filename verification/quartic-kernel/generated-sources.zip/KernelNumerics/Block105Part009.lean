import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_4_band0 : bandStats 16439305 16450449 0 752 = (7, 67510, -497) := by decide +kernel
theorem a105_0_4_band1 : bandStats 16439305 16450449 752 725 = (20, 56648, -485) := by decide +kernel
theorem a105_0_4_band2 : bandStats 16439305 16450449 1477 669 = (1, -88523, -497) := by decide +kernel
theorem a105_0_4_band3 : bandStats 16439305 16450449 2146 588 = (-11, -147610, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
