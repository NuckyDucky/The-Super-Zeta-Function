import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_10_band4 : bandStats 17077139 17089955 2486 495 = (-20, -136729, -511) := by decide +kernel
theorem a108_0_10_band5 : bandStats 17077139 17089955 2981 420 = (18, -121474, -488) := by decide +kernel
theorem a108_0_10_band6 : bandStats 17077139 17089955 3401 332 = (8, 23224, -492) := by decide +kernel
theorem a108_0_10_band7 : bandStats 17077139 17089955 3733 233 = (-46, -503801, -520) := by decide +kernel

end QuarticKernel.KernelPrefixes
