import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_12_band0 : bandStats 17638201 17650504 0 687 = (34, 9589, -481) := by decide +kernel
theorem a111_0_12_band1 : bandStats 17638201 17650504 687 668 = (14, 111695, -490) := by decide +kernel
theorem a111_0_12_band2 : bandStats 17638201 17650504 1355 634 = (32, 163441, -483) := by decide +kernel
theorem a111_0_12_band3 : bandStats 17638201 17650504 1989 584 = (-1, 59649, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
