import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_4_band4 : bandStats 16824831 16836576 2618 509 = (27, -24245, -485) := by decide +kernel
theorem a107_0_4_band5 : bandStats 16824831 16836576 3127 414 = (-39, -282084, -515) := by decide +kernel
theorem a107_0_4_band6 : bandStats 16824831 16836576 3541 301 = (65, 410940, -468) := by decide +kernel
theorem a107_0_4_band7 : bandStats 16824831 16836576 3842 191 = (-28, -241727, -512) := by decide +kernel

end QuarticKernel.KernelPrefixes
