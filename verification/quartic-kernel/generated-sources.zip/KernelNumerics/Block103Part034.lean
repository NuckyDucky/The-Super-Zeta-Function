import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_15_band2 : bandStats 16219809 16225300 2739 883 = (8, 5358, -493) := by decide +kernel
theorem a103_0_15_band3 : bandStats 16219809 16225300 3622 392 = (-11, -7171, -501) := by decide +kernel
theorem a103_0_15_band4 : bandStats 16219809 16225300 4014 14 = (1, -24049, -103) := by decide +kernel

end QuarticKernel.KernelPrefixes
