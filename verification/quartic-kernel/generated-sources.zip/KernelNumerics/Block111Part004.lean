import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_1_band6 : bandStats 17499832 17512524 3448 334 = (7, 198294, -494) := by decide +kernel
theorem a111_0_1_band7 : bandStats 17499832 17512524 3782 237 = (23, 261799, -485) := by decide +kernel
theorem a111_0_1_band8 : bandStats 17499832 17512524 4019 134 = (-29, -283814, -511) := by decide +kernel
theorem a111_0_1_band9 : bandStats 17499832 17512524 4153 31 = (-18, -210804, -369) := by decide +kernel

end QuarticKernel.KernelPrefixes
