import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_8_band4 : bandStats 17588209 17600724 2548 497 = (5, 54112, -485) := by decide +kernel
theorem a111_0_8_band5 : bandStats 17588209 17600724 3045 429 = (-61, -326122, -529) := by decide +kernel
theorem a111_0_8_band6 : bandStats 17588209 17600724 3474 336 = (-35, -440314, -519) := by decide +kernel
theorem a111_0_8_band7 : bandStats 17588209 17600724 3810 235 = (-22, -329536, -507) := by decide +kernel

end QuarticKernel.KernelPrefixes
