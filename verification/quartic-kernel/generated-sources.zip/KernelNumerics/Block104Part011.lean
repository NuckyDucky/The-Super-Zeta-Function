import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_4_band8 : bandStats 16270272 16281249 4023 12 = (-12, 2157, -195) := by decide +kernel
theorem a104_0_5_band0 : bandStats 16281249 16292008 0 745 = (14, 74788, -492) := by decide +kernel
theorem a104_0_5_band1 : bandStats 16281249 16292008 745 733 = (-26, -57835, -511) := by decide +kernel
theorem a104_0_5_band2 : bandStats 16281249 16292008 1478 684 = (18, 58333, -490) := by decide +kernel

end QuarticKernel.KernelPrefixes
