import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_1_band3 : bandStats 16405384 16416841 2078 587 = (-3, 99204, -501) := by decide +kernel
theorem a105_0_1_band4 : bandStats 16405384 16416841 2665 501 = (-26, -182763, -510) := by decide +kernel
theorem a105_0_1_band5 : bandStats 16405384 16416841 3166 399 = (-37, -255492, -518) := by decide +kernel
theorem a105_0_1_band6 : bandStats 16405384 16416841 3565 286 = (-20, -6194, -511) := by decide +kernel

end QuarticKernel.KernelPrefixes
