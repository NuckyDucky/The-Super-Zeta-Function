import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_4_band0 : bandStats 17179180 17191708 0 665 = (7, 159309, -496) := by decide +kernel
theorem a109_0_4_band1 : bandStats 17179180 17191708 665 660 = (6, -38005, -497) := by decide +kernel
theorem a109_0_4_band2 : bandStats 17179180 17191708 1325 612 = (-16, -93470, -505) := by decide +kernel
theorem a109_0_4_band3 : bandStats 17179180 17191708 1937 570 = (17, 309061, -489) := by decide +kernel

end QuarticKernel.KernelPrefixes
