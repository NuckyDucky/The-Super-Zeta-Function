import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_9_band7 : bandStats 16495089 16506384 3886 149 = (-47, -458693, -514) := by decide +kernel
theorem a105_0_9_band8 : bandStats 16495089 16506384 4035 27 = (14, 99926, -300) := by decide +kernel
theorem a105_0_10_band0 : bandStats 16506384 16517464 0 739 = (9, -238, -494) := by decide +kernel
theorem a105_0_10_band1 : bandStats 16506384 16517464 739 727 = (0, -27207, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
