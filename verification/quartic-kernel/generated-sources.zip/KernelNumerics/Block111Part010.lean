import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_4_band0 : bandStats 17537860 17550601 0 656 = (-16, -178965, -508) := by decide +kernel
theorem a111_0_4_band1 : bandStats 17537860 17550601 656 650 = (-35, -282987, -518) := by decide +kernel
theorem a111_0_4_band2 : bandStats 17537860 17550601 1306 628 = (47, 482870, -478) := by decide +kernel
theorem a111_0_4_band3 : bandStats 17537860 17550601 1934 569 = (38, 39254, -479) := by decide +kernel

end QuarticKernel.KernelPrefixes
