import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_11_band8 : bandStats 16689817 16700993 4059 27 = (15, 142698, -300) := by decide +kernel
theorem a106_0_12_band0 : bandStats 16700993 16712356 0 731 = (10, 24418, -494) := by decide +kernel
theorem a106_0_12_band1 : bandStats 16700993 16712356 731 711 = (-6, 153046, -503) := by decide +kernel
theorem a106_0_12_band2 : bandStats 16700993 16712356 1442 659 = (-13, -48663, -504) := by decide +kernel

end QuarticKernel.KernelPrefixes
