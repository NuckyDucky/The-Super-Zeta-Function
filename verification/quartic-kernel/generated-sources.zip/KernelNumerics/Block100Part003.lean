import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_1_band3 : bandStats 15632657 15643584 2088 591 = (17, 171909, -494) := by decide +kernel
theorem a100_0_1_band4 : bandStats 15632657 15643584 2679 496 = (-4, 107904, -499) := by decide +kernel
theorem a100_0_1_band5 : bandStats 15632657 15643584 3175 381 = (-37, -308660, -516) := by decide +kernel
theorem a100_0_1_band6 : bandStats 15632657 15643584 3556 258 = (-34, -46147, -513) := by decide +kernel

end QuarticKernel.KernelPrefixes
