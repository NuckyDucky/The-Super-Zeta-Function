import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_2_band6 : bandStats 15643584 15654595 3556 261 = (-28, 196717, -513) := by decide +kernel
theorem a100_0_2_band7 : bandStats 15643584 15654595 3817 126 = (-28, -60721, -515) := by decide +kernel
theorem a100_0_2_band8 : bandStats 15643584 15654595 3943 13 = (-16, -46210, -220) := by decide +kernel
theorem a100_0_3_band0 : bandStats 15654595 15665545 0 748 = (11, -39167, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
