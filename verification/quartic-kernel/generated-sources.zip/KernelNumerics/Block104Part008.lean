import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_3_band5 : bandStats 16259233 16270272 3227 391 = (-30, -166702, -514) := by decide +kernel
theorem a104_0_3_band6 : bandStats 16259233 16270272 3618 265 = (-7, 50416, -499) := by decide +kernel
theorem a104_0_3_band7 : bandStats 16259233 16270272 3883 133 = (-18, 32885, -505) := by decide +kernel
theorem a104_0_3_band8 : bandStats 16259233 16270272 4016 17 = (0, 65354, -240) := by decide +kernel

end QuarticKernel.KernelPrefixes
