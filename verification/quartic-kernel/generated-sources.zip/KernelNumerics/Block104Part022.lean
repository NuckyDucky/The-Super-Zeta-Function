import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_9_band7 : bandStats 16324696 16335775 3886 136 = (7, 65398, -488) := by decide +kernel
theorem a104_0_9_band8 : bandStats 16324696 16335775 4022 19 = (2, -34411, -252) := by decide +kernel
theorem a104_0_10_band0 : bandStats 16335775 16346796 0 742 = (14, 268286, -489) := by decide +kernel
theorem a104_0_10_band1 : bandStats 16335775 16346796 742 719 = (-14, -156062, -509) := by decide +kernel

end QuarticKernel.KernelPrefixes
