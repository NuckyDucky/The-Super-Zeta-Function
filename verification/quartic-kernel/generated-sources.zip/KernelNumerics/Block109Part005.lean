import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_2_band0 : bandStats 17153620 17166439 0 657 = (-16, -51769, -507) := by decide +kernel
theorem a109_0_2_band1 : bandStats 17153620 17166439 657 639 = (-22, -218367, -512) := by decide +kernel
theorem a109_0_2_band2 : bandStats 17153620 17166439 1296 610 = (-36, -216886, -516) := by decide +kernel
theorem a109_0_2_band3 : bandStats 17153620 17166439 1906 559 = (-5, -187738, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
