import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_6_band0 : bandStats 17204380 17217044 0 658 = (37, 281286, -479) := by decide +kernel
theorem a109_0_6_band1 : bandStats 17204380 17217044 658 646 = (-65, -425053, -532) := by decide +kernel
theorem a109_0_6_band2 : bandStats 17204380 17217044 1304 612 = (-19, -243524, -508) := by decide +kernel
theorem a109_0_6_band3 : bandStats 17204380 17217044 1916 568 = (-32, -328495, -514) := by decide +kernel

end QuarticKernel.KernelPrefixes
