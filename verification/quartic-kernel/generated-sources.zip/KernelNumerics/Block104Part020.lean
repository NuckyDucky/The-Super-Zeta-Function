import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_8_band8 : bandStats 16313785 16324696 4030 10 = (3, 46314, -184) := by decide +kernel
theorem a104_0_9_band0 : bandStats 16324696 16335775 0 751 = (-36, -270620, -518) := by decide +kernel
theorem a104_0_9_band1 : bandStats 16324696 16335775 751 712 = (10, -29541, -491) := by decide +kernel
theorem a104_0_9_band2 : bandStats 16324696 16335775 1463 669 = (-1, 216212, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
