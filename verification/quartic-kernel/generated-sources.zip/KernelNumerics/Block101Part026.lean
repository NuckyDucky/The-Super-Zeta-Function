import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_11_band5 : bandStats 15847153 15857980 3222 383 = (-6, 27873, -499) := by decide +kernel
theorem a101_0_11_band6 : bandStats 15847153 15857980 3605 255 = (-3, 2996, -500) := by decide +kernel
theorem a101_0_11_band7 : bandStats 15847153 15857980 3860 114 = (-8, 79138, -501) := by decide +kernel
theorem a101_0_11_band8 : bandStats 15847153 15857980 3974 8 = (-24, -171233, -177) := by decide +kernel

end QuarticKernel.KernelPrefixes
