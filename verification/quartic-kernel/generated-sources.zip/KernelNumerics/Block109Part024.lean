import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_9_band6 : bandStats 17242627 17255744 3359 337 = (21, 25528, -487) := by decide +kernel
theorem a109_0_9_band7 : bandStats 17242627 17255744 3696 250 = (-54, -237365, -526) := by decide +kernel
theorem a109_0_9_band8 : bandStats 17242627 17255744 3946 153 = (5, -96307, -496) := by decide +kernel
theorem a109_0_9_band9 : bandStats 17242627 17255744 4099 53 = (3, 220101, -456) := by decide +kernel

end QuarticKernel.KernelPrefixes
