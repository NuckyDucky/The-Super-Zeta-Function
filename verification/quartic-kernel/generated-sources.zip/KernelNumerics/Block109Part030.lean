import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_11_band9 : bandStats 17268625 17281300 4127 30 = (-48, -172048, -384) := by decide +kernel
theorem a109_0_12_band0 : bandStats 17281300 17293801 0 674 = (35, 93824, -481) := by decide +kernel
theorem a109_0_12_band1 : bandStats 17281300 17293801 674 655 = (20, 157621, -488) := by decide +kernel
theorem a109_0_12_band2 : bandStats 17281300 17293801 1329 633 = (4, -32901, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
