import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_5_band7 : bandStats 15945249 15955864 3896 95 = (59, 210501, -451) := by decide +kernel
theorem a102_0_5_band8 : bandStats 15945249 15955864 3991 3 = (8, -4841, -84) := by decide +kernel
theorem a102_0_6_band0 : bandStats 15955864 15966616 0 769 = (-13, -6659, -505) := by decide +kernel
theorem a102_0_6_band1 : bandStats 15955864 15966616 769 727 = (-77, -346199, -534) := by decide +kernel

end QuarticKernel.KernelPrefixes
