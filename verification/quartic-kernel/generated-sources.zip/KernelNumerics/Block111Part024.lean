import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_9_band6 : bandStats 17600724 17613139 3510 326 = (-26, 95437, -510) := by decide +kernel
theorem a111_0_9_band7 : bandStats 17600724 17613139 3836 226 = (21, 55008, -486) := by decide +kernel
theorem a111_0_9_band8 : bandStats 17600724 17613139 4062 117 = (-13, -111775, -505) := by decide +kernel
theorem a111_0_9_band9 : bandStats 17600724 17613139 4179 17 = (6, 201188, -257) := by decide +kernel

end QuarticKernel.KernelPrefixes
