import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_12_band8 : bandStats 16528585 16539939 4035 31 = (-9, -179237, -330) := by decide +kernel
theorem a105_0_13_band0 : bandStats 16539939 16551180 0 724 = (32, -81520, -484) := by decide +kernel
theorem a105_0_13_band1 : bandStats 16539939 16551180 724 714 = (-6, -136613, -502) := by decide +kernel
theorem a105_0_13_band2 : bandStats 16539939 16551180 1438 661 = (-15, 16852, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
