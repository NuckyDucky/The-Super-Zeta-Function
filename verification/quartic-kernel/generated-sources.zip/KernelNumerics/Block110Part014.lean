import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_5_band6 : bandStats 17371240 17384116 3390 340 = (12, -87349, -492) := by decide +kernel
theorem a110_0_5_band7 : bandStats 17371240 17384116 3730 246 = (-42, -401689, -518) := by decide +kernel
theorem a110_0_5_band8 : bandStats 17371240 17384116 3976 148 = (33, 150617, -476) := by decide +kernel
theorem a110_0_5_band9 : bandStats 17371240 17384116 4124 45 = (-59, -295807, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
