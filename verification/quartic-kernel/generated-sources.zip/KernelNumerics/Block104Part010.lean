import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_4_band4 : bandStats 16270272 16281249 2753 501 = (-29, -180955, -511) := by decide +kernel
theorem a104_0_4_band5 : bandStats 16270272 16281249 3254 386 = (33, 271638, -483) := by decide +kernel
theorem a104_0_4_band6 : bandStats 16270272 16281249 3640 260 = (-19, -58501, -508) := by decide +kernel
theorem a104_0_4_band7 : bandStats 16270272 16281249 3900 123 = (-10, -235858, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
