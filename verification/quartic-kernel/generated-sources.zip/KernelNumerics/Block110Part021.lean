import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_8_band4 : bandStats 17409844 17422924 2448 498 = (19, -46380, -493) := by decide +kernel
theorem a110_0_8_band5 : bandStats 17409844 17422924 2946 423 = (21, 163219, -488) := by decide +kernel
theorem a110_0_8_band6 : bandStats 17409844 17422924 3369 345 = (-28, -321864, -511) := by decide +kernel
theorem a110_0_8_band7 : bandStats 17409844 17422924 3714 249 = (-7, 74726, -503) := by decide +kernel

end QuarticKernel.KernelPrefixes
