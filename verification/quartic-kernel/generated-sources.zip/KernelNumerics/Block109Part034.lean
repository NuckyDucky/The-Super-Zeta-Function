import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_13_band5 : bandStats 17293801 17306313 3017 421 = (-24, 51605, -510) := by decide +kernel
theorem a109_0_13_band6 : bandStats 17293801 17306313 3438 329 = (-3, -255371, -498) := by decide +kernel
theorem a109_0_13_band7 : bandStats 17293801 17306313 3767 235 = (-3, -73879, -499) := by decide +kernel
theorem a109_0_13_band8 : bandStats 17293801 17306313 4002 131 = (7, 73426, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
