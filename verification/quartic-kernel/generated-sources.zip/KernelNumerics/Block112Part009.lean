import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a112_0_3_band6 : bandStats 17706316 17718416 3576 320 = (14, -18769, -491) := by decide +kernel
theorem a112_0_3_band7 : bandStats 17706316 17718416 3896 212 = (-30, -171543, -511) := by decide +kernel
theorem a112_0_3_band8 : bandStats 17706316 17718416 4108 95 = (1, -127367, -501) := by decide +kernel
theorem a112_0_3_band9 : bandStats 17706316 17718416 4203 6 = (3, -42084, -154) := by decide +kernel

end QuarticKernel.KernelPrefixes
