import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_4_band8 : bandStats 17358249 17371240 3972 148 = (4, -17835, -494) := by decide +kernel
theorem a110_0_4_band9 : bandStats 17358249 17371240 4120 47 = (45, 198729, -442) := by decide +kernel
theorem a110_0_5_band0 : bandStats 17371240 17384116 0 646 = (-2, 13884, -500) := by decide +kernel
theorem a110_0_5_band1 : bandStats 17371240 17384116 646 647 = (-26, -384112, -511) := by decide +kernel

end QuarticKernel.KernelPrefixes
