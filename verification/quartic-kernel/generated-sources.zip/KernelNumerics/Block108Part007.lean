import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_2_band8 : bandStats 16976284 16988451 4020 94 = (32, 70282, -467) := by decide +kernel
theorem a108_0_2_band9 : bandStats 16976284 16988451 4114 7 = (6, 62490, -158) := by decide +kernel
theorem a108_0_3_band0 : bandStats 16988451 17000872 0 668 = (-9, -145765, -503) := by decide +kernel
theorem a108_0_3_band1 : bandStats 16988451 17000872 668 655 = (39, 413983, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
