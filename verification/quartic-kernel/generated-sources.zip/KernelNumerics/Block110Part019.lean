import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_7_band6 : bandStats 17396999 17409844 3404 340 = (0, -16152, -494) := by decide +kernel
theorem a110_0_7_band7 : bandStats 17396999 17409844 3744 244 = (34, 39687, -480) := by decide +kernel
theorem a110_0_7_band8 : bandStats 17396999 17409844 3988 143 = (18, 226249, -484) := by decide +kernel
theorem a110_0_7_band9 : bandStats 17396999 17409844 4131 41 = (29, 93539, -431) := by decide +kernel

end QuarticKernel.KernelPrefixes
