import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_5_band6 : bandStats 17191708 17204380 3434 331 = (-7, 69374, -500) := by decide +kernel
theorem a109_0_5_band7 : bandStats 17191708 17204380 3765 230 = (-38, -259588, -513) := by decide +kernel
theorem a109_0_5_band8 : bandStats 17191708 17204380 3995 126 = (14, 33442, -486) := by decide +kernel
theorem a109_0_5_band9 : bandStats 17191708 17204380 4121 26 = (56, 394646, -307) := by decide +kernel

end QuarticKernel.KernelPrefixes
