import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_2_band6 : bandStats 15750561 15761460 3589 253 = (-28, -100895, -510) := by decide +kernel
theorem a101_0_2_band7 : bandStats 15750561 15761460 3842 118 = (-4, -12041, -497) := by decide +kernel
theorem a101_0_2_band8 : bandStats 15750561 15761460 3960 10 = (-13, -52666, -185) := by decide +kernel
theorem a101_0_3_band0 : bandStats 15761460 15772464 0 727 = (-42, -312642, -520) := by decide +kernel

end QuarticKernel.KernelPrefixes
