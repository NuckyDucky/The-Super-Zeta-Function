import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_9_band1 : bandStats 17422924 17436003 652 632 = (-51, -367466, -523) := by decide +kernel
theorem a110_0_9_band2 : bandStats 17422924 17436003 1284 603 = (-38, -301419, -516) := by decide +kernel
theorem a110_0_9_band3 : bandStats 17422924 17436003 1887 557 = (56, 496759, -470) := by decide +kernel
theorem a110_0_9_band4 : bandStats 17422924 17436003 2444 494 = (-18, -130098, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
