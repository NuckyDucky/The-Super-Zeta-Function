import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_12_band4 : bandStats 17102424 17115156 2484 501 = (26, 167861, -479) := by decide +kernel
theorem a108_0_12_band5 : bandStats 17102424 17115156 2985 418 = (-15, -140433, -505) := by decide +kernel
theorem a108_0_12_band6 : bandStats 17102424 17115156 3403 333 = (-7, 58169, -501) := by decide +kernel
theorem a108_0_12_band7 : bandStats 17102424 17115156 3736 235 = (-7, -117843, -502) := by decide +kernel

end QuarticKernel.KernelPrefixes
