import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_3_band1 : bandStats 15924100 15934641 781 742 = (31, 237677, -483) := by decide +kernel
theorem a102_0_3_band2 : bandStats 15924100 15934641 1523 687 = (29, 126125, -482) := by decide +kernel
theorem a102_0_3_band3 : bandStats 15924100 15934641 2210 599 = (10, 107160, -491) := by decide +kernel
theorem a102_0_3_band4 : bandStats 15924100 15934641 2809 493 = (0, 75148, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
