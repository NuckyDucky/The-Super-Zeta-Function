import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_14_band6 : bandStats 16380404 16391553 3613 271 = (-18, -223420, -510) := by decide +kernel
theorem a104_0_14_band7 : bandStats 16380404 16391553 3884 143 = (0, 140442, -494) := by decide +kernel
theorem a104_0_14_band8 : bandStats 16380404 16391553 4027 21 = (-10, 14772, -274) := by decide +kernel
theorem a104_0_15_band0 : bandStats 16391553 16394314 0 2766 = (3, -47918, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
