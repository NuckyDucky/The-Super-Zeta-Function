import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_8_band8 : bandStats 16872697 16884841 4003 97 = (-46, -137366, -512) := by decide +kernel
theorem a107_0_8_band9 : bandStats 16872697 16884841 4100 9 = (-8, 17236, -188) := by decide +kernel
theorem a107_0_9_band0 : bandStats 16884841 16896999 0 690 = (23, 26464, -485) := by decide +kernel
theorem a107_0_9_band1 : bandStats 16884841 16896999 690 677 = (9, 24194, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
