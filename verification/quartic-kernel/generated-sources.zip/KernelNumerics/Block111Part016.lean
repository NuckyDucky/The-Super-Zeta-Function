import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_6_band4 : bandStats 17563240 17575617 2562 516 = (2, -200043, -502) := by decide +kernel
theorem a111_0_6_band5 : bandStats 17563240 17575617 3078 429 = (-4, 164981, -499) := by decide +kernel
theorem a111_0_6_band6 : bandStats 17563240 17575617 3507 328 = (32, -71192, -481) := by decide +kernel
theorem a111_0_6_band7 : bandStats 17563240 17575617 3835 225 = (-13, -10259, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
