import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_9_band0 : bandStats 15987228 15997409 0 802 = (20, 5266, -489) := by decide +kernel
theorem a102_0_9_band1 : bandStats 15987228 15997409 802 763 = (13, 89499, -494) := by decide +kernel
theorem a102_0_9_band2 : bandStats 15987228 15997409 1565 702 = (22, 212161, -488) := by decide +kernel
theorem a102_0_9_band3 : bandStats 15987228 15997409 2267 605 = (-52, -267738, -526) := by decide +kernel

end QuarticKernel.KernelPrefixes
