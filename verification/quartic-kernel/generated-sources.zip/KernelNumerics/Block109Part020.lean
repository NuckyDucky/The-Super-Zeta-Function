import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_8_band0 : bandStats 17229732 17242627 0 649 = (0, -124276, -498) := by decide +kernel
theorem a109_0_8_band1 : bandStats 17229732 17242627 649 642 = (29, 224840, -482) := by decide +kernel
theorem a109_0_8_band2 : bandStats 17229732 17242627 1291 610 = (26, 48585, -485) := by decide +kernel
theorem a109_0_8_band3 : bandStats 17229732 17242627 1901 561 = (38, 231996, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
