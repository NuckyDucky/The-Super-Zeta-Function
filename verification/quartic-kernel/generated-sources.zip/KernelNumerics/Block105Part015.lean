import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_6_band6 : bandStats 16461520 16472744 3618 274 = (21, 72395, -485) := by decide +kernel
theorem a105_0_6_band7 : bandStats 16461520 16472744 3892 143 = (-36, -272360, -510) := by decide +kernel
theorem a105_0_6_band8 : bandStats 16461520 16472744 4035 23 = (20, 130790, -273) := by decide +kernel
theorem a105_0_7_band0 : bandStats 16472744 16483897 0 742 = (14, 94751, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
