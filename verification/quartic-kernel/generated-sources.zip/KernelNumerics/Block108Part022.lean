import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_8_band8 : bandStats 17051683 17064568 3950 140 = (-15, -120390, -506) := by decide +kernel
theorem a108_0_8_band9 : bandStats 17051683 17064568 4090 40 = (8, 63591, -417) := by decide +kernel
theorem a108_0_9_band0 : bandStats 17064568 17077139 0 656 = (-19, -75068, -509) := by decide +kernel
theorem a108_0_9_band1 : bandStats 17064568 17077139 656 656 = (35, 65043, -480) := by decide +kernel

end QuarticKernel.KernelPrefixes
