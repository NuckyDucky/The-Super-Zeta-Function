import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_10_band8 : bandStats 16896999 16909172 4003 100 = (11, 17861, -489) := by decide +kernel
theorem a107_0_10_band9 : bandStats 16896999 16909172 4103 9 = (12, 20373, -178) := by decide +kernel
theorem a107_0_11_band0 : bandStats 16909172 16921377 0 684 = (-21, -178263, -509) := by decide +kernel
theorem a107_0_11_band1 : bandStats 16909172 16921377 684 668 = (42, 221869, -473) := by decide +kernel

end QuarticKernel.KernelPrefixes
