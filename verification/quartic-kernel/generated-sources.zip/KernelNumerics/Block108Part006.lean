import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_2_band4 : bandStats 16976284 16988451 2580 501 = (99, 532910, -450) := by decide +kernel
theorem a108_0_2_band5 : bandStats 16976284 16988451 3081 415 = (0, -17494, -494) := by decide +kernel
theorem a108_0_2_band6 : bandStats 16976284 16988451 3496 315 = (28, 147242, -483) := by decide +kernel
theorem a108_0_2_band7 : bandStats 16976284 16988451 3811 209 = (54, 262384, -469) := by decide +kernel

end QuarticKernel.KernelPrefixes
