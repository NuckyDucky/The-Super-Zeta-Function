import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_8_band5 : bandStats 16144227 16154608 3339 374 = (35, 392461, -483) := by decide +kernel
theorem a103_0_8_band6 : bandStats 16144227 16154608 3713 228 = (50, 283504, -469) := by decide +kernel
theorem a103_0_8_band7 : bandStats 16144227 16154608 3941 77 = (25, 122645, -473) := by decide +kernel
theorem a103_0_8_band8 : bandStats 16144227 16154608 4018 1 = (19, 36700, -14) := by decide +kernel

end QuarticKernel.KernelPrefixes
