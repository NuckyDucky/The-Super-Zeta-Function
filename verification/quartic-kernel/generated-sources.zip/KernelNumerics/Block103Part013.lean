import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_5_band8 : bandStats 16111484 16122599 3993 22 = (14, 36664, -282) := by decide +kernel
theorem a103_0_6_band0 : bandStats 16122599 16133543 0 753 = (-1, -105271, -497) := by decide +kernel
theorem a103_0_6_band1 : bandStats 16122599 16133543 753 724 = (-37, -247765, -514) := by decide +kernel
theorem a103_0_6_band2 : bandStats 16122599 16133543 1477 667 = (-67, -580009, -531) := by decide +kernel

end QuarticKernel.KernelPrefixes
