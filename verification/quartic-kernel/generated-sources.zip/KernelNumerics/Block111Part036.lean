import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_14_band4 : bandStats 17663080 17669428 4046 157 = (-47, -119257, -451) := by decide +kernel

end QuarticKernel.KernelPrefixes
