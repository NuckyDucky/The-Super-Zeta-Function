import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_8_band4 : bandStats 16483897 16495089 2694 505 = (-60, -502445, -528) := by decide +kernel
theorem a105_0_8_band5 : bandStats 16483897 16495089 3199 401 = (6, -101123, -496) := by decide +kernel
theorem a105_0_8_band6 : bandStats 16483897 16495089 3600 279 = (18, 24631, -488) := by decide +kernel
theorem a105_0_8_band7 : bandStats 16483897 16495089 3879 153 = (0, -67634, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
