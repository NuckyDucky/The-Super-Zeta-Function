import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_2_band4 : bandStats 17332417 17345295 2479 504 = (49, 249204, -473) := by decide +kernel
theorem a110_0_2_band5 : bandStats 17332417 17345295 2983 421 = (32, 151770, -483) := by decide +kernel
theorem a110_0_2_band6 : bandStats 17332417 17345295 3404 337 = (32, 377275, -483) := by decide +kernel
theorem a110_0_2_band7 : bandStats 17332417 17345295 3741 242 = (-4, -33950, -496) := by decide +kernel

end QuarticKernel.KernelPrefixes
