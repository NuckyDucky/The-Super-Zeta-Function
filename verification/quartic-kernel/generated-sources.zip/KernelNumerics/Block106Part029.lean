import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_12_band7 : bandStats 16700993 16712356 3892 160 = (48, 464530, -471) := by decide +kernel
theorem a106_0_12_band8 : bandStats 16700993 16712356 4052 36 = (-13, -270227, -373) := by decide +kernel
theorem a106_0_13_band0 : bandStats 16712356 16723764 0 723 = (37, 208673, -481) := by decide +kernel
theorem a106_0_13_band1 : bandStats 16712356 16723764 723 706 = (26, 40332, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
