import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_14_band6 : bandStats 16551180 16562465 3601 281 = (62, 289889, -466) := by decide +kernel
theorem a105_0_14_band7 : bandStats 16551180 16562465 3882 156 = (-3, -256825, -497) := by decide +kernel
theorem a105_0_14_band8 : bandStats 16551180 16562465 4038 31 = (-24, -92083, -347) := by decide +kernel
theorem a105_0_15_band0 : bandStats 16562465 16565089 0 2924 = (0, -23336, -499) := by decide +kernel

end QuarticKernel.KernelPrefixes
