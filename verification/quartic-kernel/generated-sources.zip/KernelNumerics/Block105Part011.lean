import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_4_band8 : bandStats 16439305 16450449 4036 19 = (1, -78247, -252) := by decide +kernel
theorem a105_0_5_band0 : bandStats 16450449 16461520 0 727 = (-2, 11838, -498) := by decide +kernel
theorem a105_0_5_band1 : bandStats 16450449 16461520 727 710 = (-44, -445415, -523) := by decide +kernel
theorem a105_0_5_band2 : bandStats 16450449 16461520 1437 668 = (-9, -86049, -501) := by decide +kernel

end QuarticKernel.KernelPrefixes
