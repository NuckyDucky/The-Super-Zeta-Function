import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_8_band0 : bandStats 16313785 16324696 0 746 = (1, 54836, -498) := by decide +kernel
theorem a104_0_8_band1 : bandStats 16313785 16324696 746 736 = (55, 589626, -473) := by decide +kernel
theorem a104_0_8_band2 : bandStats 16313785 16324696 1482 673 = (33, 114103, -482) := by decide +kernel
theorem a104_0_8_band3 : bandStats 16313785 16324696 2155 598 = (-5, 76428, -505) := by decide +kernel

end QuarticKernel.KernelPrefixes
