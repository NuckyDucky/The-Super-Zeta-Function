import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_2_band4 : bandStats 16800999 16812961 2583 507 = (-13, -37953, -503) := by decide +kernel
theorem a107_0_2_band5 : bandStats 16800999 16812961 3090 413 = (-34, -171001, -517) := by decide +kernel
theorem a107_0_2_band6 : bandStats 16800999 16812961 3503 313 = (-26, -185513, -513) := by decide +kernel
theorem a107_0_2_band7 : bandStats 16800999 16812961 3816 197 = (-27, -37228, -509) := by decide +kernel

end QuarticKernel.KernelPrefixes
