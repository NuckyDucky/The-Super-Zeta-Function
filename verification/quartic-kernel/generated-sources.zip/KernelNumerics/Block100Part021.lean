import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_9_band3 : bandStats 15720712 15728640 2768 635 = (-30, -45061, -515) := by decide +kernel
theorem a100_0_9_band4 : bandStats 15720712 15728640 3403 405 = (-59, -138400, -530) := by decide +kernel
theorem a100_0_9_band5 : bandStats 15720712 15728640 3808 155 = (-6, -63115, -488) := by decide +kernel
theorem a100_0_9_band6 : bandStats 15720712 15728640 3963 2 = (-13, -46648, -67) := by decide +kernel

end QuarticKernel.KernelPrefixes
