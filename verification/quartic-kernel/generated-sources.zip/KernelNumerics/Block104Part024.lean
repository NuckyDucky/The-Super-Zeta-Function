import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_10_band6 : bandStats 16335775 16346796 3620 269 = (14, 38610, -491) := by decide +kernel
theorem a104_0_10_band7 : bandStats 16335775 16346796 3889 136 = (24, 180742, -484) := by decide +kernel
theorem a104_0_10_band8 : bandStats 16335775 16346796 4025 18 = (-11, -176497, -255) := by decide +kernel
theorem a104_0_11_band0 : bandStats 16346796 16357993 0 735 = (-51, -290676, -523) := by decide +kernel

end QuarticKernel.KernelPrefixes
