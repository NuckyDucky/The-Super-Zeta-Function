import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_5_band7 : bandStats 16621161 16632849 3836 183 = (-21, -165134, -507) := by decide +kernel
theorem a106_0_5_band8 : bandStats 16621161 16632849 4019 59 = (23, 302516, -484) := by decide +kernel
theorem a106_0_6_band0 : bandStats 16632849 16644624 0 714 = (-14, 30637, -505) := by decide +kernel
theorem a106_0_6_band1 : bandStats 16632849 16644624 714 680 = (-17, 40708, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
