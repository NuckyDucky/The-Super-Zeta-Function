import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_1_band8 : bandStats 16068483 16078900 4008 1 = (-17, -71390, -49) := by decide +kernel
theorem a103_0_2_band0 : bandStats 16078900 16089444 0 761 = (14, 152955, -490) := by decide +kernel
theorem a103_0_2_band1 : bandStats 16078900 16089444 761 750 = (42, 138529, -481) := by decide +kernel
theorem a103_0_2_band2 : bandStats 16078900 16089444 1511 690 = (13, 42609, -491) := by decide +kernel

end QuarticKernel.KernelPrefixes
