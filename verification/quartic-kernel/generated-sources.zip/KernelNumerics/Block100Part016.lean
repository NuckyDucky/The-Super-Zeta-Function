import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a100_0_7_band1 : bandStats 15698545 15709524 732 716 = (-8, -35110, -501) := by decide +kernel
theorem a100_0_7_band2 : bandStats 15698545 15709524 1448 661 = (72, 443980, -463) := by decide +kernel
theorem a100_0_7_band3 : bandStats 15698545 15709524 2109 586 = (15, -9985, -495) := by decide +kernel
theorem a100_0_7_band4 : bandStats 15698545 15709524 2695 492 = (19, -203, -488) := by decide +kernel

end QuarticKernel.KernelPrefixes
