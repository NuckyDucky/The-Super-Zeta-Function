import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_2_band0 : bandStats 16976284 16988451 0 698 = (7, 47993, -496) := by decide +kernel
theorem a108_0_2_band1 : bandStats 16976284 16988451 698 676 = (15, 203782, -487) := by decide +kernel
theorem a108_0_2_band2 : bandStats 16976284 16988451 1374 630 = (17, 41081, -487) := by decide +kernel
theorem a108_0_2_band3 : bandStats 16976284 16988451 2004 576 = (38, 395481, -481) := by decide +kernel

end QuarticKernel.KernelPrefixes
