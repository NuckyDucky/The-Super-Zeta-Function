import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_10_band10 : bandStats 17436003 17449008 4176 1 = (2, 1306, -19) := by decide +kernel
theorem a110_0_11_band0 : bandStats 17449008 17462184 0 655 = (-9, 89255, -502) := by decide +kernel
theorem a110_0_11_band1 : bandStats 17449008 17462184 655 631 = (-4, -59200, -498) := by decide +kernel
theorem a110_0_11_band2 : bandStats 17449008 17462184 1286 600 = (12, 254636, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
