import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_3_band6 : bandStats 16988451 17000872 3428 330 = (-27, -304974, -513) := by decide +kernel
theorem a108_0_3_band7 : bandStats 16988451 17000872 3758 226 = (2, -43754, -497) := by decide +kernel
theorem a108_0_3_band8 : bandStats 16988451 17000872 3984 119 = (-57, -377789, -527) := by decide +kernel
theorem a108_0_3_band9 : bandStats 16988451 17000872 4103 20 = (17, 100611, -288) := by decide +kernel

end QuarticKernel.KernelPrefixes
