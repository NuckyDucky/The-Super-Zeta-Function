import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_5_band2 : bandStats 16836576 16848744 1365 629 = (27, 59679, -485) := by decide +kernel
theorem a107_0_5_band3 : bandStats 16836576 16848744 1994 574 = (-59, -252435, -527) := by decide +kernel
theorem a107_0_5_band4 : bandStats 16836576 16848744 2568 505 = (-2, 67247, -498) := by decide +kernel
theorem a107_0_5_band5 : bandStats 16836576 16848744 3073 415 = (-41, -332349, -520) := by decide +kernel

end QuarticKernel.KernelPrefixes
