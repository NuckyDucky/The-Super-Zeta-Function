import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_0_band4 : bandStats 16777216 16788905 2613 509 = (81, 409049, -458) := by decide +kernel
theorem a107_0_0_band5 : bandStats 16777216 16788905 3122 414 = (34, 229525, -481) := by decide +kernel
theorem a107_0_0_band6 : bandStats 16777216 16788905 3536 302 = (-21, -60430, -508) := by decide +kernel
theorem a107_0_0_band7 : bandStats 16777216 16788905 3838 190 = (9, 132605, -490) := by decide +kernel

end QuarticKernel.KernelPrefixes
