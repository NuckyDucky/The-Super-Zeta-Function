import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a105_0_1_band7 : bandStats 16405384 16416841 3851 161 = (-19, -90973, -504) := by decide +kernel
theorem a105_0_1_band8 : bandStats 16405384 16416841 4012 39 = (-17, -10596, -392) := by decide +kernel
theorem a105_0_2_band0 : bandStats 16416841 16428113 0 723 = (-46, -433625, -522) := by decide +kernel
theorem a105_0_2_band1 : bandStats 16416841 16428113 723 702 = (-38, -253546, -517) := by decide +kernel

end QuarticKernel.KernelPrefixes
