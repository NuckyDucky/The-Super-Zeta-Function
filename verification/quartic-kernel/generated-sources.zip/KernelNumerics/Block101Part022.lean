import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a101_0_9_band7 : bandStats 15825464 15836300 3851 119 = (-23, -140812, -512) := by decide +kernel
theorem a101_0_9_band8 : bandStats 15825464 15836300 3970 9 = (-16, -55266, -179) := by decide +kernel
theorem a101_0_10_band0 : bandStats 15836300 15847153 0 757 = (7, 36034, -496) := by decide +kernel
theorem a101_0_10_band1 : bandStats 15836300 15847153 757 717 = (-24, -151864, -512) := by decide +kernel

end QuarticKernel.KernelPrefixes
