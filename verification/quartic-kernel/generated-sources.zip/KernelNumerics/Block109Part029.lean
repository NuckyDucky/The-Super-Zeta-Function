import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_11_band5 : bandStats 17268625 17281300 3008 420 = (-12, -377, -504) := by decide +kernel
theorem a109_0_11_band6 : bandStats 17268625 17281300 3428 332 = (25, 98616, -485) := by decide +kernel
theorem a109_0_11_band7 : bandStats 17268625 17281300 3760 235 = (34, 265128, -483) := by decide +kernel
theorem a109_0_11_band8 : bandStats 17268625 17281300 3995 132 = (16, -67656, -484) := by decide +kernel

end QuarticKernel.KernelPrefixes
