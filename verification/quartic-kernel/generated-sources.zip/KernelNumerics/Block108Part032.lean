import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_12_band8 : bandStats 17102424 17115156 3971 134 = (40, 312926, -479) := by decide +kernel
theorem a108_0_12_band9 : bandStats 17102424 17115156 4105 32 = (-4, -3267, -378) := by decide +kernel
theorem a108_0_13_band0 : bandStats 17115156 17127811 0 660 = (3, 75636, -495) := by decide +kernel
theorem a108_0_13_band1 : bandStats 17115156 17127811 660 651 = (6, 121158, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
