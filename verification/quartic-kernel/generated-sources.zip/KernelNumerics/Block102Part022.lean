import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a102_0_10_band0 : bandStats 15997409 16007539 0 823 = (-6, 132799, -502) := by decide +kernel
theorem a102_0_10_band1 : bandStats 15997409 16007539 823 769 = (4, 32095, -497) := by decide +kernel
theorem a102_0_10_band2 : bandStats 15997409 16007539 1592 702 = (29, 86799, -484) := by decide +kernel
theorem a102_0_10_band3 : bandStats 15997409 16007539 2294 616 = (16, 113559, -495) := by decide +kernel

end QuarticKernel.KernelPrefixes
