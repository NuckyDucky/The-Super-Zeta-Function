import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a107_0_6_band4 : bandStats 16848744 16860752 2585 497 = (5, 57328, -494) := by decide +kernel
theorem a107_0_6_band5 : bandStats 16848744 16860752 3082 412 = (-38, -245936, -519) := by decide +kernel
theorem a107_0_6_band6 : bandStats 16848744 16860752 3494 317 = (7, 284133, -498) := by decide +kernel
theorem a107_0_6_band7 : bandStats 16848744 16860752 3811 204 = (28, 123399, -482) := by decide +kernel

end QuarticKernel.KernelPrefixes
