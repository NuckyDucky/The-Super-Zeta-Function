import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a104_0_7_band1 : bandStats 16302916 16313785 758 726 = (-2, 10537, -499) := by decide +kernel
theorem a104_0_7_band2 : bandStats 16302916 16313785 1484 679 = (25, 60632, -484) := by decide +kernel
theorem a104_0_7_band3 : bandStats 16302916 16313785 2163 604 = (-4, -104600, -504) := by decide +kernel
theorem a104_0_7_band4 : bandStats 16302916 16313785 2767 505 = (-2, -58175, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
