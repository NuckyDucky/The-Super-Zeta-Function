import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_13_band8 : bandStats 16197641 16208675 4010 15 = (-6, 9359, -225) := by decide +kernel
theorem a103_0_14_band0 : bandStats 16208675 16219809 0 719 = (6, 145463, -497) := by decide +kernel
theorem a103_0_14_band1 : bandStats 16208675 16219809 719 712 = (4, -161933, -495) := by decide +kernel
theorem a103_0_14_band2 : bandStats 16208675 16219809 1431 665 = (12, 51621, -492) := by decide +kernel

end QuarticKernel.KernelPrefixes
