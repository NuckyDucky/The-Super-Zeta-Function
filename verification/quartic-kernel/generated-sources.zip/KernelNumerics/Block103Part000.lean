import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a103_0_0_band0 : bandStats 16058028 16068483 0 790 = (-58, -193834, -528) := by decide +kernel
theorem a103_0_0_band1 : bandStats 16058028 16068483 790 747 = (-16, 39141, -508) := by decide +kernel
theorem a103_0_0_band2 : bandStats 16058028 16068483 1537 693 = (6, 83622, -496) := by decide +kernel
theorem a103_0_0_band3 : bandStats 16058028 16068483 2230 615 = (-21, -125204, -508) := by decide +kernel

end QuarticKernel.KernelPrefixes
