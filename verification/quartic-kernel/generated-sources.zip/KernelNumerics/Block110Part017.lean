import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_6_band8 : bandStats 17384116 17396999 3989 141 = (-20, -51215, -506) := by decide +kernel
theorem a110_0_6_band9 : bandStats 17384116 17396999 4130 40 = (15, 81759, -411) := by decide +kernel
theorem a110_0_7_band0 : bandStats 17396999 17409844 0 650 = (25, 150259, -484) := by decide +kernel
theorem a110_0_7_band1 : bandStats 17396999 17409844 650 644 = (-2, -130579, -498) := by decide +kernel

end QuarticKernel.KernelPrefixes
