import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_13_band6 : bandStats 17475124 17487268 3560 319 = (-15, -60215, -503) := by decide +kernel
theorem a110_0_13_band7 : bandStats 17475124 17487268 3879 207 = (11, 29373, -490) := by decide +kernel
theorem a110_0_13_band8 : bandStats 17475124 17487268 4086 90 = (-9, -389307, -496) := by decide +kernel
theorem a110_0_13_band9 : bandStats 17475124 17487268 4176 5 = (-30, -153488, -145) := by decide +kernel

end QuarticKernel.KernelPrefixes
