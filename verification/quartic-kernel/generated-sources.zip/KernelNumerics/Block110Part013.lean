import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_5_band2 : bandStats 17371240 17384116 1293 608 = (28, 228389, -483) := by decide +kernel
theorem a110_0_5_band3 : bandStats 17371240 17384116 1901 563 = (-11, -258510, -504) := by decide +kernel
theorem a110_0_5_band4 : bandStats 17371240 17384116 2464 502 = (-17, -41688, -498) := by decide +kernel
theorem a110_0_5_band5 : bandStats 17371240 17384116 2966 424 = (3, 52063, -494) := by decide +kernel

end QuarticKernel.KernelPrefixes
