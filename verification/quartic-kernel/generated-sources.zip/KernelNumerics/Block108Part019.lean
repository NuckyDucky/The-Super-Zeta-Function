import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_7_band6 : bandStats 17038833 17051683 3372 335 = (-21, -416105, -508) := by decide +kernel
theorem a108_0_7_band7 : bandStats 17038833 17051683 3707 240 = (7, 59970, -496) := by decide +kernel
theorem a108_0_7_band8 : bandStats 17038833 17051683 3947 142 = (14, -155558, -488) := by decide +kernel
theorem a108_0_7_band9 : bandStats 17038833 17051683 4089 40 = (-4, -162784, -443) := by decide +kernel

end QuarticKernel.KernelPrefixes
