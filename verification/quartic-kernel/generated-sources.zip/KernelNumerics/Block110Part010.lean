import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a110_0_4_band0 : bandStats 17358249 17371240 0 666 = (-5, -27217, -501) := by decide +kernel
theorem a110_0_4_band1 : bandStats 17358249 17371240 666 638 = (13, -25217, -490) := by decide +kernel
theorem a110_0_4_band2 : bandStats 17358249 17371240 1304 612 = (-49, -433065, -522) := by decide +kernel
theorem a110_0_4_band3 : bandStats 17358249 17371240 1916 553 = (8, -28043, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
