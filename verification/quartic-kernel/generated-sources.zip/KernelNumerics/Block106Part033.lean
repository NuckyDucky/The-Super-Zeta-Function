import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a106_0_14_band5 : bandStats 16723764 16735292 3183 403 = (-10, -30999, -501) := by decide +kernel
theorem a106_0_14_band6 : bandStats 16723764 16735292 3586 291 = (-17, -145035, -508) := by decide +kernel
theorem a106_0_14_band7 : bandStats 16723764 16735292 3877 169 = (32, 492411, -481) := by decide +kernel
theorem a106_0_14_band8 : bandStats 16723764 16735292 4046 44 = (-17, -138381, -412) := by decide +kernel

end QuarticKernel.KernelPrefixes
