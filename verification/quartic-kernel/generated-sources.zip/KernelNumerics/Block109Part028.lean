import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_11_band1 : bandStats 17268625 17281300 672 654 = (-29, -294207, -514) := by decide +kernel
theorem a109_0_11_band2 : bandStats 17268625 17281300 1326 613 = (-29, -408361, -512) := by decide +kernel
theorem a109_0_11_band3 : bandStats 17268625 17281300 1939 563 = (-31, -243855, -514) := by decide +kernel
theorem a109_0_11_band4 : bandStats 17268625 17281300 2502 506 = (-70, -804442, -521) := by decide +kernel

end QuarticKernel.KernelPrefixes
