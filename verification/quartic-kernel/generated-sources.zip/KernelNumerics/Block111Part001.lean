import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a111_0_0_band4 : bandStats 17487268 17499832 2523 502 = (37, 65321, -478) := by decide +kernel
theorem a111_0_0_band5 : bandStats 17487268 17499832 3025 429 = (1, -158299, -498) := by decide +kernel
theorem a111_0_0_band6 : bandStats 17487268 17499832 3454 337 = (2, -181933, -500) := by decide +kernel
theorem a111_0_0_band7 : bandStats 17487268 17499832 3791 236 = (3, 23825, -497) := by decide +kernel

end QuarticKernel.KernelPrefixes
