import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a109_0_4_band4 : bandStats 17179180 17191708 2507 508 = (-31, -277531, -517) := by decide +kernel
theorem a109_0_4_band5 : bandStats 17179180 17191708 3015 420 = (1, 80177, -498) := by decide +kernel
theorem a109_0_4_band6 : bandStats 17179180 17191708 3435 329 = (1, -59949, -498) := by decide +kernel
theorem a109_0_4_band7 : bandStats 17179180 17191708 3764 231 = (-4, 118247, -500) := by decide +kernel

end QuarticKernel.KernelPrefixes
