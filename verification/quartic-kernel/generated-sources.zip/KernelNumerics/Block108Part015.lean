import QuarticAnnulusBands

namespace QuarticKernel.KernelPrefixes

set_option maxRecDepth 24000
set_option maxHeartbeats 0
set_option Elab.async false

theorem a108_0_6_band0 : bandStats 17025936 17038833 0 662 = (-25, -187880, -511) := by decide +kernel
theorem a108_0_6_band1 : bandStats 17025936 17038833 662 632 = (51, 288627, -471) := by decide +kernel
theorem a108_0_6_band2 : bandStats 17025936 17038833 1294 604 = (1, -102278, -496) := by decide +kernel
theorem a108_0_6_band3 : bandStats 17025936 17038833 1898 555 = (3, -109103, -493) := by decide +kernel

end QuarticKernel.KernelPrefixes
