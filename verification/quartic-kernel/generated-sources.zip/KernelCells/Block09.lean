import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell144 : checkCoreCellRange 144 1 = true := by
  decide +kernel

private theorem cell145 : checkCoreCellRange 145 1 = true := by
  decide +kernel

private theorem cell146 : checkCoreCellRange 146 1 = true := by
  decide +kernel

private theorem cell147 : checkCoreCellRange 147 1 = true := by
  decide +kernel

private theorem cell148 : checkCoreCellRange 148 1 = true := by
  decide +kernel

private theorem cell149 : checkCoreCellRange 149 1 = true := by
  decide +kernel

private theorem cell150 : checkCoreCellRange 150 1 = true := by
  decide +kernel

private theorem cell151 : checkCoreCellRange 151 1 = true := by
  decide +kernel

private theorem cell152 : checkCoreCellRange 152 1 = true := by
  decide +kernel

private theorem cell153 : checkCoreCellRange 153 1 = true := by
  decide +kernel

private theorem cell154 : checkCoreCellRange 154 1 = true := by
  decide +kernel

private theorem cell155 : checkCoreCellRange 155 1 = true := by
  decide +kernel

private theorem cell156 : checkCoreCellRange 156 1 = true := by
  decide +kernel

private theorem cell157 : checkCoreCellRange 157 1 = true := by
  decide +kernel

private theorem cell158 : checkCoreCellRange 158 1 = true := by
  decide +kernel

private theorem cell159 : checkCoreCellRange 159 1 = true := by
  decide +kernel

theorem block9 : checkCoreCellRange 144 16 = true :=
  checkCoreCellRange_succ 144 15 (checkCoreCellRange_succ 144 14 (checkCoreCellRange_succ 144 13 (checkCoreCellRange_succ 144 12 (checkCoreCellRange_succ 144 11 (checkCoreCellRange_succ 144 10 (checkCoreCellRange_succ 144 9 (checkCoreCellRange_succ 144 8 (checkCoreCellRange_succ 144 7 (checkCoreCellRange_succ 144 6 (checkCoreCellRange_succ 144 5 (checkCoreCellRange_succ 144 4 (checkCoreCellRange_succ 144 3 (checkCoreCellRange_succ 144 2 (checkCoreCellRange_succ 144 1 (checkCoreCellRange_succ 144 0 rfl cell144) cell145) cell146) cell147) cell148) cell149) cell150) cell151) cell152) cell153) cell154) cell155) cell156) cell157) cell158) cell159

#print axioms block9

end QuarticKernel.KernelCells
