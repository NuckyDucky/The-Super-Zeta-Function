import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell528 : checkCoreCellRange 528 1 = true := by
  decide +kernel

private theorem cell529 : checkCoreCellRange 529 1 = true := by
  decide +kernel

private theorem cell530 : checkCoreCellRange 530 1 = true := by
  decide +kernel

private theorem cell531 : checkCoreCellRange 531 1 = true := by
  decide +kernel

private theorem cell532 : checkCoreCellRange 532 1 = true := by
  decide +kernel

private theorem cell533 : checkCoreCellRange 533 1 = true := by
  decide +kernel

private theorem cell534 : checkCoreCellRange 534 1 = true := by
  decide +kernel

private theorem cell535 : checkCoreCellRange 535 1 = true := by
  decide +kernel

private theorem cell536 : checkCoreCellRange 536 1 = true := by
  decide +kernel

private theorem cell537 : checkCoreCellRange 537 1 = true := by
  decide +kernel

private theorem cell538 : checkCoreCellRange 538 1 = true := by
  decide +kernel

private theorem cell539 : checkCoreCellRange 539 1 = true := by
  decide +kernel

private theorem cell540 : checkCoreCellRange 540 1 = true := by
  decide +kernel

private theorem cell541 : checkCoreCellRange 541 1 = true := by
  decide +kernel

private theorem cell542 : checkCoreCellRange 542 1 = true := by
  decide +kernel

private theorem cell543 : checkCoreCellRange 543 1 = true := by
  decide +kernel

theorem block33 : checkCoreCellRange 528 16 = true :=
  checkCoreCellRange_succ 528 15 (checkCoreCellRange_succ 528 14 (checkCoreCellRange_succ 528 13 (checkCoreCellRange_succ 528 12 (checkCoreCellRange_succ 528 11 (checkCoreCellRange_succ 528 10 (checkCoreCellRange_succ 528 9 (checkCoreCellRange_succ 528 8 (checkCoreCellRange_succ 528 7 (checkCoreCellRange_succ 528 6 (checkCoreCellRange_succ 528 5 (checkCoreCellRange_succ 528 4 (checkCoreCellRange_succ 528 3 (checkCoreCellRange_succ 528 2 (checkCoreCellRange_succ 528 1 (checkCoreCellRange_succ 528 0 rfl cell528) cell529) cell530) cell531) cell532) cell533) cell534) cell535) cell536) cell537) cell538) cell539) cell540) cell541) cell542) cell543

#print axioms block33

end QuarticKernel.KernelCells
