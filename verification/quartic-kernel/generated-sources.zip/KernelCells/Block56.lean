import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell896 : checkCoreCellRange 896 1 = true := by
  decide +kernel

private theorem cell897 : checkCoreCellRange 897 1 = true := by
  decide +kernel

private theorem cell898 : checkCoreCellRange 898 1 = true := by
  decide +kernel

private theorem cell899 : checkCoreCellRange 899 1 = true := by
  decide +kernel

private theorem cell900 : checkCoreCellRange 900 1 = true := by
  decide +kernel

private theorem cell901 : checkCoreCellRange 901 1 = true := by
  decide +kernel

private theorem cell902 : checkCoreCellRange 902 1 = true := by
  decide +kernel

private theorem cell903 : checkCoreCellRange 903 1 = true := by
  decide +kernel

private theorem cell904 : checkCoreCellRange 904 1 = true := by
  decide +kernel

private theorem cell905 : checkCoreCellRange 905 1 = true := by
  decide +kernel

private theorem cell906 : checkCoreCellRange 906 1 = true := by
  decide +kernel

private theorem cell907 : checkCoreCellRange 907 1 = true := by
  decide +kernel

private theorem cell908 : checkCoreCellRange 908 1 = true := by
  decide +kernel

private theorem cell909 : checkCoreCellRange 909 1 = true := by
  decide +kernel

private theorem cell910 : checkCoreCellRange 910 1 = true := by
  decide +kernel

private theorem cell911 : checkCoreCellRange 911 1 = true := by
  decide +kernel

theorem block56 : checkCoreCellRange 896 16 = true :=
  checkCoreCellRange_succ 896 15 (checkCoreCellRange_succ 896 14 (checkCoreCellRange_succ 896 13 (checkCoreCellRange_succ 896 12 (checkCoreCellRange_succ 896 11 (checkCoreCellRange_succ 896 10 (checkCoreCellRange_succ 896 9 (checkCoreCellRange_succ 896 8 (checkCoreCellRange_succ 896 7 (checkCoreCellRange_succ 896 6 (checkCoreCellRange_succ 896 5 (checkCoreCellRange_succ 896 4 (checkCoreCellRange_succ 896 3 (checkCoreCellRange_succ 896 2 (checkCoreCellRange_succ 896 1 (checkCoreCellRange_succ 896 0 rfl cell896) cell897) cell898) cell899) cell900) cell901) cell902) cell903) cell904) cell905) cell906) cell907) cell908) cell909) cell910) cell911

#print axioms block56

end QuarticKernel.KernelCells
