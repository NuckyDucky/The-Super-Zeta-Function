import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell416 : checkCoreCellRange 416 1 = true := by
  decide +kernel

private theorem cell417 : checkCoreCellRange 417 1 = true := by
  decide +kernel

private theorem cell418 : checkCoreCellRange 418 1 = true := by
  decide +kernel

private theorem cell419 : checkCoreCellRange 419 1 = true := by
  decide +kernel

private theorem cell420 : checkCoreCellRange 420 1 = true := by
  decide +kernel

private theorem cell421 : checkCoreCellRange 421 1 = true := by
  decide +kernel

private theorem cell422 : checkCoreCellRange 422 1 = true := by
  decide +kernel

private theorem cell423 : checkCoreCellRange 423 1 = true := by
  decide +kernel

private theorem cell424 : checkCoreCellRange 424 1 = true := by
  decide +kernel

private theorem cell425 : checkCoreCellRange 425 1 = true := by
  decide +kernel

private theorem cell426 : checkCoreCellRange 426 1 = true := by
  decide +kernel

private theorem cell427 : checkCoreCellRange 427 1 = true := by
  decide +kernel

private theorem cell428 : checkCoreCellRange 428 1 = true := by
  decide +kernel

private theorem cell429 : checkCoreCellRange 429 1 = true := by
  decide +kernel

private theorem cell430 : checkCoreCellRange 430 1 = true := by
  decide +kernel

private theorem cell431 : checkCoreCellRange 431 1 = true := by
  decide +kernel

theorem block26 : checkCoreCellRange 416 16 = true :=
  checkCoreCellRange_succ 416 15 (checkCoreCellRange_succ 416 14 (checkCoreCellRange_succ 416 13 (checkCoreCellRange_succ 416 12 (checkCoreCellRange_succ 416 11 (checkCoreCellRange_succ 416 10 (checkCoreCellRange_succ 416 9 (checkCoreCellRange_succ 416 8 (checkCoreCellRange_succ 416 7 (checkCoreCellRange_succ 416 6 (checkCoreCellRange_succ 416 5 (checkCoreCellRange_succ 416 4 (checkCoreCellRange_succ 416 3 (checkCoreCellRange_succ 416 2 (checkCoreCellRange_succ 416 1 (checkCoreCellRange_succ 416 0 rfl cell416) cell417) cell418) cell419) cell420) cell421) cell422) cell423) cell424) cell425) cell426) cell427) cell428) cell429) cell430) cell431

#print axioms block26

end QuarticKernel.KernelCells
