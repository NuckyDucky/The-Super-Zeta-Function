import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell1040 : checkCoreCellRange 1040 1 = true := by
  decide +kernel

private theorem cell1041 : checkCoreCellRange 1041 1 = true := by
  decide +kernel

private theorem cell1042 : checkCoreCellRange 1042 1 = true := by
  decide +kernel

private theorem cell1043 : checkCoreCellRange 1043 1 = true := by
  decide +kernel

private theorem cell1044 : checkCoreCellRange 1044 1 = true := by
  decide +kernel

private theorem cell1045 : checkCoreCellRange 1045 1 = true := by
  decide +kernel

private theorem cell1046 : checkCoreCellRange 1046 1 = true := by
  decide +kernel

private theorem cell1047 : checkCoreCellRange 1047 1 = true := by
  decide +kernel

private theorem cell1048 : checkCoreCellRange 1048 1 = true := by
  decide +kernel

private theorem cell1049 : checkCoreCellRange 1049 1 = true := by
  decide +kernel

private theorem cell1050 : checkCoreCellRange 1050 1 = true := by
  decide +kernel

theorem block65 : checkCoreCellRange 1040 11 = true :=
  checkCoreCellRange_succ 1040 10 (checkCoreCellRange_succ 1040 9 (checkCoreCellRange_succ 1040 8 (checkCoreCellRange_succ 1040 7 (checkCoreCellRange_succ 1040 6 (checkCoreCellRange_succ 1040 5 (checkCoreCellRange_succ 1040 4 (checkCoreCellRange_succ 1040 3 (checkCoreCellRange_succ 1040 2 (checkCoreCellRange_succ 1040 1 (checkCoreCellRange_succ 1040 0 rfl cell1040) cell1041) cell1042) cell1043) cell1044) cell1045) cell1046) cell1047) cell1048) cell1049) cell1050

#print axioms block65

end QuarticKernel.KernelCells
