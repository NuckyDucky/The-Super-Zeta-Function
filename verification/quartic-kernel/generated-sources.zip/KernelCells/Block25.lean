import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell400 : checkCoreCellRange 400 1 = true := by
  decide +kernel

private theorem cell401 : checkCoreCellRange 401 1 = true := by
  decide +kernel

private theorem cell402 : checkCoreCellRange 402 1 = true := by
  decide +kernel

private theorem cell403 : checkCoreCellRange 403 1 = true := by
  decide +kernel

private theorem cell404 : checkCoreCellRange 404 1 = true := by
  decide +kernel

private theorem cell405 : checkCoreCellRange 405 1 = true := by
  decide +kernel

private theorem cell406 : checkCoreCellRange 406 1 = true := by
  decide +kernel

private theorem cell407 : checkCoreCellRange 407 1 = true := by
  decide +kernel

private theorem cell408 : checkCoreCellRange 408 1 = true := by
  decide +kernel

private theorem cell409 : checkCoreCellRange 409 1 = true := by
  decide +kernel

private theorem cell410 : checkCoreCellRange 410 1 = true := by
  decide +kernel

private theorem cell411 : checkCoreCellRange 411 1 = true := by
  decide +kernel

private theorem cell412 : checkCoreCellRange 412 1 = true := by
  decide +kernel

private theorem cell413 : checkCoreCellRange 413 1 = true := by
  decide +kernel

private theorem cell414 : checkCoreCellRange 414 1 = true := by
  decide +kernel

private theorem cell415 : checkCoreCellRange 415 1 = true := by
  decide +kernel

theorem block25 : checkCoreCellRange 400 16 = true :=
  checkCoreCellRange_succ 400 15 (checkCoreCellRange_succ 400 14 (checkCoreCellRange_succ 400 13 (checkCoreCellRange_succ 400 12 (checkCoreCellRange_succ 400 11 (checkCoreCellRange_succ 400 10 (checkCoreCellRange_succ 400 9 (checkCoreCellRange_succ 400 8 (checkCoreCellRange_succ 400 7 (checkCoreCellRange_succ 400 6 (checkCoreCellRange_succ 400 5 (checkCoreCellRange_succ 400 4 (checkCoreCellRange_succ 400 3 (checkCoreCellRange_succ 400 2 (checkCoreCellRange_succ 400 1 (checkCoreCellRange_succ 400 0 rfl cell400) cell401) cell402) cell403) cell404) cell405) cell406) cell407) cell408) cell409) cell410) cell411) cell412) cell413) cell414) cell415

#print axioms block25

end QuarticKernel.KernelCells
