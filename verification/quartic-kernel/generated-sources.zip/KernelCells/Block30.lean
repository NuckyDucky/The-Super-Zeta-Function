import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell480 : checkCoreCellRange 480 1 = true := by
  decide +kernel

private theorem cell481 : checkCoreCellRange 481 1 = true := by
  decide +kernel

private theorem cell482 : checkCoreCellRange 482 1 = true := by
  decide +kernel

private theorem cell483 : checkCoreCellRange 483 1 = true := by
  decide +kernel

private theorem cell484 : checkCoreCellRange 484 1 = true := by
  decide +kernel

private theorem cell485 : checkCoreCellRange 485 1 = true := by
  decide +kernel

private theorem cell486 : checkCoreCellRange 486 1 = true := by
  decide +kernel

private theorem cell487 : checkCoreCellRange 487 1 = true := by
  decide +kernel

private theorem cell488 : checkCoreCellRange 488 1 = true := by
  decide +kernel

private theorem cell489 : checkCoreCellRange 489 1 = true := by
  decide +kernel

private theorem cell490 : checkCoreCellRange 490 1 = true := by
  decide +kernel

private theorem cell491 : checkCoreCellRange 491 1 = true := by
  decide +kernel

private theorem cell492 : checkCoreCellRange 492 1 = true := by
  decide +kernel

private theorem cell493 : checkCoreCellRange 493 1 = true := by
  decide +kernel

private theorem cell494 : checkCoreCellRange 494 1 = true := by
  decide +kernel

private theorem cell495 : checkCoreCellRange 495 1 = true := by
  decide +kernel

theorem block30 : checkCoreCellRange 480 16 = true :=
  checkCoreCellRange_succ 480 15 (checkCoreCellRange_succ 480 14 (checkCoreCellRange_succ 480 13 (checkCoreCellRange_succ 480 12 (checkCoreCellRange_succ 480 11 (checkCoreCellRange_succ 480 10 (checkCoreCellRange_succ 480 9 (checkCoreCellRange_succ 480 8 (checkCoreCellRange_succ 480 7 (checkCoreCellRange_succ 480 6 (checkCoreCellRange_succ 480 5 (checkCoreCellRange_succ 480 4 (checkCoreCellRange_succ 480 3 (checkCoreCellRange_succ 480 2 (checkCoreCellRange_succ 480 1 (checkCoreCellRange_succ 480 0 rfl cell480) cell481) cell482) cell483) cell484) cell485) cell486) cell487) cell488) cell489) cell490) cell491) cell492) cell493) cell494) cell495

#print axioms block30

end QuarticKernel.KernelCells
