import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell0 : checkCoreCellRange 0 1 = true := by
  decide +kernel

private theorem cell1 : checkCoreCellRange 1 1 = true := by
  decide +kernel

private theorem cell2 : checkCoreCellRange 2 1 = true := by
  decide +kernel

private theorem cell3 : checkCoreCellRange 3 1 = true := by
  decide +kernel

private theorem cell4 : checkCoreCellRange 4 1 = true := by
  decide +kernel

private theorem cell5 : checkCoreCellRange 5 1 = true := by
  decide +kernel

private theorem cell6 : checkCoreCellRange 6 1 = true := by
  decide +kernel

private theorem cell7 : checkCoreCellRange 7 1 = true := by
  decide +kernel

private theorem cell8 : checkCoreCellRange 8 1 = true := by
  decide +kernel

private theorem cell9 : checkCoreCellRange 9 1 = true := by
  decide +kernel

private theorem cell10 : checkCoreCellRange 10 1 = true := by
  decide +kernel

private theorem cell11 : checkCoreCellRange 11 1 = true := by
  decide +kernel

private theorem cell12 : checkCoreCellRange 12 1 = true := by
  decide +kernel

private theorem cell13 : checkCoreCellRange 13 1 = true := by
  decide +kernel

private theorem cell14 : checkCoreCellRange 14 1 = true := by
  decide +kernel

private theorem cell15 : checkCoreCellRange 15 1 = true := by
  decide +kernel

theorem block0 : checkCoreCellRange 0 16 = true :=
  checkCoreCellRange_succ 0 15 (checkCoreCellRange_succ 0 14 (checkCoreCellRange_succ 0 13 (checkCoreCellRange_succ 0 12 (checkCoreCellRange_succ 0 11 (checkCoreCellRange_succ 0 10 (checkCoreCellRange_succ 0 9 (checkCoreCellRange_succ 0 8 (checkCoreCellRange_succ 0 7 (checkCoreCellRange_succ 0 6 (checkCoreCellRange_succ 0 5 (checkCoreCellRange_succ 0 4 (checkCoreCellRange_succ 0 3 (checkCoreCellRange_succ 0 2 (checkCoreCellRange_succ 0 1 (checkCoreCellRange_succ 0 0 rfl cell0) cell1) cell2) cell3) cell4) cell5) cell6) cell7) cell8) cell9) cell10) cell11) cell12) cell13) cell14) cell15

#print axioms block0

end QuarticKernel.KernelCells
