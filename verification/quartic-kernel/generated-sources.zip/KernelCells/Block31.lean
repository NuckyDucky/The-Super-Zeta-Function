import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell496 : checkCoreCellRange 496 1 = true := by
  decide +kernel

private theorem cell497 : checkCoreCellRange 497 1 = true := by
  decide +kernel

private theorem cell498 : checkCoreCellRange 498 1 = true := by
  decide +kernel

private theorem cell499 : checkCoreCellRange 499 1 = true := by
  decide +kernel

private theorem cell500 : checkCoreCellRange 500 1 = true := by
  decide +kernel

private theorem cell501 : checkCoreCellRange 501 1 = true := by
  decide +kernel

private theorem cell502 : checkCoreCellRange 502 1 = true := by
  decide +kernel

private theorem cell503 : checkCoreCellRange 503 1 = true := by
  decide +kernel

private theorem cell504 : checkCoreCellRange 504 1 = true := by
  decide +kernel

private theorem cell505 : checkCoreCellRange 505 1 = true := by
  decide +kernel

private theorem cell506 : checkCoreCellRange 506 1 = true := by
  decide +kernel

private theorem cell507 : checkCoreCellRange 507 1 = true := by
  decide +kernel

private theorem cell508 : checkCoreCellRange 508 1 = true := by
  decide +kernel

private theorem cell509 : checkCoreCellRange 509 1 = true := by
  decide +kernel

private theorem cell510 : checkCoreCellRange 510 1 = true := by
  decide +kernel

private theorem cell511 : checkCoreCellRange 511 1 = true := by
  decide +kernel

theorem block31 : checkCoreCellRange 496 16 = true :=
  checkCoreCellRange_succ 496 15 (checkCoreCellRange_succ 496 14 (checkCoreCellRange_succ 496 13 (checkCoreCellRange_succ 496 12 (checkCoreCellRange_succ 496 11 (checkCoreCellRange_succ 496 10 (checkCoreCellRange_succ 496 9 (checkCoreCellRange_succ 496 8 (checkCoreCellRange_succ 496 7 (checkCoreCellRange_succ 496 6 (checkCoreCellRange_succ 496 5 (checkCoreCellRange_succ 496 4 (checkCoreCellRange_succ 496 3 (checkCoreCellRange_succ 496 2 (checkCoreCellRange_succ 496 1 (checkCoreCellRange_succ 496 0 rfl cell496) cell497) cell498) cell499) cell500) cell501) cell502) cell503) cell504) cell505) cell506) cell507) cell508) cell509) cell510) cell511

#print axioms block31

end QuarticKernel.KernelCells
