import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell688 : checkCoreCellRange 688 1 = true := by
  decide +kernel

private theorem cell689 : checkCoreCellRange 689 1 = true := by
  decide +kernel

private theorem cell690 : checkCoreCellRange 690 1 = true := by
  decide +kernel

private theorem cell691 : checkCoreCellRange 691 1 = true := by
  decide +kernel

private theorem cell692 : checkCoreCellRange 692 1 = true := by
  decide +kernel

private theorem cell693 : checkCoreCellRange 693 1 = true := by
  decide +kernel

private theorem cell694 : checkCoreCellRange 694 1 = true := by
  decide +kernel

private theorem cell695 : checkCoreCellRange 695 1 = true := by
  decide +kernel

private theorem cell696 : checkCoreCellRange 696 1 = true := by
  decide +kernel

private theorem cell697 : checkCoreCellRange 697 1 = true := by
  decide +kernel

private theorem cell698 : checkCoreCellRange 698 1 = true := by
  decide +kernel

private theorem cell699 : checkCoreCellRange 699 1 = true := by
  decide +kernel

private theorem cell700 : checkCoreCellRange 700 1 = true := by
  decide +kernel

private theorem cell701 : checkCoreCellRange 701 1 = true := by
  decide +kernel

private theorem cell702 : checkCoreCellRange 702 1 = true := by
  decide +kernel

private theorem cell703 : checkCoreCellRange 703 1 = true := by
  decide +kernel

theorem block43 : checkCoreCellRange 688 16 = true :=
  checkCoreCellRange_succ 688 15 (checkCoreCellRange_succ 688 14 (checkCoreCellRange_succ 688 13 (checkCoreCellRange_succ 688 12 (checkCoreCellRange_succ 688 11 (checkCoreCellRange_succ 688 10 (checkCoreCellRange_succ 688 9 (checkCoreCellRange_succ 688 8 (checkCoreCellRange_succ 688 7 (checkCoreCellRange_succ 688 6 (checkCoreCellRange_succ 688 5 (checkCoreCellRange_succ 688 4 (checkCoreCellRange_succ 688 3 (checkCoreCellRange_succ 688 2 (checkCoreCellRange_succ 688 1 (checkCoreCellRange_succ 688 0 rfl cell688) cell689) cell690) cell691) cell692) cell693) cell694) cell695) cell696) cell697) cell698) cell699) cell700) cell701) cell702) cell703

#print axioms block43

end QuarticKernel.KernelCells
