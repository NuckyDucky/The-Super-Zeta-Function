import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell992 : checkCoreCellRange 992 1 = true := by
  decide +kernel

private theorem cell993 : checkCoreCellRange 993 1 = true := by
  decide +kernel

private theorem cell994 : checkCoreCellRange 994 1 = true := by
  decide +kernel

private theorem cell995 : checkCoreCellRange 995 1 = true := by
  decide +kernel

private theorem cell996 : checkCoreCellRange 996 1 = true := by
  decide +kernel

private theorem cell997 : checkCoreCellRange 997 1 = true := by
  decide +kernel

private theorem cell998 : checkCoreCellRange 998 1 = true := by
  decide +kernel

private theorem cell999 : checkCoreCellRange 999 1 = true := by
  decide +kernel

private theorem cell1000 : checkCoreCellRange 1000 1 = true := by
  decide +kernel

private theorem cell1001 : checkCoreCellRange 1001 1 = true := by
  decide +kernel

private theorem cell1002 : checkCoreCellRange 1002 1 = true := by
  decide +kernel

private theorem cell1003 : checkCoreCellRange 1003 1 = true := by
  decide +kernel

private theorem cell1004 : checkCoreCellRange 1004 1 = true := by
  decide +kernel

private theorem cell1005 : checkCoreCellRange 1005 1 = true := by
  decide +kernel

private theorem cell1006 : checkCoreCellRange 1006 1 = true := by
  decide +kernel

private theorem cell1007 : checkCoreCellRange 1007 1 = true := by
  decide +kernel

theorem block62 : checkCoreCellRange 992 16 = true :=
  checkCoreCellRange_succ 992 15 (checkCoreCellRange_succ 992 14 (checkCoreCellRange_succ 992 13 (checkCoreCellRange_succ 992 12 (checkCoreCellRange_succ 992 11 (checkCoreCellRange_succ 992 10 (checkCoreCellRange_succ 992 9 (checkCoreCellRange_succ 992 8 (checkCoreCellRange_succ 992 7 (checkCoreCellRange_succ 992 6 (checkCoreCellRange_succ 992 5 (checkCoreCellRange_succ 992 4 (checkCoreCellRange_succ 992 3 (checkCoreCellRange_succ 992 2 (checkCoreCellRange_succ 992 1 (checkCoreCellRange_succ 992 0 rfl cell992) cell993) cell994) cell995) cell996) cell997) cell998) cell999) cell1000) cell1001) cell1002) cell1003) cell1004) cell1005) cell1006) cell1007

#print axioms block62

end QuarticKernel.KernelCells
