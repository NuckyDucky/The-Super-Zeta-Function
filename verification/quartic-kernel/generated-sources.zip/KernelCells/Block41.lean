import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell656 : checkCoreCellRange 656 1 = true := by
  decide +kernel

private theorem cell657 : checkCoreCellRange 657 1 = true := by
  decide +kernel

private theorem cell658 : checkCoreCellRange 658 1 = true := by
  decide +kernel

private theorem cell659 : checkCoreCellRange 659 1 = true := by
  decide +kernel

private theorem cell660 : checkCoreCellRange 660 1 = true := by
  decide +kernel

private theorem cell661 : checkCoreCellRange 661 1 = true := by
  decide +kernel

private theorem cell662 : checkCoreCellRange 662 1 = true := by
  decide +kernel

private theorem cell663 : checkCoreCellRange 663 1 = true := by
  decide +kernel

private theorem cell664 : checkCoreCellRange 664 1 = true := by
  decide +kernel

private theorem cell665 : checkCoreCellRange 665 1 = true := by
  decide +kernel

private theorem cell666 : checkCoreCellRange 666 1 = true := by
  decide +kernel

private theorem cell667 : checkCoreCellRange 667 1 = true := by
  decide +kernel

private theorem cell668 : checkCoreCellRange 668 1 = true := by
  decide +kernel

private theorem cell669 : checkCoreCellRange 669 1 = true := by
  decide +kernel

private theorem cell670 : checkCoreCellRange 670 1 = true := by
  decide +kernel

private theorem cell671 : checkCoreCellRange 671 1 = true := by
  decide +kernel

theorem block41 : checkCoreCellRange 656 16 = true :=
  checkCoreCellRange_succ 656 15 (checkCoreCellRange_succ 656 14 (checkCoreCellRange_succ 656 13 (checkCoreCellRange_succ 656 12 (checkCoreCellRange_succ 656 11 (checkCoreCellRange_succ 656 10 (checkCoreCellRange_succ 656 9 (checkCoreCellRange_succ 656 8 (checkCoreCellRange_succ 656 7 (checkCoreCellRange_succ 656 6 (checkCoreCellRange_succ 656 5 (checkCoreCellRange_succ 656 4 (checkCoreCellRange_succ 656 3 (checkCoreCellRange_succ 656 2 (checkCoreCellRange_succ 656 1 (checkCoreCellRange_succ 656 0 rfl cell656) cell657) cell658) cell659) cell660) cell661) cell662) cell663) cell664) cell665) cell666) cell667) cell668) cell669) cell670) cell671

#print axioms block41

end QuarticKernel.KernelCells
