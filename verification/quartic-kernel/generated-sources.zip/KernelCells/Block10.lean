import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell160 : checkCoreCellRange 160 1 = true := by
  decide +kernel

private theorem cell161 : checkCoreCellRange 161 1 = true := by
  decide +kernel

private theorem cell162 : checkCoreCellRange 162 1 = true := by
  decide +kernel

private theorem cell163 : checkCoreCellRange 163 1 = true := by
  decide +kernel

private theorem cell164 : checkCoreCellRange 164 1 = true := by
  decide +kernel

private theorem cell165 : checkCoreCellRange 165 1 = true := by
  decide +kernel

private theorem cell166 : checkCoreCellRange 166 1 = true := by
  decide +kernel

private theorem cell167 : checkCoreCellRange 167 1 = true := by
  decide +kernel

private theorem cell168 : checkCoreCellRange 168 1 = true := by
  decide +kernel

private theorem cell169 : checkCoreCellRange 169 1 = true := by
  decide +kernel

private theorem cell170 : checkCoreCellRange 170 1 = true := by
  decide +kernel

private theorem cell171 : checkCoreCellRange 171 1 = true := by
  decide +kernel

private theorem cell172 : checkCoreCellRange 172 1 = true := by
  decide +kernel

private theorem cell173 : checkCoreCellRange 173 1 = true := by
  decide +kernel

private theorem cell174 : checkCoreCellRange 174 1 = true := by
  decide +kernel

private theorem cell175 : checkCoreCellRange 175 1 = true := by
  decide +kernel

theorem block10 : checkCoreCellRange 160 16 = true :=
  checkCoreCellRange_succ 160 15 (checkCoreCellRange_succ 160 14 (checkCoreCellRange_succ 160 13 (checkCoreCellRange_succ 160 12 (checkCoreCellRange_succ 160 11 (checkCoreCellRange_succ 160 10 (checkCoreCellRange_succ 160 9 (checkCoreCellRange_succ 160 8 (checkCoreCellRange_succ 160 7 (checkCoreCellRange_succ 160 6 (checkCoreCellRange_succ 160 5 (checkCoreCellRange_succ 160 4 (checkCoreCellRange_succ 160 3 (checkCoreCellRange_succ 160 2 (checkCoreCellRange_succ 160 1 (checkCoreCellRange_succ 160 0 rfl cell160) cell161) cell162) cell163) cell164) cell165) cell166) cell167) cell168) cell169) cell170) cell171) cell172) cell173) cell174) cell175

#print axioms block10

end QuarticKernel.KernelCells
