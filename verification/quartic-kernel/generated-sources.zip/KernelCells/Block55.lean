import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell880 : checkCoreCellRange 880 1 = true := by
  decide +kernel

private theorem cell881 : checkCoreCellRange 881 1 = true := by
  decide +kernel

private theorem cell882 : checkCoreCellRange 882 1 = true := by
  decide +kernel

private theorem cell883 : checkCoreCellRange 883 1 = true := by
  decide +kernel

private theorem cell884 : checkCoreCellRange 884 1 = true := by
  decide +kernel

private theorem cell885 : checkCoreCellRange 885 1 = true := by
  decide +kernel

private theorem cell886 : checkCoreCellRange 886 1 = true := by
  decide +kernel

private theorem cell887 : checkCoreCellRange 887 1 = true := by
  decide +kernel

private theorem cell888 : checkCoreCellRange 888 1 = true := by
  decide +kernel

private theorem cell889 : checkCoreCellRange 889 1 = true := by
  decide +kernel

private theorem cell890 : checkCoreCellRange 890 1 = true := by
  decide +kernel

private theorem cell891 : checkCoreCellRange 891 1 = true := by
  decide +kernel

private theorem cell892 : checkCoreCellRange 892 1 = true := by
  decide +kernel

private theorem cell893 : checkCoreCellRange 893 1 = true := by
  decide +kernel

private theorem cell894 : checkCoreCellRange 894 1 = true := by
  decide +kernel

private theorem cell895 : checkCoreCellRange 895 1 = true := by
  decide +kernel

theorem block55 : checkCoreCellRange 880 16 = true :=
  checkCoreCellRange_succ 880 15 (checkCoreCellRange_succ 880 14 (checkCoreCellRange_succ 880 13 (checkCoreCellRange_succ 880 12 (checkCoreCellRange_succ 880 11 (checkCoreCellRange_succ 880 10 (checkCoreCellRange_succ 880 9 (checkCoreCellRange_succ 880 8 (checkCoreCellRange_succ 880 7 (checkCoreCellRange_succ 880 6 (checkCoreCellRange_succ 880 5 (checkCoreCellRange_succ 880 4 (checkCoreCellRange_succ 880 3 (checkCoreCellRange_succ 880 2 (checkCoreCellRange_succ 880 1 (checkCoreCellRange_succ 880 0 rfl cell880) cell881) cell882) cell883) cell884) cell885) cell886) cell887) cell888) cell889) cell890) cell891) cell892) cell893) cell894) cell895

#print axioms block55

end QuarticKernel.KernelCells
