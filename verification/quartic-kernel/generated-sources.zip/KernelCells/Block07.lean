import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell112 : checkCoreCellRange 112 1 = true := by
  decide +kernel

private theorem cell113 : checkCoreCellRange 113 1 = true := by
  decide +kernel

private theorem cell114 : checkCoreCellRange 114 1 = true := by
  decide +kernel

private theorem cell115 : checkCoreCellRange 115 1 = true := by
  decide +kernel

private theorem cell116 : checkCoreCellRange 116 1 = true := by
  decide +kernel

private theorem cell117 : checkCoreCellRange 117 1 = true := by
  decide +kernel

private theorem cell118 : checkCoreCellRange 118 1 = true := by
  decide +kernel

private theorem cell119 : checkCoreCellRange 119 1 = true := by
  decide +kernel

private theorem cell120 : checkCoreCellRange 120 1 = true := by
  decide +kernel

private theorem cell121 : checkCoreCellRange 121 1 = true := by
  decide +kernel

private theorem cell122 : checkCoreCellRange 122 1 = true := by
  decide +kernel

private theorem cell123 : checkCoreCellRange 123 1 = true := by
  decide +kernel

private theorem cell124 : checkCoreCellRange 124 1 = true := by
  decide +kernel

private theorem cell125 : checkCoreCellRange 125 1 = true := by
  decide +kernel

private theorem cell126 : checkCoreCellRange 126 1 = true := by
  decide +kernel

private theorem cell127 : checkCoreCellRange 127 1 = true := by
  decide +kernel

theorem block7 : checkCoreCellRange 112 16 = true :=
  checkCoreCellRange_succ 112 15 (checkCoreCellRange_succ 112 14 (checkCoreCellRange_succ 112 13 (checkCoreCellRange_succ 112 12 (checkCoreCellRange_succ 112 11 (checkCoreCellRange_succ 112 10 (checkCoreCellRange_succ 112 9 (checkCoreCellRange_succ 112 8 (checkCoreCellRange_succ 112 7 (checkCoreCellRange_succ 112 6 (checkCoreCellRange_succ 112 5 (checkCoreCellRange_succ 112 4 (checkCoreCellRange_succ 112 3 (checkCoreCellRange_succ 112 2 (checkCoreCellRange_succ 112 1 (checkCoreCellRange_succ 112 0 rfl cell112) cell113) cell114) cell115) cell116) cell117) cell118) cell119) cell120) cell121) cell122) cell123) cell124) cell125) cell126) cell127

#print axioms block7

end QuarticKernel.KernelCells
