import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell1024 : checkCoreCellRange 1024 1 = true := by
  decide +kernel

private theorem cell1025 : checkCoreCellRange 1025 1 = true := by
  decide +kernel

private theorem cell1026 : checkCoreCellRange 1026 1 = true := by
  decide +kernel

private theorem cell1027 : checkCoreCellRange 1027 1 = true := by
  decide +kernel

private theorem cell1028 : checkCoreCellRange 1028 1 = true := by
  decide +kernel

private theorem cell1029 : checkCoreCellRange 1029 1 = true := by
  decide +kernel

private theorem cell1030 : checkCoreCellRange 1030 1 = true := by
  decide +kernel

private theorem cell1031 : checkCoreCellRange 1031 1 = true := by
  decide +kernel

private theorem cell1032 : checkCoreCellRange 1032 1 = true := by
  decide +kernel

private theorem cell1033 : checkCoreCellRange 1033 1 = true := by
  decide +kernel

private theorem cell1034 : checkCoreCellRange 1034 1 = true := by
  decide +kernel

private theorem cell1035 : checkCoreCellRange 1035 1 = true := by
  decide +kernel

private theorem cell1036 : checkCoreCellRange 1036 1 = true := by
  decide +kernel

private theorem cell1037 : checkCoreCellRange 1037 1 = true := by
  decide +kernel

private theorem cell1038 : checkCoreCellRange 1038 1 = true := by
  decide +kernel

private theorem cell1039 : checkCoreCellRange 1039 1 = true := by
  decide +kernel

theorem block64 : checkCoreCellRange 1024 16 = true :=
  checkCoreCellRange_succ 1024 15 (checkCoreCellRange_succ 1024 14 (checkCoreCellRange_succ 1024 13 (checkCoreCellRange_succ 1024 12 (checkCoreCellRange_succ 1024 11 (checkCoreCellRange_succ 1024 10 (checkCoreCellRange_succ 1024 9 (checkCoreCellRange_succ 1024 8 (checkCoreCellRange_succ 1024 7 (checkCoreCellRange_succ 1024 6 (checkCoreCellRange_succ 1024 5 (checkCoreCellRange_succ 1024 4 (checkCoreCellRange_succ 1024 3 (checkCoreCellRange_succ 1024 2 (checkCoreCellRange_succ 1024 1 (checkCoreCellRange_succ 1024 0 rfl cell1024) cell1025) cell1026) cell1027) cell1028) cell1029) cell1030) cell1031) cell1032) cell1033) cell1034) cell1035) cell1036) cell1037) cell1038) cell1039

#print axioms block64

end QuarticKernel.KernelCells
