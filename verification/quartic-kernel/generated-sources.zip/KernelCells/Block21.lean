import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell336 : checkCoreCellRange 336 1 = true := by
  decide +kernel

private theorem cell337 : checkCoreCellRange 337 1 = true := by
  decide +kernel

private theorem cell338 : checkCoreCellRange 338 1 = true := by
  decide +kernel

private theorem cell339 : checkCoreCellRange 339 1 = true := by
  decide +kernel

private theorem cell340 : checkCoreCellRange 340 1 = true := by
  decide +kernel

private theorem cell341 : checkCoreCellRange 341 1 = true := by
  decide +kernel

private theorem cell342 : checkCoreCellRange 342 1 = true := by
  decide +kernel

private theorem cell343 : checkCoreCellRange 343 1 = true := by
  decide +kernel

private theorem cell344 : checkCoreCellRange 344 1 = true := by
  decide +kernel

private theorem cell345 : checkCoreCellRange 345 1 = true := by
  decide +kernel

private theorem cell346 : checkCoreCellRange 346 1 = true := by
  decide +kernel

private theorem cell347 : checkCoreCellRange 347 1 = true := by
  decide +kernel

private theorem cell348 : checkCoreCellRange 348 1 = true := by
  decide +kernel

private theorem cell349 : checkCoreCellRange 349 1 = true := by
  decide +kernel

private theorem cell350 : checkCoreCellRange 350 1 = true := by
  decide +kernel

private theorem cell351 : checkCoreCellRange 351 1 = true := by
  decide +kernel

theorem block21 : checkCoreCellRange 336 16 = true :=
  checkCoreCellRange_succ 336 15 (checkCoreCellRange_succ 336 14 (checkCoreCellRange_succ 336 13 (checkCoreCellRange_succ 336 12 (checkCoreCellRange_succ 336 11 (checkCoreCellRange_succ 336 10 (checkCoreCellRange_succ 336 9 (checkCoreCellRange_succ 336 8 (checkCoreCellRange_succ 336 7 (checkCoreCellRange_succ 336 6 (checkCoreCellRange_succ 336 5 (checkCoreCellRange_succ 336 4 (checkCoreCellRange_succ 336 3 (checkCoreCellRange_succ 336 2 (checkCoreCellRange_succ 336 1 (checkCoreCellRange_succ 336 0 rfl cell336) cell337) cell338) cell339) cell340) cell341) cell342) cell343) cell344) cell345) cell346) cell347) cell348) cell349) cell350) cell351

#print axioms block21

end QuarticKernel.KernelCells
