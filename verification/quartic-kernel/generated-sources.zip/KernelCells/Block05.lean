import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell80 : checkCoreCellRange 80 1 = true := by
  decide +kernel

private theorem cell81 : checkCoreCellRange 81 1 = true := by
  decide +kernel

private theorem cell82 : checkCoreCellRange 82 1 = true := by
  decide +kernel

private theorem cell83 : checkCoreCellRange 83 1 = true := by
  decide +kernel

private theorem cell84 : checkCoreCellRange 84 1 = true := by
  decide +kernel

private theorem cell85 : checkCoreCellRange 85 1 = true := by
  decide +kernel

private theorem cell86 : checkCoreCellRange 86 1 = true := by
  decide +kernel

private theorem cell87 : checkCoreCellRange 87 1 = true := by
  decide +kernel

private theorem cell88 : checkCoreCellRange 88 1 = true := by
  decide +kernel

private theorem cell89 : checkCoreCellRange 89 1 = true := by
  decide +kernel

private theorem cell90 : checkCoreCellRange 90 1 = true := by
  decide +kernel

private theorem cell91 : checkCoreCellRange 91 1 = true := by
  decide +kernel

private theorem cell92 : checkCoreCellRange 92 1 = true := by
  decide +kernel

private theorem cell93 : checkCoreCellRange 93 1 = true := by
  decide +kernel

private theorem cell94 : checkCoreCellRange 94 1 = true := by
  decide +kernel

private theorem cell95 : checkCoreCellRange 95 1 = true := by
  decide +kernel

theorem block5 : checkCoreCellRange 80 16 = true :=
  checkCoreCellRange_succ 80 15 (checkCoreCellRange_succ 80 14 (checkCoreCellRange_succ 80 13 (checkCoreCellRange_succ 80 12 (checkCoreCellRange_succ 80 11 (checkCoreCellRange_succ 80 10 (checkCoreCellRange_succ 80 9 (checkCoreCellRange_succ 80 8 (checkCoreCellRange_succ 80 7 (checkCoreCellRange_succ 80 6 (checkCoreCellRange_succ 80 5 (checkCoreCellRange_succ 80 4 (checkCoreCellRange_succ 80 3 (checkCoreCellRange_succ 80 2 (checkCoreCellRange_succ 80 1 (checkCoreCellRange_succ 80 0 rfl cell80) cell81) cell82) cell83) cell84) cell85) cell86) cell87) cell88) cell89) cell90) cell91) cell92) cell93) cell94) cell95

#print axioms block5

end QuarticKernel.KernelCells
