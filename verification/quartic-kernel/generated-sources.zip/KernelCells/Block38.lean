import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell608 : checkCoreCellRange 608 1 = true := by
  decide +kernel

private theorem cell609 : checkCoreCellRange 609 1 = true := by
  decide +kernel

private theorem cell610 : checkCoreCellRange 610 1 = true := by
  decide +kernel

private theorem cell611 : checkCoreCellRange 611 1 = true := by
  decide +kernel

private theorem cell612 : checkCoreCellRange 612 1 = true := by
  decide +kernel

private theorem cell613 : checkCoreCellRange 613 1 = true := by
  decide +kernel

private theorem cell614 : checkCoreCellRange 614 1 = true := by
  decide +kernel

private theorem cell615 : checkCoreCellRange 615 1 = true := by
  decide +kernel

private theorem cell616 : checkCoreCellRange 616 1 = true := by
  decide +kernel

private theorem cell617 : checkCoreCellRange 617 1 = true := by
  decide +kernel

private theorem cell618 : checkCoreCellRange 618 1 = true := by
  decide +kernel

private theorem cell619 : checkCoreCellRange 619 1 = true := by
  decide +kernel

private theorem cell620 : checkCoreCellRange 620 1 = true := by
  decide +kernel

private theorem cell621 : checkCoreCellRange 621 1 = true := by
  decide +kernel

private theorem cell622 : checkCoreCellRange 622 1 = true := by
  decide +kernel

private theorem cell623 : checkCoreCellRange 623 1 = true := by
  decide +kernel

theorem block38 : checkCoreCellRange 608 16 = true :=
  checkCoreCellRange_succ 608 15 (checkCoreCellRange_succ 608 14 (checkCoreCellRange_succ 608 13 (checkCoreCellRange_succ 608 12 (checkCoreCellRange_succ 608 11 (checkCoreCellRange_succ 608 10 (checkCoreCellRange_succ 608 9 (checkCoreCellRange_succ 608 8 (checkCoreCellRange_succ 608 7 (checkCoreCellRange_succ 608 6 (checkCoreCellRange_succ 608 5 (checkCoreCellRange_succ 608 4 (checkCoreCellRange_succ 608 3 (checkCoreCellRange_succ 608 2 (checkCoreCellRange_succ 608 1 (checkCoreCellRange_succ 608 0 rfl cell608) cell609) cell610) cell611) cell612) cell613) cell614) cell615) cell616) cell617) cell618) cell619) cell620) cell621) cell622) cell623

#print axioms block38

end QuarticKernel.KernelCells
