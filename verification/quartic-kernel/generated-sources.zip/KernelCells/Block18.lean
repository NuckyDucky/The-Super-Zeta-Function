import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell288 : checkCoreCellRange 288 1 = true := by
  decide +kernel

private theorem cell289 : checkCoreCellRange 289 1 = true := by
  decide +kernel

private theorem cell290 : checkCoreCellRange 290 1 = true := by
  decide +kernel

private theorem cell291 : checkCoreCellRange 291 1 = true := by
  decide +kernel

private theorem cell292 : checkCoreCellRange 292 1 = true := by
  decide +kernel

private theorem cell293 : checkCoreCellRange 293 1 = true := by
  decide +kernel

private theorem cell294 : checkCoreCellRange 294 1 = true := by
  decide +kernel

private theorem cell295 : checkCoreCellRange 295 1 = true := by
  decide +kernel

private theorem cell296 : checkCoreCellRange 296 1 = true := by
  decide +kernel

private theorem cell297 : checkCoreCellRange 297 1 = true := by
  decide +kernel

private theorem cell298 : checkCoreCellRange 298 1 = true := by
  decide +kernel

private theorem cell299 : checkCoreCellRange 299 1 = true := by
  decide +kernel

private theorem cell300 : checkCoreCellRange 300 1 = true := by
  decide +kernel

private theorem cell301 : checkCoreCellRange 301 1 = true := by
  decide +kernel

private theorem cell302 : checkCoreCellRange 302 1 = true := by
  decide +kernel

private theorem cell303 : checkCoreCellRange 303 1 = true := by
  decide +kernel

theorem block18 : checkCoreCellRange 288 16 = true :=
  checkCoreCellRange_succ 288 15 (checkCoreCellRange_succ 288 14 (checkCoreCellRange_succ 288 13 (checkCoreCellRange_succ 288 12 (checkCoreCellRange_succ 288 11 (checkCoreCellRange_succ 288 10 (checkCoreCellRange_succ 288 9 (checkCoreCellRange_succ 288 8 (checkCoreCellRange_succ 288 7 (checkCoreCellRange_succ 288 6 (checkCoreCellRange_succ 288 5 (checkCoreCellRange_succ 288 4 (checkCoreCellRange_succ 288 3 (checkCoreCellRange_succ 288 2 (checkCoreCellRange_succ 288 1 (checkCoreCellRange_succ 288 0 rfl cell288) cell289) cell290) cell291) cell292) cell293) cell294) cell295) cell296) cell297) cell298) cell299) cell300) cell301) cell302) cell303

#print axioms block18

end QuarticKernel.KernelCells
