import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell832 : checkCoreCellRange 832 1 = true := by
  decide +kernel

private theorem cell833 : checkCoreCellRange 833 1 = true := by
  decide +kernel

private theorem cell834 : checkCoreCellRange 834 1 = true := by
  decide +kernel

private theorem cell835 : checkCoreCellRange 835 1 = true := by
  decide +kernel

private theorem cell836 : checkCoreCellRange 836 1 = true := by
  decide +kernel

private theorem cell837 : checkCoreCellRange 837 1 = true := by
  decide +kernel

private theorem cell838 : checkCoreCellRange 838 1 = true := by
  decide +kernel

private theorem cell839 : checkCoreCellRange 839 1 = true := by
  decide +kernel

private theorem cell840 : checkCoreCellRange 840 1 = true := by
  decide +kernel

private theorem cell841 : checkCoreCellRange 841 1 = true := by
  decide +kernel

private theorem cell842 : checkCoreCellRange 842 1 = true := by
  decide +kernel

private theorem cell843 : checkCoreCellRange 843 1 = true := by
  decide +kernel

private theorem cell844 : checkCoreCellRange 844 1 = true := by
  decide +kernel

private theorem cell845 : checkCoreCellRange 845 1 = true := by
  decide +kernel

private theorem cell846 : checkCoreCellRange 846 1 = true := by
  decide +kernel

private theorem cell847 : checkCoreCellRange 847 1 = true := by
  decide +kernel

theorem block52 : checkCoreCellRange 832 16 = true :=
  checkCoreCellRange_succ 832 15 (checkCoreCellRange_succ 832 14 (checkCoreCellRange_succ 832 13 (checkCoreCellRange_succ 832 12 (checkCoreCellRange_succ 832 11 (checkCoreCellRange_succ 832 10 (checkCoreCellRange_succ 832 9 (checkCoreCellRange_succ 832 8 (checkCoreCellRange_succ 832 7 (checkCoreCellRange_succ 832 6 (checkCoreCellRange_succ 832 5 (checkCoreCellRange_succ 832 4 (checkCoreCellRange_succ 832 3 (checkCoreCellRange_succ 832 2 (checkCoreCellRange_succ 832 1 (checkCoreCellRange_succ 832 0 rfl cell832) cell833) cell834) cell835) cell836) cell837) cell838) cell839) cell840) cell841) cell842) cell843) cell844) cell845) cell846) cell847

#print axioms block52

end QuarticKernel.KernelCells
