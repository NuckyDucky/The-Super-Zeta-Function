import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell672 : checkCoreCellRange 672 1 = true := by
  decide +kernel

private theorem cell673 : checkCoreCellRange 673 1 = true := by
  decide +kernel

private theorem cell674 : checkCoreCellRange 674 1 = true := by
  decide +kernel

private theorem cell675 : checkCoreCellRange 675 1 = true := by
  decide +kernel

private theorem cell676 : checkCoreCellRange 676 1 = true := by
  decide +kernel

private theorem cell677 : checkCoreCellRange 677 1 = true := by
  decide +kernel

private theorem cell678 : checkCoreCellRange 678 1 = true := by
  decide +kernel

private theorem cell679 : checkCoreCellRange 679 1 = true := by
  decide +kernel

private theorem cell680 : checkCoreCellRange 680 1 = true := by
  decide +kernel

private theorem cell681 : checkCoreCellRange 681 1 = true := by
  decide +kernel

private theorem cell682 : checkCoreCellRange 682 1 = true := by
  decide +kernel

private theorem cell683 : checkCoreCellRange 683 1 = true := by
  decide +kernel

private theorem cell684 : checkCoreCellRange 684 1 = true := by
  decide +kernel

private theorem cell685 : checkCoreCellRange 685 1 = true := by
  decide +kernel

private theorem cell686 : checkCoreCellRange 686 1 = true := by
  decide +kernel

private theorem cell687 : checkCoreCellRange 687 1 = true := by
  decide +kernel

theorem block42 : checkCoreCellRange 672 16 = true :=
  checkCoreCellRange_succ 672 15 (checkCoreCellRange_succ 672 14 (checkCoreCellRange_succ 672 13 (checkCoreCellRange_succ 672 12 (checkCoreCellRange_succ 672 11 (checkCoreCellRange_succ 672 10 (checkCoreCellRange_succ 672 9 (checkCoreCellRange_succ 672 8 (checkCoreCellRange_succ 672 7 (checkCoreCellRange_succ 672 6 (checkCoreCellRange_succ 672 5 (checkCoreCellRange_succ 672 4 (checkCoreCellRange_succ 672 3 (checkCoreCellRange_succ 672 2 (checkCoreCellRange_succ 672 1 (checkCoreCellRange_succ 672 0 rfl cell672) cell673) cell674) cell675) cell676) cell677) cell678) cell679) cell680) cell681) cell682) cell683) cell684) cell685) cell686) cell687

#print axioms block42

end QuarticKernel.KernelCells
