import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell928 : checkCoreCellRange 928 1 = true := by
  decide +kernel

private theorem cell929 : checkCoreCellRange 929 1 = true := by
  decide +kernel

private theorem cell930 : checkCoreCellRange 930 1 = true := by
  decide +kernel

private theorem cell931 : checkCoreCellRange 931 1 = true := by
  decide +kernel

private theorem cell932 : checkCoreCellRange 932 1 = true := by
  decide +kernel

private theorem cell933 : checkCoreCellRange 933 1 = true := by
  decide +kernel

private theorem cell934 : checkCoreCellRange 934 1 = true := by
  decide +kernel

private theorem cell935 : checkCoreCellRange 935 1 = true := by
  decide +kernel

private theorem cell936 : checkCoreCellRange 936 1 = true := by
  decide +kernel

private theorem cell937 : checkCoreCellRange 937 1 = true := by
  decide +kernel

private theorem cell938 : checkCoreCellRange 938 1 = true := by
  decide +kernel

private theorem cell939 : checkCoreCellRange 939 1 = true := by
  decide +kernel

private theorem cell940 : checkCoreCellRange 940 1 = true := by
  decide +kernel

private theorem cell941 : checkCoreCellRange 941 1 = true := by
  decide +kernel

private theorem cell942 : checkCoreCellRange 942 1 = true := by
  decide +kernel

private theorem cell943 : checkCoreCellRange 943 1 = true := by
  decide +kernel

theorem block58 : checkCoreCellRange 928 16 = true :=
  checkCoreCellRange_succ 928 15 (checkCoreCellRange_succ 928 14 (checkCoreCellRange_succ 928 13 (checkCoreCellRange_succ 928 12 (checkCoreCellRange_succ 928 11 (checkCoreCellRange_succ 928 10 (checkCoreCellRange_succ 928 9 (checkCoreCellRange_succ 928 8 (checkCoreCellRange_succ 928 7 (checkCoreCellRange_succ 928 6 (checkCoreCellRange_succ 928 5 (checkCoreCellRange_succ 928 4 (checkCoreCellRange_succ 928 3 (checkCoreCellRange_succ 928 2 (checkCoreCellRange_succ 928 1 (checkCoreCellRange_succ 928 0 rfl cell928) cell929) cell930) cell931) cell932) cell933) cell934) cell935) cell936) cell937) cell938) cell939) cell940) cell941) cell942) cell943

#print axioms block58

end QuarticKernel.KernelCells
