import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell32 : checkCoreCellRange 32 1 = true := by
  decide +kernel

private theorem cell33 : checkCoreCellRange 33 1 = true := by
  decide +kernel

private theorem cell34 : checkCoreCellRange 34 1 = true := by
  decide +kernel

private theorem cell35 : checkCoreCellRange 35 1 = true := by
  decide +kernel

private theorem cell36 : checkCoreCellRange 36 1 = true := by
  decide +kernel

private theorem cell37 : checkCoreCellRange 37 1 = true := by
  decide +kernel

private theorem cell38 : checkCoreCellRange 38 1 = true := by
  decide +kernel

private theorem cell39 : checkCoreCellRange 39 1 = true := by
  decide +kernel

private theorem cell40 : checkCoreCellRange 40 1 = true := by
  decide +kernel

private theorem cell41 : checkCoreCellRange 41 1 = true := by
  decide +kernel

private theorem cell42 : checkCoreCellRange 42 1 = true := by
  decide +kernel

private theorem cell43 : checkCoreCellRange 43 1 = true := by
  decide +kernel

private theorem cell44 : checkCoreCellRange 44 1 = true := by
  decide +kernel

private theorem cell45 : checkCoreCellRange 45 1 = true := by
  decide +kernel

private theorem cell46 : checkCoreCellRange 46 1 = true := by
  decide +kernel

private theorem cell47 : checkCoreCellRange 47 1 = true := by
  decide +kernel

theorem block2 : checkCoreCellRange 32 16 = true :=
  checkCoreCellRange_succ 32 15 (checkCoreCellRange_succ 32 14 (checkCoreCellRange_succ 32 13 (checkCoreCellRange_succ 32 12 (checkCoreCellRange_succ 32 11 (checkCoreCellRange_succ 32 10 (checkCoreCellRange_succ 32 9 (checkCoreCellRange_succ 32 8 (checkCoreCellRange_succ 32 7 (checkCoreCellRange_succ 32 6 (checkCoreCellRange_succ 32 5 (checkCoreCellRange_succ 32 4 (checkCoreCellRange_succ 32 3 (checkCoreCellRange_succ 32 2 (checkCoreCellRange_succ 32 1 (checkCoreCellRange_succ 32 0 rfl cell32) cell33) cell34) cell35) cell36) cell37) cell38) cell39) cell40) cell41) cell42) cell43) cell44) cell45) cell46) cell47

#print axioms block2

end QuarticKernel.KernelCells
