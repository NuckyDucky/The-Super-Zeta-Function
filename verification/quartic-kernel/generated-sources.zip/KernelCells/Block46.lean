import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell736 : checkCoreCellRange 736 1 = true := by
  decide +kernel

private theorem cell737 : checkCoreCellRange 737 1 = true := by
  decide +kernel

private theorem cell738 : checkCoreCellRange 738 1 = true := by
  decide +kernel

private theorem cell739 : checkCoreCellRange 739 1 = true := by
  decide +kernel

private theorem cell740 : checkCoreCellRange 740 1 = true := by
  decide +kernel

private theorem cell741 : checkCoreCellRange 741 1 = true := by
  decide +kernel

private theorem cell742 : checkCoreCellRange 742 1 = true := by
  decide +kernel

private theorem cell743 : checkCoreCellRange 743 1 = true := by
  decide +kernel

private theorem cell744 : checkCoreCellRange 744 1 = true := by
  decide +kernel

private theorem cell745 : checkCoreCellRange 745 1 = true := by
  decide +kernel

private theorem cell746 : checkCoreCellRange 746 1 = true := by
  decide +kernel

private theorem cell747 : checkCoreCellRange 747 1 = true := by
  decide +kernel

private theorem cell748 : checkCoreCellRange 748 1 = true := by
  decide +kernel

private theorem cell749 : checkCoreCellRange 749 1 = true := by
  decide +kernel

private theorem cell750 : checkCoreCellRange 750 1 = true := by
  decide +kernel

private theorem cell751 : checkCoreCellRange 751 1 = true := by
  decide +kernel

theorem block46 : checkCoreCellRange 736 16 = true :=
  checkCoreCellRange_succ 736 15 (checkCoreCellRange_succ 736 14 (checkCoreCellRange_succ 736 13 (checkCoreCellRange_succ 736 12 (checkCoreCellRange_succ 736 11 (checkCoreCellRange_succ 736 10 (checkCoreCellRange_succ 736 9 (checkCoreCellRange_succ 736 8 (checkCoreCellRange_succ 736 7 (checkCoreCellRange_succ 736 6 (checkCoreCellRange_succ 736 5 (checkCoreCellRange_succ 736 4 (checkCoreCellRange_succ 736 3 (checkCoreCellRange_succ 736 2 (checkCoreCellRange_succ 736 1 (checkCoreCellRange_succ 736 0 rfl cell736) cell737) cell738) cell739) cell740) cell741) cell742) cell743) cell744) cell745) cell746) cell747) cell748) cell749) cell750) cell751

#print axioms block46

end QuarticKernel.KernelCells
