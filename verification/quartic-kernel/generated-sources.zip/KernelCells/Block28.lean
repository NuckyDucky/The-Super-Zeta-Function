import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell448 : checkCoreCellRange 448 1 = true := by
  decide +kernel

private theorem cell449 : checkCoreCellRange 449 1 = true := by
  decide +kernel

private theorem cell450 : checkCoreCellRange 450 1 = true := by
  decide +kernel

private theorem cell451 : checkCoreCellRange 451 1 = true := by
  decide +kernel

private theorem cell452 : checkCoreCellRange 452 1 = true := by
  decide +kernel

private theorem cell453 : checkCoreCellRange 453 1 = true := by
  decide +kernel

private theorem cell454 : checkCoreCellRange 454 1 = true := by
  decide +kernel

private theorem cell455 : checkCoreCellRange 455 1 = true := by
  decide +kernel

private theorem cell456 : checkCoreCellRange 456 1 = true := by
  decide +kernel

private theorem cell457 : checkCoreCellRange 457 1 = true := by
  decide +kernel

private theorem cell458 : checkCoreCellRange 458 1 = true := by
  decide +kernel

private theorem cell459 : checkCoreCellRange 459 1 = true := by
  decide +kernel

private theorem cell460 : checkCoreCellRange 460 1 = true := by
  decide +kernel

private theorem cell461 : checkCoreCellRange 461 1 = true := by
  decide +kernel

private theorem cell462 : checkCoreCellRange 462 1 = true := by
  decide +kernel

private theorem cell463 : checkCoreCellRange 463 1 = true := by
  decide +kernel

theorem block28 : checkCoreCellRange 448 16 = true :=
  checkCoreCellRange_succ 448 15 (checkCoreCellRange_succ 448 14 (checkCoreCellRange_succ 448 13 (checkCoreCellRange_succ 448 12 (checkCoreCellRange_succ 448 11 (checkCoreCellRange_succ 448 10 (checkCoreCellRange_succ 448 9 (checkCoreCellRange_succ 448 8 (checkCoreCellRange_succ 448 7 (checkCoreCellRange_succ 448 6 (checkCoreCellRange_succ 448 5 (checkCoreCellRange_succ 448 4 (checkCoreCellRange_succ 448 3 (checkCoreCellRange_succ 448 2 (checkCoreCellRange_succ 448 1 (checkCoreCellRange_succ 448 0 rfl cell448) cell449) cell450) cell451) cell452) cell453) cell454) cell455) cell456) cell457) cell458) cell459) cell460) cell461) cell462) cell463

#print axioms block28

end QuarticKernel.KernelCells
