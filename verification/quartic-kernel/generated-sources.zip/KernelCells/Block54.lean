import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell864 : checkCoreCellRange 864 1 = true := by
  decide +kernel

private theorem cell865 : checkCoreCellRange 865 1 = true := by
  decide +kernel

private theorem cell866 : checkCoreCellRange 866 1 = true := by
  decide +kernel

private theorem cell867 : checkCoreCellRange 867 1 = true := by
  decide +kernel

private theorem cell868 : checkCoreCellRange 868 1 = true := by
  decide +kernel

private theorem cell869 : checkCoreCellRange 869 1 = true := by
  decide +kernel

private theorem cell870 : checkCoreCellRange 870 1 = true := by
  decide +kernel

private theorem cell871 : checkCoreCellRange 871 1 = true := by
  decide +kernel

private theorem cell872 : checkCoreCellRange 872 1 = true := by
  decide +kernel

private theorem cell873 : checkCoreCellRange 873 1 = true := by
  decide +kernel

private theorem cell874 : checkCoreCellRange 874 1 = true := by
  decide +kernel

private theorem cell875 : checkCoreCellRange 875 1 = true := by
  decide +kernel

private theorem cell876 : checkCoreCellRange 876 1 = true := by
  decide +kernel

private theorem cell877 : checkCoreCellRange 877 1 = true := by
  decide +kernel

private theorem cell878 : checkCoreCellRange 878 1 = true := by
  decide +kernel

private theorem cell879 : checkCoreCellRange 879 1 = true := by
  decide +kernel

theorem block54 : checkCoreCellRange 864 16 = true :=
  checkCoreCellRange_succ 864 15 (checkCoreCellRange_succ 864 14 (checkCoreCellRange_succ 864 13 (checkCoreCellRange_succ 864 12 (checkCoreCellRange_succ 864 11 (checkCoreCellRange_succ 864 10 (checkCoreCellRange_succ 864 9 (checkCoreCellRange_succ 864 8 (checkCoreCellRange_succ 864 7 (checkCoreCellRange_succ 864 6 (checkCoreCellRange_succ 864 5 (checkCoreCellRange_succ 864 4 (checkCoreCellRange_succ 864 3 (checkCoreCellRange_succ 864 2 (checkCoreCellRange_succ 864 1 (checkCoreCellRange_succ 864 0 rfl cell864) cell865) cell866) cell867) cell868) cell869) cell870) cell871) cell872) cell873) cell874) cell875) cell876) cell877) cell878) cell879

#print axioms block54

end QuarticKernel.KernelCells
