import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell16 : checkCoreCellRange 16 1 = true := by
  decide +kernel

private theorem cell17 : checkCoreCellRange 17 1 = true := by
  decide +kernel

private theorem cell18 : checkCoreCellRange 18 1 = true := by
  decide +kernel

private theorem cell19 : checkCoreCellRange 19 1 = true := by
  decide +kernel

private theorem cell20 : checkCoreCellRange 20 1 = true := by
  decide +kernel

private theorem cell21 : checkCoreCellRange 21 1 = true := by
  decide +kernel

private theorem cell22 : checkCoreCellRange 22 1 = true := by
  decide +kernel

private theorem cell23 : checkCoreCellRange 23 1 = true := by
  decide +kernel

private theorem cell24 : checkCoreCellRange 24 1 = true := by
  decide +kernel

private theorem cell25 : checkCoreCellRange 25 1 = true := by
  decide +kernel

private theorem cell26 : checkCoreCellRange 26 1 = true := by
  decide +kernel

private theorem cell27 : checkCoreCellRange 27 1 = true := by
  decide +kernel

private theorem cell28 : checkCoreCellRange 28 1 = true := by
  decide +kernel

private theorem cell29 : checkCoreCellRange 29 1 = true := by
  decide +kernel

private theorem cell30 : checkCoreCellRange 30 1 = true := by
  decide +kernel

private theorem cell31 : checkCoreCellRange 31 1 = true := by
  decide +kernel

theorem block1 : checkCoreCellRange 16 16 = true :=
  checkCoreCellRange_succ 16 15 (checkCoreCellRange_succ 16 14 (checkCoreCellRange_succ 16 13 (checkCoreCellRange_succ 16 12 (checkCoreCellRange_succ 16 11 (checkCoreCellRange_succ 16 10 (checkCoreCellRange_succ 16 9 (checkCoreCellRange_succ 16 8 (checkCoreCellRange_succ 16 7 (checkCoreCellRange_succ 16 6 (checkCoreCellRange_succ 16 5 (checkCoreCellRange_succ 16 4 (checkCoreCellRange_succ 16 3 (checkCoreCellRange_succ 16 2 (checkCoreCellRange_succ 16 1 (checkCoreCellRange_succ 16 0 rfl cell16) cell17) cell18) cell19) cell20) cell21) cell22) cell23) cell24) cell25) cell26) cell27) cell28) cell29) cell30) cell31

#print axioms block1

end QuarticKernel.KernelCells
