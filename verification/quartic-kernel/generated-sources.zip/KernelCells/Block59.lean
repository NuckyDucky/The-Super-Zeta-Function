import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell944 : checkCoreCellRange 944 1 = true := by
  decide +kernel

private theorem cell945 : checkCoreCellRange 945 1 = true := by
  decide +kernel

private theorem cell946 : checkCoreCellRange 946 1 = true := by
  decide +kernel

private theorem cell947 : checkCoreCellRange 947 1 = true := by
  decide +kernel

private theorem cell948 : checkCoreCellRange 948 1 = true := by
  decide +kernel

private theorem cell949 : checkCoreCellRange 949 1 = true := by
  decide +kernel

private theorem cell950 : checkCoreCellRange 950 1 = true := by
  decide +kernel

private theorem cell951 : checkCoreCellRange 951 1 = true := by
  decide +kernel

private theorem cell952 : checkCoreCellRange 952 1 = true := by
  decide +kernel

private theorem cell953 : checkCoreCellRange 953 1 = true := by
  decide +kernel

private theorem cell954 : checkCoreCellRange 954 1 = true := by
  decide +kernel

private theorem cell955 : checkCoreCellRange 955 1 = true := by
  decide +kernel

private theorem cell956 : checkCoreCellRange 956 1 = true := by
  decide +kernel

private theorem cell957 : checkCoreCellRange 957 1 = true := by
  decide +kernel

private theorem cell958 : checkCoreCellRange 958 1 = true := by
  decide +kernel

private theorem cell959 : checkCoreCellRange 959 1 = true := by
  decide +kernel

theorem block59 : checkCoreCellRange 944 16 = true :=
  checkCoreCellRange_succ 944 15 (checkCoreCellRange_succ 944 14 (checkCoreCellRange_succ 944 13 (checkCoreCellRange_succ 944 12 (checkCoreCellRange_succ 944 11 (checkCoreCellRange_succ 944 10 (checkCoreCellRange_succ 944 9 (checkCoreCellRange_succ 944 8 (checkCoreCellRange_succ 944 7 (checkCoreCellRange_succ 944 6 (checkCoreCellRange_succ 944 5 (checkCoreCellRange_succ 944 4 (checkCoreCellRange_succ 944 3 (checkCoreCellRange_succ 944 2 (checkCoreCellRange_succ 944 1 (checkCoreCellRange_succ 944 0 rfl cell944) cell945) cell946) cell947) cell948) cell949) cell950) cell951) cell952) cell953) cell954) cell955) cell956) cell957) cell958) cell959

#print axioms block59

end QuarticKernel.KernelCells
