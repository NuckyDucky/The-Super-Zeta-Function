import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell384 : checkCoreCellRange 384 1 = true := by
  decide +kernel

private theorem cell385 : checkCoreCellRange 385 1 = true := by
  decide +kernel

private theorem cell386 : checkCoreCellRange 386 1 = true := by
  decide +kernel

private theorem cell387 : checkCoreCellRange 387 1 = true := by
  decide +kernel

private theorem cell388 : checkCoreCellRange 388 1 = true := by
  decide +kernel

private theorem cell389 : checkCoreCellRange 389 1 = true := by
  decide +kernel

private theorem cell390 : checkCoreCellRange 390 1 = true := by
  decide +kernel

private theorem cell391 : checkCoreCellRange 391 1 = true := by
  decide +kernel

private theorem cell392 : checkCoreCellRange 392 1 = true := by
  decide +kernel

private theorem cell393 : checkCoreCellRange 393 1 = true := by
  decide +kernel

private theorem cell394 : checkCoreCellRange 394 1 = true := by
  decide +kernel

private theorem cell395 : checkCoreCellRange 395 1 = true := by
  decide +kernel

private theorem cell396 : checkCoreCellRange 396 1 = true := by
  decide +kernel

private theorem cell397 : checkCoreCellRange 397 1 = true := by
  decide +kernel

private theorem cell398 : checkCoreCellRange 398 1 = true := by
  decide +kernel

private theorem cell399 : checkCoreCellRange 399 1 = true := by
  decide +kernel

theorem block24 : checkCoreCellRange 384 16 = true :=
  checkCoreCellRange_succ 384 15 (checkCoreCellRange_succ 384 14 (checkCoreCellRange_succ 384 13 (checkCoreCellRange_succ 384 12 (checkCoreCellRange_succ 384 11 (checkCoreCellRange_succ 384 10 (checkCoreCellRange_succ 384 9 (checkCoreCellRange_succ 384 8 (checkCoreCellRange_succ 384 7 (checkCoreCellRange_succ 384 6 (checkCoreCellRange_succ 384 5 (checkCoreCellRange_succ 384 4 (checkCoreCellRange_succ 384 3 (checkCoreCellRange_succ 384 2 (checkCoreCellRange_succ 384 1 (checkCoreCellRange_succ 384 0 rfl cell384) cell385) cell386) cell387) cell388) cell389) cell390) cell391) cell392) cell393) cell394) cell395) cell396) cell397) cell398) cell399

#print axioms block24

end QuarticKernel.KernelCells
