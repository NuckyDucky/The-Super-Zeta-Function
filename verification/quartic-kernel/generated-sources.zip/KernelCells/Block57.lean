import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell912 : checkCoreCellRange 912 1 = true := by
  decide +kernel

private theorem cell913 : checkCoreCellRange 913 1 = true := by
  decide +kernel

private theorem cell914 : checkCoreCellRange 914 1 = true := by
  decide +kernel

private theorem cell915 : checkCoreCellRange 915 1 = true := by
  decide +kernel

private theorem cell916 : checkCoreCellRange 916 1 = true := by
  decide +kernel

private theorem cell917 : checkCoreCellRange 917 1 = true := by
  decide +kernel

private theorem cell918 : checkCoreCellRange 918 1 = true := by
  decide +kernel

private theorem cell919 : checkCoreCellRange 919 1 = true := by
  decide +kernel

private theorem cell920 : checkCoreCellRange 920 1 = true := by
  decide +kernel

private theorem cell921 : checkCoreCellRange 921 1 = true := by
  decide +kernel

private theorem cell922 : checkCoreCellRange 922 1 = true := by
  decide +kernel

private theorem cell923 : checkCoreCellRange 923 1 = true := by
  decide +kernel

private theorem cell924 : checkCoreCellRange 924 1 = true := by
  decide +kernel

private theorem cell925 : checkCoreCellRange 925 1 = true := by
  decide +kernel

private theorem cell926 : checkCoreCellRange 926 1 = true := by
  decide +kernel

private theorem cell927 : checkCoreCellRange 927 1 = true := by
  decide +kernel

theorem block57 : checkCoreCellRange 912 16 = true :=
  checkCoreCellRange_succ 912 15 (checkCoreCellRange_succ 912 14 (checkCoreCellRange_succ 912 13 (checkCoreCellRange_succ 912 12 (checkCoreCellRange_succ 912 11 (checkCoreCellRange_succ 912 10 (checkCoreCellRange_succ 912 9 (checkCoreCellRange_succ 912 8 (checkCoreCellRange_succ 912 7 (checkCoreCellRange_succ 912 6 (checkCoreCellRange_succ 912 5 (checkCoreCellRange_succ 912 4 (checkCoreCellRange_succ 912 3 (checkCoreCellRange_succ 912 2 (checkCoreCellRange_succ 912 1 (checkCoreCellRange_succ 912 0 rfl cell912) cell913) cell914) cell915) cell916) cell917) cell918) cell919) cell920) cell921) cell922) cell923) cell924) cell925) cell926) cell927

#print axioms block57

end QuarticKernel.KernelCells
