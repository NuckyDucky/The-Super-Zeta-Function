import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell240 : checkCoreCellRange 240 1 = true := by
  decide +kernel

private theorem cell241 : checkCoreCellRange 241 1 = true := by
  decide +kernel

private theorem cell242 : checkCoreCellRange 242 1 = true := by
  decide +kernel

private theorem cell243 : checkCoreCellRange 243 1 = true := by
  decide +kernel

private theorem cell244 : checkCoreCellRange 244 1 = true := by
  decide +kernel

private theorem cell245 : checkCoreCellRange 245 1 = true := by
  decide +kernel

private theorem cell246 : checkCoreCellRange 246 1 = true := by
  decide +kernel

private theorem cell247 : checkCoreCellRange 247 1 = true := by
  decide +kernel

private theorem cell248 : checkCoreCellRange 248 1 = true := by
  decide +kernel

private theorem cell249 : checkCoreCellRange 249 1 = true := by
  decide +kernel

private theorem cell250 : checkCoreCellRange 250 1 = true := by
  decide +kernel

private theorem cell251 : checkCoreCellRange 251 1 = true := by
  decide +kernel

private theorem cell252 : checkCoreCellRange 252 1 = true := by
  decide +kernel

private theorem cell253 : checkCoreCellRange 253 1 = true := by
  decide +kernel

private theorem cell254 : checkCoreCellRange 254 1 = true := by
  decide +kernel

private theorem cell255 : checkCoreCellRange 255 1 = true := by
  decide +kernel

theorem block15 : checkCoreCellRange 240 16 = true :=
  checkCoreCellRange_succ 240 15 (checkCoreCellRange_succ 240 14 (checkCoreCellRange_succ 240 13 (checkCoreCellRange_succ 240 12 (checkCoreCellRange_succ 240 11 (checkCoreCellRange_succ 240 10 (checkCoreCellRange_succ 240 9 (checkCoreCellRange_succ 240 8 (checkCoreCellRange_succ 240 7 (checkCoreCellRange_succ 240 6 (checkCoreCellRange_succ 240 5 (checkCoreCellRange_succ 240 4 (checkCoreCellRange_succ 240 3 (checkCoreCellRange_succ 240 2 (checkCoreCellRange_succ 240 1 (checkCoreCellRange_succ 240 0 rfl cell240) cell241) cell242) cell243) cell244) cell245) cell246) cell247) cell248) cell249) cell250) cell251) cell252) cell253) cell254) cell255

#print axioms block15

end QuarticKernel.KernelCells
