import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell96 : checkCoreCellRange 96 1 = true := by
  decide +kernel

private theorem cell97 : checkCoreCellRange 97 1 = true := by
  decide +kernel

private theorem cell98 : checkCoreCellRange 98 1 = true := by
  decide +kernel

private theorem cell99 : checkCoreCellRange 99 1 = true := by
  decide +kernel

private theorem cell100 : checkCoreCellRange 100 1 = true := by
  decide +kernel

private theorem cell101 : checkCoreCellRange 101 1 = true := by
  decide +kernel

private theorem cell102 : checkCoreCellRange 102 1 = true := by
  decide +kernel

private theorem cell103 : checkCoreCellRange 103 1 = true := by
  decide +kernel

private theorem cell104 : checkCoreCellRange 104 1 = true := by
  decide +kernel

private theorem cell105 : checkCoreCellRange 105 1 = true := by
  decide +kernel

private theorem cell106 : checkCoreCellRange 106 1 = true := by
  decide +kernel

private theorem cell107 : checkCoreCellRange 107 1 = true := by
  decide +kernel

private theorem cell108 : checkCoreCellRange 108 1 = true := by
  decide +kernel

private theorem cell109 : checkCoreCellRange 109 1 = true := by
  decide +kernel

private theorem cell110 : checkCoreCellRange 110 1 = true := by
  decide +kernel

private theorem cell111 : checkCoreCellRange 111 1 = true := by
  decide +kernel

theorem block6 : checkCoreCellRange 96 16 = true :=
  checkCoreCellRange_succ 96 15 (checkCoreCellRange_succ 96 14 (checkCoreCellRange_succ 96 13 (checkCoreCellRange_succ 96 12 (checkCoreCellRange_succ 96 11 (checkCoreCellRange_succ 96 10 (checkCoreCellRange_succ 96 9 (checkCoreCellRange_succ 96 8 (checkCoreCellRange_succ 96 7 (checkCoreCellRange_succ 96 6 (checkCoreCellRange_succ 96 5 (checkCoreCellRange_succ 96 4 (checkCoreCellRange_succ 96 3 (checkCoreCellRange_succ 96 2 (checkCoreCellRange_succ 96 1 (checkCoreCellRange_succ 96 0 rfl cell96) cell97) cell98) cell99) cell100) cell101) cell102) cell103) cell104) cell105) cell106) cell107) cell108) cell109) cell110) cell111

#print axioms block6

end QuarticKernel.KernelCells
