import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell352 : checkCoreCellRange 352 1 = true := by
  decide +kernel

private theorem cell353 : checkCoreCellRange 353 1 = true := by
  decide +kernel

private theorem cell354 : checkCoreCellRange 354 1 = true := by
  decide +kernel

private theorem cell355 : checkCoreCellRange 355 1 = true := by
  decide +kernel

private theorem cell356 : checkCoreCellRange 356 1 = true := by
  decide +kernel

private theorem cell357 : checkCoreCellRange 357 1 = true := by
  decide +kernel

private theorem cell358 : checkCoreCellRange 358 1 = true := by
  decide +kernel

private theorem cell359 : checkCoreCellRange 359 1 = true := by
  decide +kernel

private theorem cell360 : checkCoreCellRange 360 1 = true := by
  decide +kernel

private theorem cell361 : checkCoreCellRange 361 1 = true := by
  decide +kernel

private theorem cell362 : checkCoreCellRange 362 1 = true := by
  decide +kernel

private theorem cell363 : checkCoreCellRange 363 1 = true := by
  decide +kernel

private theorem cell364 : checkCoreCellRange 364 1 = true := by
  decide +kernel

private theorem cell365 : checkCoreCellRange 365 1 = true := by
  decide +kernel

private theorem cell366 : checkCoreCellRange 366 1 = true := by
  decide +kernel

private theorem cell367 : checkCoreCellRange 367 1 = true := by
  decide +kernel

theorem block22 : checkCoreCellRange 352 16 = true :=
  checkCoreCellRange_succ 352 15 (checkCoreCellRange_succ 352 14 (checkCoreCellRange_succ 352 13 (checkCoreCellRange_succ 352 12 (checkCoreCellRange_succ 352 11 (checkCoreCellRange_succ 352 10 (checkCoreCellRange_succ 352 9 (checkCoreCellRange_succ 352 8 (checkCoreCellRange_succ 352 7 (checkCoreCellRange_succ 352 6 (checkCoreCellRange_succ 352 5 (checkCoreCellRange_succ 352 4 (checkCoreCellRange_succ 352 3 (checkCoreCellRange_succ 352 2 (checkCoreCellRange_succ 352 1 (checkCoreCellRange_succ 352 0 rfl cell352) cell353) cell354) cell355) cell356) cell357) cell358) cell359) cell360) cell361) cell362) cell363) cell364) cell365) cell366) cell367

#print axioms block22

end QuarticKernel.KernelCells
