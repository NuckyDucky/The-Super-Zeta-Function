import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell512 : checkCoreCellRange 512 1 = true := by
  decide +kernel

private theorem cell513 : checkCoreCellRange 513 1 = true := by
  decide +kernel

private theorem cell514 : checkCoreCellRange 514 1 = true := by
  decide +kernel

private theorem cell515 : checkCoreCellRange 515 1 = true := by
  decide +kernel

private theorem cell516 : checkCoreCellRange 516 1 = true := by
  decide +kernel

private theorem cell517 : checkCoreCellRange 517 1 = true := by
  decide +kernel

private theorem cell518 : checkCoreCellRange 518 1 = true := by
  decide +kernel

private theorem cell519 : checkCoreCellRange 519 1 = true := by
  decide +kernel

private theorem cell520 : checkCoreCellRange 520 1 = true := by
  decide +kernel

private theorem cell521 : checkCoreCellRange 521 1 = true := by
  decide +kernel

private theorem cell522 : checkCoreCellRange 522 1 = true := by
  decide +kernel

private theorem cell523 : checkCoreCellRange 523 1 = true := by
  decide +kernel

private theorem cell524 : checkCoreCellRange 524 1 = true := by
  decide +kernel

private theorem cell525 : checkCoreCellRange 525 1 = true := by
  decide +kernel

private theorem cell526 : checkCoreCellRange 526 1 = true := by
  decide +kernel

private theorem cell527 : checkCoreCellRange 527 1 = true := by
  decide +kernel

theorem block32 : checkCoreCellRange 512 16 = true :=
  checkCoreCellRange_succ 512 15 (checkCoreCellRange_succ 512 14 (checkCoreCellRange_succ 512 13 (checkCoreCellRange_succ 512 12 (checkCoreCellRange_succ 512 11 (checkCoreCellRange_succ 512 10 (checkCoreCellRange_succ 512 9 (checkCoreCellRange_succ 512 8 (checkCoreCellRange_succ 512 7 (checkCoreCellRange_succ 512 6 (checkCoreCellRange_succ 512 5 (checkCoreCellRange_succ 512 4 (checkCoreCellRange_succ 512 3 (checkCoreCellRange_succ 512 2 (checkCoreCellRange_succ 512 1 (checkCoreCellRange_succ 512 0 rfl cell512) cell513) cell514) cell515) cell516) cell517) cell518) cell519) cell520) cell521) cell522) cell523) cell524) cell525) cell526) cell527

#print axioms block32

end QuarticKernel.KernelCells
