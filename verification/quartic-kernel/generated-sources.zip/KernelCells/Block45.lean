import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell720 : checkCoreCellRange 720 1 = true := by
  decide +kernel

private theorem cell721 : checkCoreCellRange 721 1 = true := by
  decide +kernel

private theorem cell722 : checkCoreCellRange 722 1 = true := by
  decide +kernel

private theorem cell723 : checkCoreCellRange 723 1 = true := by
  decide +kernel

private theorem cell724 : checkCoreCellRange 724 1 = true := by
  decide +kernel

private theorem cell725 : checkCoreCellRange 725 1 = true := by
  decide +kernel

private theorem cell726 : checkCoreCellRange 726 1 = true := by
  decide +kernel

private theorem cell727 : checkCoreCellRange 727 1 = true := by
  decide +kernel

private theorem cell728 : checkCoreCellRange 728 1 = true := by
  decide +kernel

private theorem cell729 : checkCoreCellRange 729 1 = true := by
  decide +kernel

private theorem cell730 : checkCoreCellRange 730 1 = true := by
  decide +kernel

private theorem cell731 : checkCoreCellRange 731 1 = true := by
  decide +kernel

private theorem cell732 : checkCoreCellRange 732 1 = true := by
  decide +kernel

private theorem cell733 : checkCoreCellRange 733 1 = true := by
  decide +kernel

private theorem cell734 : checkCoreCellRange 734 1 = true := by
  decide +kernel

private theorem cell735 : checkCoreCellRange 735 1 = true := by
  decide +kernel

theorem block45 : checkCoreCellRange 720 16 = true :=
  checkCoreCellRange_succ 720 15 (checkCoreCellRange_succ 720 14 (checkCoreCellRange_succ 720 13 (checkCoreCellRange_succ 720 12 (checkCoreCellRange_succ 720 11 (checkCoreCellRange_succ 720 10 (checkCoreCellRange_succ 720 9 (checkCoreCellRange_succ 720 8 (checkCoreCellRange_succ 720 7 (checkCoreCellRange_succ 720 6 (checkCoreCellRange_succ 720 5 (checkCoreCellRange_succ 720 4 (checkCoreCellRange_succ 720 3 (checkCoreCellRange_succ 720 2 (checkCoreCellRange_succ 720 1 (checkCoreCellRange_succ 720 0 rfl cell720) cell721) cell722) cell723) cell724) cell725) cell726) cell727) cell728) cell729) cell730) cell731) cell732) cell733) cell734) cell735

#print axioms block45

end QuarticKernel.KernelCells
