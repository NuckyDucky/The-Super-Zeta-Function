import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell256 : checkCoreCellRange 256 1 = true := by
  decide +kernel

private theorem cell257 : checkCoreCellRange 257 1 = true := by
  decide +kernel

private theorem cell258 : checkCoreCellRange 258 1 = true := by
  decide +kernel

private theorem cell259 : checkCoreCellRange 259 1 = true := by
  decide +kernel

private theorem cell260 : checkCoreCellRange 260 1 = true := by
  decide +kernel

private theorem cell261 : checkCoreCellRange 261 1 = true := by
  decide +kernel

private theorem cell262 : checkCoreCellRange 262 1 = true := by
  decide +kernel

private theorem cell263 : checkCoreCellRange 263 1 = true := by
  decide +kernel

private theorem cell264 : checkCoreCellRange 264 1 = true := by
  decide +kernel

private theorem cell265 : checkCoreCellRange 265 1 = true := by
  decide +kernel

private theorem cell266 : checkCoreCellRange 266 1 = true := by
  decide +kernel

private theorem cell267 : checkCoreCellRange 267 1 = true := by
  decide +kernel

private theorem cell268 : checkCoreCellRange 268 1 = true := by
  decide +kernel

private theorem cell269 : checkCoreCellRange 269 1 = true := by
  decide +kernel

private theorem cell270 : checkCoreCellRange 270 1 = true := by
  decide +kernel

private theorem cell271 : checkCoreCellRange 271 1 = true := by
  decide +kernel

theorem block16 : checkCoreCellRange 256 16 = true :=
  checkCoreCellRange_succ 256 15 (checkCoreCellRange_succ 256 14 (checkCoreCellRange_succ 256 13 (checkCoreCellRange_succ 256 12 (checkCoreCellRange_succ 256 11 (checkCoreCellRange_succ 256 10 (checkCoreCellRange_succ 256 9 (checkCoreCellRange_succ 256 8 (checkCoreCellRange_succ 256 7 (checkCoreCellRange_succ 256 6 (checkCoreCellRange_succ 256 5 (checkCoreCellRange_succ 256 4 (checkCoreCellRange_succ 256 3 (checkCoreCellRange_succ 256 2 (checkCoreCellRange_succ 256 1 (checkCoreCellRange_succ 256 0 rfl cell256) cell257) cell258) cell259) cell260) cell261) cell262) cell263) cell264) cell265) cell266) cell267) cell268) cell269) cell270) cell271

#print axioms block16

end QuarticKernel.KernelCells
