import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell464 : checkCoreCellRange 464 1 = true := by
  decide +kernel

private theorem cell465 : checkCoreCellRange 465 1 = true := by
  decide +kernel

private theorem cell466 : checkCoreCellRange 466 1 = true := by
  decide +kernel

private theorem cell467 : checkCoreCellRange 467 1 = true := by
  decide +kernel

private theorem cell468 : checkCoreCellRange 468 1 = true := by
  decide +kernel

private theorem cell469 : checkCoreCellRange 469 1 = true := by
  decide +kernel

private theorem cell470 : checkCoreCellRange 470 1 = true := by
  decide +kernel

private theorem cell471 : checkCoreCellRange 471 1 = true := by
  decide +kernel

private theorem cell472 : checkCoreCellRange 472 1 = true := by
  decide +kernel

private theorem cell473 : checkCoreCellRange 473 1 = true := by
  decide +kernel

private theorem cell474 : checkCoreCellRange 474 1 = true := by
  decide +kernel

private theorem cell475 : checkCoreCellRange 475 1 = true := by
  decide +kernel

private theorem cell476 : checkCoreCellRange 476 1 = true := by
  decide +kernel

private theorem cell477 : checkCoreCellRange 477 1 = true := by
  decide +kernel

private theorem cell478 : checkCoreCellRange 478 1 = true := by
  decide +kernel

private theorem cell479 : checkCoreCellRange 479 1 = true := by
  decide +kernel

theorem block29 : checkCoreCellRange 464 16 = true :=
  checkCoreCellRange_succ 464 15 (checkCoreCellRange_succ 464 14 (checkCoreCellRange_succ 464 13 (checkCoreCellRange_succ 464 12 (checkCoreCellRange_succ 464 11 (checkCoreCellRange_succ 464 10 (checkCoreCellRange_succ 464 9 (checkCoreCellRange_succ 464 8 (checkCoreCellRange_succ 464 7 (checkCoreCellRange_succ 464 6 (checkCoreCellRange_succ 464 5 (checkCoreCellRange_succ 464 4 (checkCoreCellRange_succ 464 3 (checkCoreCellRange_succ 464 2 (checkCoreCellRange_succ 464 1 (checkCoreCellRange_succ 464 0 rfl cell464) cell465) cell466) cell467) cell468) cell469) cell470) cell471) cell472) cell473) cell474) cell475) cell476) cell477) cell478) cell479

#print axioms block29

end QuarticKernel.KernelCells
