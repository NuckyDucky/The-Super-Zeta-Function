import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell304 : checkCoreCellRange 304 1 = true := by
  decide +kernel

private theorem cell305 : checkCoreCellRange 305 1 = true := by
  decide +kernel

private theorem cell306 : checkCoreCellRange 306 1 = true := by
  decide +kernel

private theorem cell307 : checkCoreCellRange 307 1 = true := by
  decide +kernel

private theorem cell308 : checkCoreCellRange 308 1 = true := by
  decide +kernel

private theorem cell309 : checkCoreCellRange 309 1 = true := by
  decide +kernel

private theorem cell310 : checkCoreCellRange 310 1 = true := by
  decide +kernel

private theorem cell311 : checkCoreCellRange 311 1 = true := by
  decide +kernel

private theorem cell312 : checkCoreCellRange 312 1 = true := by
  decide +kernel

private theorem cell313 : checkCoreCellRange 313 1 = true := by
  decide +kernel

private theorem cell314 : checkCoreCellRange 314 1 = true := by
  decide +kernel

private theorem cell315 : checkCoreCellRange 315 1 = true := by
  decide +kernel

private theorem cell316 : checkCoreCellRange 316 1 = true := by
  decide +kernel

private theorem cell317 : checkCoreCellRange 317 1 = true := by
  decide +kernel

private theorem cell318 : checkCoreCellRange 318 1 = true := by
  decide +kernel

private theorem cell319 : checkCoreCellRange 319 1 = true := by
  decide +kernel

theorem block19 : checkCoreCellRange 304 16 = true :=
  checkCoreCellRange_succ 304 15 (checkCoreCellRange_succ 304 14 (checkCoreCellRange_succ 304 13 (checkCoreCellRange_succ 304 12 (checkCoreCellRange_succ 304 11 (checkCoreCellRange_succ 304 10 (checkCoreCellRange_succ 304 9 (checkCoreCellRange_succ 304 8 (checkCoreCellRange_succ 304 7 (checkCoreCellRange_succ 304 6 (checkCoreCellRange_succ 304 5 (checkCoreCellRange_succ 304 4 (checkCoreCellRange_succ 304 3 (checkCoreCellRange_succ 304 2 (checkCoreCellRange_succ 304 1 (checkCoreCellRange_succ 304 0 rfl cell304) cell305) cell306) cell307) cell308) cell309) cell310) cell311) cell312) cell313) cell314) cell315) cell316) cell317) cell318) cell319

#print axioms block19

end QuarticKernel.KernelCells
