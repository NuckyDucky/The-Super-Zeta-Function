import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell816 : checkCoreCellRange 816 1 = true := by
  decide +kernel

private theorem cell817 : checkCoreCellRange 817 1 = true := by
  decide +kernel

private theorem cell818 : checkCoreCellRange 818 1 = true := by
  decide +kernel

private theorem cell819 : checkCoreCellRange 819 1 = true := by
  decide +kernel

private theorem cell820 : checkCoreCellRange 820 1 = true := by
  decide +kernel

private theorem cell821 : checkCoreCellRange 821 1 = true := by
  decide +kernel

private theorem cell822 : checkCoreCellRange 822 1 = true := by
  decide +kernel

private theorem cell823 : checkCoreCellRange 823 1 = true := by
  decide +kernel

private theorem cell824 : checkCoreCellRange 824 1 = true := by
  decide +kernel

private theorem cell825 : checkCoreCellRange 825 1 = true := by
  decide +kernel

private theorem cell826 : checkCoreCellRange 826 1 = true := by
  decide +kernel

private theorem cell827 : checkCoreCellRange 827 1 = true := by
  decide +kernel

private theorem cell828 : checkCoreCellRange 828 1 = true := by
  decide +kernel

private theorem cell829 : checkCoreCellRange 829 1 = true := by
  decide +kernel

private theorem cell830 : checkCoreCellRange 830 1 = true := by
  decide +kernel

private theorem cell831 : checkCoreCellRange 831 1 = true := by
  decide +kernel

theorem block51 : checkCoreCellRange 816 16 = true :=
  checkCoreCellRange_succ 816 15 (checkCoreCellRange_succ 816 14 (checkCoreCellRange_succ 816 13 (checkCoreCellRange_succ 816 12 (checkCoreCellRange_succ 816 11 (checkCoreCellRange_succ 816 10 (checkCoreCellRange_succ 816 9 (checkCoreCellRange_succ 816 8 (checkCoreCellRange_succ 816 7 (checkCoreCellRange_succ 816 6 (checkCoreCellRange_succ 816 5 (checkCoreCellRange_succ 816 4 (checkCoreCellRange_succ 816 3 (checkCoreCellRange_succ 816 2 (checkCoreCellRange_succ 816 1 (checkCoreCellRange_succ 816 0 rfl cell816) cell817) cell818) cell819) cell820) cell821) cell822) cell823) cell824) cell825) cell826) cell827) cell828) cell829) cell830) cell831

#print axioms block51

end QuarticKernel.KernelCells
