import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell48 : checkCoreCellRange 48 1 = true := by
  decide +kernel

private theorem cell49 : checkCoreCellRange 49 1 = true := by
  decide +kernel

private theorem cell50 : checkCoreCellRange 50 1 = true := by
  decide +kernel

private theorem cell51 : checkCoreCellRange 51 1 = true := by
  decide +kernel

private theorem cell52 : checkCoreCellRange 52 1 = true := by
  decide +kernel

private theorem cell53 : checkCoreCellRange 53 1 = true := by
  decide +kernel

private theorem cell54 : checkCoreCellRange 54 1 = true := by
  decide +kernel

private theorem cell55 : checkCoreCellRange 55 1 = true := by
  decide +kernel

private theorem cell56 : checkCoreCellRange 56 1 = true := by
  decide +kernel

private theorem cell57 : checkCoreCellRange 57 1 = true := by
  decide +kernel

private theorem cell58 : checkCoreCellRange 58 1 = true := by
  decide +kernel

private theorem cell59 : checkCoreCellRange 59 1 = true := by
  decide +kernel

private theorem cell60 : checkCoreCellRange 60 1 = true := by
  decide +kernel

private theorem cell61 : checkCoreCellRange 61 1 = true := by
  decide +kernel

private theorem cell62 : checkCoreCellRange 62 1 = true := by
  decide +kernel

private theorem cell63 : checkCoreCellRange 63 1 = true := by
  decide +kernel

theorem block3 : checkCoreCellRange 48 16 = true :=
  checkCoreCellRange_succ 48 15 (checkCoreCellRange_succ 48 14 (checkCoreCellRange_succ 48 13 (checkCoreCellRange_succ 48 12 (checkCoreCellRange_succ 48 11 (checkCoreCellRange_succ 48 10 (checkCoreCellRange_succ 48 9 (checkCoreCellRange_succ 48 8 (checkCoreCellRange_succ 48 7 (checkCoreCellRange_succ 48 6 (checkCoreCellRange_succ 48 5 (checkCoreCellRange_succ 48 4 (checkCoreCellRange_succ 48 3 (checkCoreCellRange_succ 48 2 (checkCoreCellRange_succ 48 1 (checkCoreCellRange_succ 48 0 rfl cell48) cell49) cell50) cell51) cell52) cell53) cell54) cell55) cell56) cell57) cell58) cell59) cell60) cell61) cell62) cell63

#print axioms block3

end QuarticKernel.KernelCells
