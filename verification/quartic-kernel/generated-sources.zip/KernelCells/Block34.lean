import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell544 : checkCoreCellRange 544 1 = true := by
  decide +kernel

private theorem cell545 : checkCoreCellRange 545 1 = true := by
  decide +kernel

private theorem cell546 : checkCoreCellRange 546 1 = true := by
  decide +kernel

private theorem cell547 : checkCoreCellRange 547 1 = true := by
  decide +kernel

private theorem cell548 : checkCoreCellRange 548 1 = true := by
  decide +kernel

private theorem cell549 : checkCoreCellRange 549 1 = true := by
  decide +kernel

private theorem cell550 : checkCoreCellRange 550 1 = true := by
  decide +kernel

private theorem cell551 : checkCoreCellRange 551 1 = true := by
  decide +kernel

private theorem cell552 : checkCoreCellRange 552 1 = true := by
  decide +kernel

private theorem cell553 : checkCoreCellRange 553 1 = true := by
  decide +kernel

private theorem cell554 : checkCoreCellRange 554 1 = true := by
  decide +kernel

private theorem cell555 : checkCoreCellRange 555 1 = true := by
  decide +kernel

private theorem cell556 : checkCoreCellRange 556 1 = true := by
  decide +kernel

private theorem cell557 : checkCoreCellRange 557 1 = true := by
  decide +kernel

private theorem cell558 : checkCoreCellRange 558 1 = true := by
  decide +kernel

private theorem cell559 : checkCoreCellRange 559 1 = true := by
  decide +kernel

theorem block34 : checkCoreCellRange 544 16 = true :=
  checkCoreCellRange_succ 544 15 (checkCoreCellRange_succ 544 14 (checkCoreCellRange_succ 544 13 (checkCoreCellRange_succ 544 12 (checkCoreCellRange_succ 544 11 (checkCoreCellRange_succ 544 10 (checkCoreCellRange_succ 544 9 (checkCoreCellRange_succ 544 8 (checkCoreCellRange_succ 544 7 (checkCoreCellRange_succ 544 6 (checkCoreCellRange_succ 544 5 (checkCoreCellRange_succ 544 4 (checkCoreCellRange_succ 544 3 (checkCoreCellRange_succ 544 2 (checkCoreCellRange_succ 544 1 (checkCoreCellRange_succ 544 0 rfl cell544) cell545) cell546) cell547) cell548) cell549) cell550) cell551) cell552) cell553) cell554) cell555) cell556) cell557) cell558) cell559

#print axioms block34

end QuarticKernel.KernelCells
