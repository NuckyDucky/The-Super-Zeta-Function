import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell368 : checkCoreCellRange 368 1 = true := by
  decide +kernel

private theorem cell369 : checkCoreCellRange 369 1 = true := by
  decide +kernel

private theorem cell370 : checkCoreCellRange 370 1 = true := by
  decide +kernel

private theorem cell371 : checkCoreCellRange 371 1 = true := by
  decide +kernel

private theorem cell372 : checkCoreCellRange 372 1 = true := by
  decide +kernel

private theorem cell373 : checkCoreCellRange 373 1 = true := by
  decide +kernel

private theorem cell374 : checkCoreCellRange 374 1 = true := by
  decide +kernel

private theorem cell375 : checkCoreCellRange 375 1 = true := by
  decide +kernel

private theorem cell376 : checkCoreCellRange 376 1 = true := by
  decide +kernel

private theorem cell377 : checkCoreCellRange 377 1 = true := by
  decide +kernel

private theorem cell378 : checkCoreCellRange 378 1 = true := by
  decide +kernel

private theorem cell379 : checkCoreCellRange 379 1 = true := by
  decide +kernel

private theorem cell380 : checkCoreCellRange 380 1 = true := by
  decide +kernel

private theorem cell381 : checkCoreCellRange 381 1 = true := by
  decide +kernel

private theorem cell382 : checkCoreCellRange 382 1 = true := by
  decide +kernel

private theorem cell383 : checkCoreCellRange 383 1 = true := by
  decide +kernel

theorem block23 : checkCoreCellRange 368 16 = true :=
  checkCoreCellRange_succ 368 15 (checkCoreCellRange_succ 368 14 (checkCoreCellRange_succ 368 13 (checkCoreCellRange_succ 368 12 (checkCoreCellRange_succ 368 11 (checkCoreCellRange_succ 368 10 (checkCoreCellRange_succ 368 9 (checkCoreCellRange_succ 368 8 (checkCoreCellRange_succ 368 7 (checkCoreCellRange_succ 368 6 (checkCoreCellRange_succ 368 5 (checkCoreCellRange_succ 368 4 (checkCoreCellRange_succ 368 3 (checkCoreCellRange_succ 368 2 (checkCoreCellRange_succ 368 1 (checkCoreCellRange_succ 368 0 rfl cell368) cell369) cell370) cell371) cell372) cell373) cell374) cell375) cell376) cell377) cell378) cell379) cell380) cell381) cell382) cell383

#print axioms block23

end QuarticKernel.KernelCells
