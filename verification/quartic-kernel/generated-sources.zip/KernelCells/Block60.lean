import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell960 : checkCoreCellRange 960 1 = true := by
  decide +kernel

private theorem cell961 : checkCoreCellRange 961 1 = true := by
  decide +kernel

private theorem cell962 : checkCoreCellRange 962 1 = true := by
  decide +kernel

private theorem cell963 : checkCoreCellRange 963 1 = true := by
  decide +kernel

private theorem cell964 : checkCoreCellRange 964 1 = true := by
  decide +kernel

private theorem cell965 : checkCoreCellRange 965 1 = true := by
  decide +kernel

private theorem cell966 : checkCoreCellRange 966 1 = true := by
  decide +kernel

private theorem cell967 : checkCoreCellRange 967 1 = true := by
  decide +kernel

private theorem cell968 : checkCoreCellRange 968 1 = true := by
  decide +kernel

private theorem cell969 : checkCoreCellRange 969 1 = true := by
  decide +kernel

private theorem cell970 : checkCoreCellRange 970 1 = true := by
  decide +kernel

private theorem cell971 : checkCoreCellRange 971 1 = true := by
  decide +kernel

private theorem cell972 : checkCoreCellRange 972 1 = true := by
  decide +kernel

private theorem cell973 : checkCoreCellRange 973 1 = true := by
  decide +kernel

private theorem cell974 : checkCoreCellRange 974 1 = true := by
  decide +kernel

private theorem cell975 : checkCoreCellRange 975 1 = true := by
  decide +kernel

theorem block60 : checkCoreCellRange 960 16 = true :=
  checkCoreCellRange_succ 960 15 (checkCoreCellRange_succ 960 14 (checkCoreCellRange_succ 960 13 (checkCoreCellRange_succ 960 12 (checkCoreCellRange_succ 960 11 (checkCoreCellRange_succ 960 10 (checkCoreCellRange_succ 960 9 (checkCoreCellRange_succ 960 8 (checkCoreCellRange_succ 960 7 (checkCoreCellRange_succ 960 6 (checkCoreCellRange_succ 960 5 (checkCoreCellRange_succ 960 4 (checkCoreCellRange_succ 960 3 (checkCoreCellRange_succ 960 2 (checkCoreCellRange_succ 960 1 (checkCoreCellRange_succ 960 0 rfl cell960) cell961) cell962) cell963) cell964) cell965) cell966) cell967) cell968) cell969) cell970) cell971) cell972) cell973) cell974) cell975

#print axioms block60

end QuarticKernel.KernelCells
