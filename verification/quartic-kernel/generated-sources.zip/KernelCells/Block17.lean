import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell272 : checkCoreCellRange 272 1 = true := by
  decide +kernel

private theorem cell273 : checkCoreCellRange 273 1 = true := by
  decide +kernel

private theorem cell274 : checkCoreCellRange 274 1 = true := by
  decide +kernel

private theorem cell275 : checkCoreCellRange 275 1 = true := by
  decide +kernel

private theorem cell276 : checkCoreCellRange 276 1 = true := by
  decide +kernel

private theorem cell277 : checkCoreCellRange 277 1 = true := by
  decide +kernel

private theorem cell278 : checkCoreCellRange 278 1 = true := by
  decide +kernel

private theorem cell279 : checkCoreCellRange 279 1 = true := by
  decide +kernel

private theorem cell280 : checkCoreCellRange 280 1 = true := by
  decide +kernel

private theorem cell281 : checkCoreCellRange 281 1 = true := by
  decide +kernel

private theorem cell282 : checkCoreCellRange 282 1 = true := by
  decide +kernel

private theorem cell283 : checkCoreCellRange 283 1 = true := by
  decide +kernel

private theorem cell284 : checkCoreCellRange 284 1 = true := by
  decide +kernel

private theorem cell285 : checkCoreCellRange 285 1 = true := by
  decide +kernel

private theorem cell286 : checkCoreCellRange 286 1 = true := by
  decide +kernel

private theorem cell287 : checkCoreCellRange 287 1 = true := by
  decide +kernel

theorem block17 : checkCoreCellRange 272 16 = true :=
  checkCoreCellRange_succ 272 15 (checkCoreCellRange_succ 272 14 (checkCoreCellRange_succ 272 13 (checkCoreCellRange_succ 272 12 (checkCoreCellRange_succ 272 11 (checkCoreCellRange_succ 272 10 (checkCoreCellRange_succ 272 9 (checkCoreCellRange_succ 272 8 (checkCoreCellRange_succ 272 7 (checkCoreCellRange_succ 272 6 (checkCoreCellRange_succ 272 5 (checkCoreCellRange_succ 272 4 (checkCoreCellRange_succ 272 3 (checkCoreCellRange_succ 272 2 (checkCoreCellRange_succ 272 1 (checkCoreCellRange_succ 272 0 rfl cell272) cell273) cell274) cell275) cell276) cell277) cell278) cell279) cell280) cell281) cell282) cell283) cell284) cell285) cell286) cell287

#print axioms block17

end QuarticKernel.KernelCells
