import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell752 : checkCoreCellRange 752 1 = true := by
  decide +kernel

private theorem cell753 : checkCoreCellRange 753 1 = true := by
  decide +kernel

private theorem cell754 : checkCoreCellRange 754 1 = true := by
  decide +kernel

private theorem cell755 : checkCoreCellRange 755 1 = true := by
  decide +kernel

private theorem cell756 : checkCoreCellRange 756 1 = true := by
  decide +kernel

private theorem cell757 : checkCoreCellRange 757 1 = true := by
  decide +kernel

private theorem cell758 : checkCoreCellRange 758 1 = true := by
  decide +kernel

private theorem cell759 : checkCoreCellRange 759 1 = true := by
  decide +kernel

private theorem cell760 : checkCoreCellRange 760 1 = true := by
  decide +kernel

private theorem cell761 : checkCoreCellRange 761 1 = true := by
  decide +kernel

private theorem cell762 : checkCoreCellRange 762 1 = true := by
  decide +kernel

private theorem cell763 : checkCoreCellRange 763 1 = true := by
  decide +kernel

private theorem cell764 : checkCoreCellRange 764 1 = true := by
  decide +kernel

private theorem cell765 : checkCoreCellRange 765 1 = true := by
  decide +kernel

private theorem cell766 : checkCoreCellRange 766 1 = true := by
  decide +kernel

private theorem cell767 : checkCoreCellRange 767 1 = true := by
  decide +kernel

theorem block47 : checkCoreCellRange 752 16 = true :=
  checkCoreCellRange_succ 752 15 (checkCoreCellRange_succ 752 14 (checkCoreCellRange_succ 752 13 (checkCoreCellRange_succ 752 12 (checkCoreCellRange_succ 752 11 (checkCoreCellRange_succ 752 10 (checkCoreCellRange_succ 752 9 (checkCoreCellRange_succ 752 8 (checkCoreCellRange_succ 752 7 (checkCoreCellRange_succ 752 6 (checkCoreCellRange_succ 752 5 (checkCoreCellRange_succ 752 4 (checkCoreCellRange_succ 752 3 (checkCoreCellRange_succ 752 2 (checkCoreCellRange_succ 752 1 (checkCoreCellRange_succ 752 0 rfl cell752) cell753) cell754) cell755) cell756) cell757) cell758) cell759) cell760) cell761) cell762) cell763) cell764) cell765) cell766) cell767

#print axioms block47

end QuarticKernel.KernelCells
