import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell224 : checkCoreCellRange 224 1 = true := by
  decide +kernel

private theorem cell225 : checkCoreCellRange 225 1 = true := by
  decide +kernel

private theorem cell226 : checkCoreCellRange 226 1 = true := by
  decide +kernel

private theorem cell227 : checkCoreCellRange 227 1 = true := by
  decide +kernel

private theorem cell228 : checkCoreCellRange 228 1 = true := by
  decide +kernel

private theorem cell229 : checkCoreCellRange 229 1 = true := by
  decide +kernel

private theorem cell230 : checkCoreCellRange 230 1 = true := by
  decide +kernel

private theorem cell231 : checkCoreCellRange 231 1 = true := by
  decide +kernel

private theorem cell232 : checkCoreCellRange 232 1 = true := by
  decide +kernel

private theorem cell233 : checkCoreCellRange 233 1 = true := by
  decide +kernel

private theorem cell234 : checkCoreCellRange 234 1 = true := by
  decide +kernel

private theorem cell235 : checkCoreCellRange 235 1 = true := by
  decide +kernel

private theorem cell236 : checkCoreCellRange 236 1 = true := by
  decide +kernel

private theorem cell237 : checkCoreCellRange 237 1 = true := by
  decide +kernel

private theorem cell238 : checkCoreCellRange 238 1 = true := by
  decide +kernel

private theorem cell239 : checkCoreCellRange 239 1 = true := by
  decide +kernel

theorem block14 : checkCoreCellRange 224 16 = true :=
  checkCoreCellRange_succ 224 15 (checkCoreCellRange_succ 224 14 (checkCoreCellRange_succ 224 13 (checkCoreCellRange_succ 224 12 (checkCoreCellRange_succ 224 11 (checkCoreCellRange_succ 224 10 (checkCoreCellRange_succ 224 9 (checkCoreCellRange_succ 224 8 (checkCoreCellRange_succ 224 7 (checkCoreCellRange_succ 224 6 (checkCoreCellRange_succ 224 5 (checkCoreCellRange_succ 224 4 (checkCoreCellRange_succ 224 3 (checkCoreCellRange_succ 224 2 (checkCoreCellRange_succ 224 1 (checkCoreCellRange_succ 224 0 rfl cell224) cell225) cell226) cell227) cell228) cell229) cell230) cell231) cell232) cell233) cell234) cell235) cell236) cell237) cell238) cell239

#print axioms block14

end QuarticKernel.KernelCells
