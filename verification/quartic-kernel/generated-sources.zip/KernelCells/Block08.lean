import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell128 : checkCoreCellRange 128 1 = true := by
  decide +kernel

private theorem cell129 : checkCoreCellRange 129 1 = true := by
  decide +kernel

private theorem cell130 : checkCoreCellRange 130 1 = true := by
  decide +kernel

private theorem cell131 : checkCoreCellRange 131 1 = true := by
  decide +kernel

private theorem cell132 : checkCoreCellRange 132 1 = true := by
  decide +kernel

private theorem cell133 : checkCoreCellRange 133 1 = true := by
  decide +kernel

private theorem cell134 : checkCoreCellRange 134 1 = true := by
  decide +kernel

private theorem cell135 : checkCoreCellRange 135 1 = true := by
  decide +kernel

private theorem cell136 : checkCoreCellRange 136 1 = true := by
  decide +kernel

private theorem cell137 : checkCoreCellRange 137 1 = true := by
  decide +kernel

private theorem cell138 : checkCoreCellRange 138 1 = true := by
  decide +kernel

private theorem cell139 : checkCoreCellRange 139 1 = true := by
  decide +kernel

private theorem cell140 : checkCoreCellRange 140 1 = true := by
  decide +kernel

private theorem cell141 : checkCoreCellRange 141 1 = true := by
  decide +kernel

private theorem cell142 : checkCoreCellRange 142 1 = true := by
  decide +kernel

private theorem cell143 : checkCoreCellRange 143 1 = true := by
  decide +kernel

theorem block8 : checkCoreCellRange 128 16 = true :=
  checkCoreCellRange_succ 128 15 (checkCoreCellRange_succ 128 14 (checkCoreCellRange_succ 128 13 (checkCoreCellRange_succ 128 12 (checkCoreCellRange_succ 128 11 (checkCoreCellRange_succ 128 10 (checkCoreCellRange_succ 128 9 (checkCoreCellRange_succ 128 8 (checkCoreCellRange_succ 128 7 (checkCoreCellRange_succ 128 6 (checkCoreCellRange_succ 128 5 (checkCoreCellRange_succ 128 4 (checkCoreCellRange_succ 128 3 (checkCoreCellRange_succ 128 2 (checkCoreCellRange_succ 128 1 (checkCoreCellRange_succ 128 0 rfl cell128) cell129) cell130) cell131) cell132) cell133) cell134) cell135) cell136) cell137) cell138) cell139) cell140) cell141) cell142) cell143

#print axioms block8

end QuarticKernel.KernelCells
