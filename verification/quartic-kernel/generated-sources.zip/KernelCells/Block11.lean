import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell176 : checkCoreCellRange 176 1 = true := by
  decide +kernel

private theorem cell177 : checkCoreCellRange 177 1 = true := by
  decide +kernel

private theorem cell178 : checkCoreCellRange 178 1 = true := by
  decide +kernel

private theorem cell179 : checkCoreCellRange 179 1 = true := by
  decide +kernel

private theorem cell180 : checkCoreCellRange 180 1 = true := by
  decide +kernel

private theorem cell181 : checkCoreCellRange 181 1 = true := by
  decide +kernel

private theorem cell182 : checkCoreCellRange 182 1 = true := by
  decide +kernel

private theorem cell183 : checkCoreCellRange 183 1 = true := by
  decide +kernel

private theorem cell184 : checkCoreCellRange 184 1 = true := by
  decide +kernel

private theorem cell185 : checkCoreCellRange 185 1 = true := by
  decide +kernel

private theorem cell186 : checkCoreCellRange 186 1 = true := by
  decide +kernel

private theorem cell187 : checkCoreCellRange 187 1 = true := by
  decide +kernel

private theorem cell188 : checkCoreCellRange 188 1 = true := by
  decide +kernel

private theorem cell189 : checkCoreCellRange 189 1 = true := by
  decide +kernel

private theorem cell190 : checkCoreCellRange 190 1 = true := by
  decide +kernel

private theorem cell191 : checkCoreCellRange 191 1 = true := by
  decide +kernel

theorem block11 : checkCoreCellRange 176 16 = true :=
  checkCoreCellRange_succ 176 15 (checkCoreCellRange_succ 176 14 (checkCoreCellRange_succ 176 13 (checkCoreCellRange_succ 176 12 (checkCoreCellRange_succ 176 11 (checkCoreCellRange_succ 176 10 (checkCoreCellRange_succ 176 9 (checkCoreCellRange_succ 176 8 (checkCoreCellRange_succ 176 7 (checkCoreCellRange_succ 176 6 (checkCoreCellRange_succ 176 5 (checkCoreCellRange_succ 176 4 (checkCoreCellRange_succ 176 3 (checkCoreCellRange_succ 176 2 (checkCoreCellRange_succ 176 1 (checkCoreCellRange_succ 176 0 rfl cell176) cell177) cell178) cell179) cell180) cell181) cell182) cell183) cell184) cell185) cell186) cell187) cell188) cell189) cell190) cell191

#print axioms block11

end QuarticKernel.KernelCells
