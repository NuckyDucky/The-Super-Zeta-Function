import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell640 : checkCoreCellRange 640 1 = true := by
  decide +kernel

private theorem cell641 : checkCoreCellRange 641 1 = true := by
  decide +kernel

private theorem cell642 : checkCoreCellRange 642 1 = true := by
  decide +kernel

private theorem cell643 : checkCoreCellRange 643 1 = true := by
  decide +kernel

private theorem cell644 : checkCoreCellRange 644 1 = true := by
  decide +kernel

private theorem cell645 : checkCoreCellRange 645 1 = true := by
  decide +kernel

private theorem cell646 : checkCoreCellRange 646 1 = true := by
  decide +kernel

private theorem cell647 : checkCoreCellRange 647 1 = true := by
  decide +kernel

private theorem cell648 : checkCoreCellRange 648 1 = true := by
  decide +kernel

private theorem cell649 : checkCoreCellRange 649 1 = true := by
  decide +kernel

private theorem cell650 : checkCoreCellRange 650 1 = true := by
  decide +kernel

private theorem cell651 : checkCoreCellRange 651 1 = true := by
  decide +kernel

private theorem cell652 : checkCoreCellRange 652 1 = true := by
  decide +kernel

private theorem cell653 : checkCoreCellRange 653 1 = true := by
  decide +kernel

private theorem cell654 : checkCoreCellRange 654 1 = true := by
  decide +kernel

private theorem cell655 : checkCoreCellRange 655 1 = true := by
  decide +kernel

theorem block40 : checkCoreCellRange 640 16 = true :=
  checkCoreCellRange_succ 640 15 (checkCoreCellRange_succ 640 14 (checkCoreCellRange_succ 640 13 (checkCoreCellRange_succ 640 12 (checkCoreCellRange_succ 640 11 (checkCoreCellRange_succ 640 10 (checkCoreCellRange_succ 640 9 (checkCoreCellRange_succ 640 8 (checkCoreCellRange_succ 640 7 (checkCoreCellRange_succ 640 6 (checkCoreCellRange_succ 640 5 (checkCoreCellRange_succ 640 4 (checkCoreCellRange_succ 640 3 (checkCoreCellRange_succ 640 2 (checkCoreCellRange_succ 640 1 (checkCoreCellRange_succ 640 0 rfl cell640) cell641) cell642) cell643) cell644) cell645) cell646) cell647) cell648) cell649) cell650) cell651) cell652) cell653) cell654) cell655

#print axioms block40

end QuarticKernel.KernelCells
