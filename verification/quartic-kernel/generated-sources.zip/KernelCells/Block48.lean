import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell768 : checkCoreCellRange 768 1 = true := by
  decide +kernel

private theorem cell769 : checkCoreCellRange 769 1 = true := by
  decide +kernel

private theorem cell770 : checkCoreCellRange 770 1 = true := by
  decide +kernel

private theorem cell771 : checkCoreCellRange 771 1 = true := by
  decide +kernel

private theorem cell772 : checkCoreCellRange 772 1 = true := by
  decide +kernel

private theorem cell773 : checkCoreCellRange 773 1 = true := by
  decide +kernel

private theorem cell774 : checkCoreCellRange 774 1 = true := by
  decide +kernel

private theorem cell775 : checkCoreCellRange 775 1 = true := by
  decide +kernel

private theorem cell776 : checkCoreCellRange 776 1 = true := by
  decide +kernel

private theorem cell777 : checkCoreCellRange 777 1 = true := by
  decide +kernel

private theorem cell778 : checkCoreCellRange 778 1 = true := by
  decide +kernel

private theorem cell779 : checkCoreCellRange 779 1 = true := by
  decide +kernel

private theorem cell780 : checkCoreCellRange 780 1 = true := by
  decide +kernel

private theorem cell781 : checkCoreCellRange 781 1 = true := by
  decide +kernel

private theorem cell782 : checkCoreCellRange 782 1 = true := by
  decide +kernel

private theorem cell783 : checkCoreCellRange 783 1 = true := by
  decide +kernel

theorem block48 : checkCoreCellRange 768 16 = true :=
  checkCoreCellRange_succ 768 15 (checkCoreCellRange_succ 768 14 (checkCoreCellRange_succ 768 13 (checkCoreCellRange_succ 768 12 (checkCoreCellRange_succ 768 11 (checkCoreCellRange_succ 768 10 (checkCoreCellRange_succ 768 9 (checkCoreCellRange_succ 768 8 (checkCoreCellRange_succ 768 7 (checkCoreCellRange_succ 768 6 (checkCoreCellRange_succ 768 5 (checkCoreCellRange_succ 768 4 (checkCoreCellRange_succ 768 3 (checkCoreCellRange_succ 768 2 (checkCoreCellRange_succ 768 1 (checkCoreCellRange_succ 768 0 rfl cell768) cell769) cell770) cell771) cell772) cell773) cell774) cell775) cell776) cell777) cell778) cell779) cell780) cell781) cell782) cell783

#print axioms block48

end QuarticKernel.KernelCells
