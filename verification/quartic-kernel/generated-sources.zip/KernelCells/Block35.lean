import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell560 : checkCoreCellRange 560 1 = true := by
  decide +kernel

private theorem cell561 : checkCoreCellRange 561 1 = true := by
  decide +kernel

private theorem cell562 : checkCoreCellRange 562 1 = true := by
  decide +kernel

private theorem cell563 : checkCoreCellRange 563 1 = true := by
  decide +kernel

private theorem cell564 : checkCoreCellRange 564 1 = true := by
  decide +kernel

private theorem cell565 : checkCoreCellRange 565 1 = true := by
  decide +kernel

private theorem cell566 : checkCoreCellRange 566 1 = true := by
  decide +kernel

private theorem cell567 : checkCoreCellRange 567 1 = true := by
  decide +kernel

private theorem cell568 : checkCoreCellRange 568 1 = true := by
  decide +kernel

private theorem cell569 : checkCoreCellRange 569 1 = true := by
  decide +kernel

private theorem cell570 : checkCoreCellRange 570 1 = true := by
  decide +kernel

private theorem cell571 : checkCoreCellRange 571 1 = true := by
  decide +kernel

private theorem cell572 : checkCoreCellRange 572 1 = true := by
  decide +kernel

private theorem cell573 : checkCoreCellRange 573 1 = true := by
  decide +kernel

private theorem cell574 : checkCoreCellRange 574 1 = true := by
  decide +kernel

private theorem cell575 : checkCoreCellRange 575 1 = true := by
  decide +kernel

theorem block35 : checkCoreCellRange 560 16 = true :=
  checkCoreCellRange_succ 560 15 (checkCoreCellRange_succ 560 14 (checkCoreCellRange_succ 560 13 (checkCoreCellRange_succ 560 12 (checkCoreCellRange_succ 560 11 (checkCoreCellRange_succ 560 10 (checkCoreCellRange_succ 560 9 (checkCoreCellRange_succ 560 8 (checkCoreCellRange_succ 560 7 (checkCoreCellRange_succ 560 6 (checkCoreCellRange_succ 560 5 (checkCoreCellRange_succ 560 4 (checkCoreCellRange_succ 560 3 (checkCoreCellRange_succ 560 2 (checkCoreCellRange_succ 560 1 (checkCoreCellRange_succ 560 0 rfl cell560) cell561) cell562) cell563) cell564) cell565) cell566) cell567) cell568) cell569) cell570) cell571) cell572) cell573) cell574) cell575

#print axioms block35

end QuarticKernel.KernelCells
