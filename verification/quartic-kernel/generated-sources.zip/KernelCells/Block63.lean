import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell1008 : checkCoreCellRange 1008 1 = true := by
  decide +kernel

private theorem cell1009 : checkCoreCellRange 1009 1 = true := by
  decide +kernel

private theorem cell1010 : checkCoreCellRange 1010 1 = true := by
  decide +kernel

private theorem cell1011 : checkCoreCellRange 1011 1 = true := by
  decide +kernel

private theorem cell1012 : checkCoreCellRange 1012 1 = true := by
  decide +kernel

private theorem cell1013 : checkCoreCellRange 1013 1 = true := by
  decide +kernel

private theorem cell1014 : checkCoreCellRange 1014 1 = true := by
  decide +kernel

private theorem cell1015 : checkCoreCellRange 1015 1 = true := by
  decide +kernel

private theorem cell1016 : checkCoreCellRange 1016 1 = true := by
  decide +kernel

private theorem cell1017 : checkCoreCellRange 1017 1 = true := by
  decide +kernel

private theorem cell1018 : checkCoreCellRange 1018 1 = true := by
  decide +kernel

private theorem cell1019 : checkCoreCellRange 1019 1 = true := by
  decide +kernel

private theorem cell1020 : checkCoreCellRange 1020 1 = true := by
  decide +kernel

private theorem cell1021 : checkCoreCellRange 1021 1 = true := by
  decide +kernel

private theorem cell1022 : checkCoreCellRange 1022 1 = true := by
  decide +kernel

private theorem cell1023 : checkCoreCellRange 1023 1 = true := by
  decide +kernel

theorem block63 : checkCoreCellRange 1008 16 = true :=
  checkCoreCellRange_succ 1008 15 (checkCoreCellRange_succ 1008 14 (checkCoreCellRange_succ 1008 13 (checkCoreCellRange_succ 1008 12 (checkCoreCellRange_succ 1008 11 (checkCoreCellRange_succ 1008 10 (checkCoreCellRange_succ 1008 9 (checkCoreCellRange_succ 1008 8 (checkCoreCellRange_succ 1008 7 (checkCoreCellRange_succ 1008 6 (checkCoreCellRange_succ 1008 5 (checkCoreCellRange_succ 1008 4 (checkCoreCellRange_succ 1008 3 (checkCoreCellRange_succ 1008 2 (checkCoreCellRange_succ 1008 1 (checkCoreCellRange_succ 1008 0 rfl cell1008) cell1009) cell1010) cell1011) cell1012) cell1013) cell1014) cell1015) cell1016) cell1017) cell1018) cell1019) cell1020) cell1021) cell1022) cell1023

#print axioms block63

end QuarticKernel.KernelCells
