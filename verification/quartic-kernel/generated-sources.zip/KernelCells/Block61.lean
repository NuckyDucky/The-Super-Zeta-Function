import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell976 : checkCoreCellRange 976 1 = true := by
  decide +kernel

private theorem cell977 : checkCoreCellRange 977 1 = true := by
  decide +kernel

private theorem cell978 : checkCoreCellRange 978 1 = true := by
  decide +kernel

private theorem cell979 : checkCoreCellRange 979 1 = true := by
  decide +kernel

private theorem cell980 : checkCoreCellRange 980 1 = true := by
  decide +kernel

private theorem cell981 : checkCoreCellRange 981 1 = true := by
  decide +kernel

private theorem cell982 : checkCoreCellRange 982 1 = true := by
  decide +kernel

private theorem cell983 : checkCoreCellRange 983 1 = true := by
  decide +kernel

private theorem cell984 : checkCoreCellRange 984 1 = true := by
  decide +kernel

private theorem cell985 : checkCoreCellRange 985 1 = true := by
  decide +kernel

private theorem cell986 : checkCoreCellRange 986 1 = true := by
  decide +kernel

private theorem cell987 : checkCoreCellRange 987 1 = true := by
  decide +kernel

private theorem cell988 : checkCoreCellRange 988 1 = true := by
  decide +kernel

private theorem cell989 : checkCoreCellRange 989 1 = true := by
  decide +kernel

private theorem cell990 : checkCoreCellRange 990 1 = true := by
  decide +kernel

private theorem cell991 : checkCoreCellRange 991 1 = true := by
  decide +kernel

theorem block61 : checkCoreCellRange 976 16 = true :=
  checkCoreCellRange_succ 976 15 (checkCoreCellRange_succ 976 14 (checkCoreCellRange_succ 976 13 (checkCoreCellRange_succ 976 12 (checkCoreCellRange_succ 976 11 (checkCoreCellRange_succ 976 10 (checkCoreCellRange_succ 976 9 (checkCoreCellRange_succ 976 8 (checkCoreCellRange_succ 976 7 (checkCoreCellRange_succ 976 6 (checkCoreCellRange_succ 976 5 (checkCoreCellRange_succ 976 4 (checkCoreCellRange_succ 976 3 (checkCoreCellRange_succ 976 2 (checkCoreCellRange_succ 976 1 (checkCoreCellRange_succ 976 0 rfl cell976) cell977) cell978) cell979) cell980) cell981) cell982) cell983) cell984) cell985) cell986) cell987) cell988) cell989) cell990) cell991

#print axioms block61

end QuarticKernel.KernelCells
