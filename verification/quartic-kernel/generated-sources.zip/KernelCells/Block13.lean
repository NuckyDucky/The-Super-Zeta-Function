import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell208 : checkCoreCellRange 208 1 = true := by
  decide +kernel

private theorem cell209 : checkCoreCellRange 209 1 = true := by
  decide +kernel

private theorem cell210 : checkCoreCellRange 210 1 = true := by
  decide +kernel

private theorem cell211 : checkCoreCellRange 211 1 = true := by
  decide +kernel

private theorem cell212 : checkCoreCellRange 212 1 = true := by
  decide +kernel

private theorem cell213 : checkCoreCellRange 213 1 = true := by
  decide +kernel

private theorem cell214 : checkCoreCellRange 214 1 = true := by
  decide +kernel

private theorem cell215 : checkCoreCellRange 215 1 = true := by
  decide +kernel

private theorem cell216 : checkCoreCellRange 216 1 = true := by
  decide +kernel

private theorem cell217 : checkCoreCellRange 217 1 = true := by
  decide +kernel

private theorem cell218 : checkCoreCellRange 218 1 = true := by
  decide +kernel

private theorem cell219 : checkCoreCellRange 219 1 = true := by
  decide +kernel

private theorem cell220 : checkCoreCellRange 220 1 = true := by
  decide +kernel

private theorem cell221 : checkCoreCellRange 221 1 = true := by
  decide +kernel

private theorem cell222 : checkCoreCellRange 222 1 = true := by
  decide +kernel

private theorem cell223 : checkCoreCellRange 223 1 = true := by
  decide +kernel

theorem block13 : checkCoreCellRange 208 16 = true :=
  checkCoreCellRange_succ 208 15 (checkCoreCellRange_succ 208 14 (checkCoreCellRange_succ 208 13 (checkCoreCellRange_succ 208 12 (checkCoreCellRange_succ 208 11 (checkCoreCellRange_succ 208 10 (checkCoreCellRange_succ 208 9 (checkCoreCellRange_succ 208 8 (checkCoreCellRange_succ 208 7 (checkCoreCellRange_succ 208 6 (checkCoreCellRange_succ 208 5 (checkCoreCellRange_succ 208 4 (checkCoreCellRange_succ 208 3 (checkCoreCellRange_succ 208 2 (checkCoreCellRange_succ 208 1 (checkCoreCellRange_succ 208 0 rfl cell208) cell209) cell210) cell211) cell212) cell213) cell214) cell215) cell216) cell217) cell218) cell219) cell220) cell221) cell222) cell223

#print axioms block13

end QuarticKernel.KernelCells
