import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell624 : checkCoreCellRange 624 1 = true := by
  decide +kernel

private theorem cell625 : checkCoreCellRange 625 1 = true := by
  decide +kernel

private theorem cell626 : checkCoreCellRange 626 1 = true := by
  decide +kernel

private theorem cell627 : checkCoreCellRange 627 1 = true := by
  decide +kernel

private theorem cell628 : checkCoreCellRange 628 1 = true := by
  decide +kernel

private theorem cell629 : checkCoreCellRange 629 1 = true := by
  decide +kernel

private theorem cell630 : checkCoreCellRange 630 1 = true := by
  decide +kernel

private theorem cell631 : checkCoreCellRange 631 1 = true := by
  decide +kernel

private theorem cell632 : checkCoreCellRange 632 1 = true := by
  decide +kernel

private theorem cell633 : checkCoreCellRange 633 1 = true := by
  decide +kernel

private theorem cell634 : checkCoreCellRange 634 1 = true := by
  decide +kernel

private theorem cell635 : checkCoreCellRange 635 1 = true := by
  decide +kernel

private theorem cell636 : checkCoreCellRange 636 1 = true := by
  decide +kernel

private theorem cell637 : checkCoreCellRange 637 1 = true := by
  decide +kernel

private theorem cell638 : checkCoreCellRange 638 1 = true := by
  decide +kernel

private theorem cell639 : checkCoreCellRange 639 1 = true := by
  decide +kernel

theorem block39 : checkCoreCellRange 624 16 = true :=
  checkCoreCellRange_succ 624 15 (checkCoreCellRange_succ 624 14 (checkCoreCellRange_succ 624 13 (checkCoreCellRange_succ 624 12 (checkCoreCellRange_succ 624 11 (checkCoreCellRange_succ 624 10 (checkCoreCellRange_succ 624 9 (checkCoreCellRange_succ 624 8 (checkCoreCellRange_succ 624 7 (checkCoreCellRange_succ 624 6 (checkCoreCellRange_succ 624 5 (checkCoreCellRange_succ 624 4 (checkCoreCellRange_succ 624 3 (checkCoreCellRange_succ 624 2 (checkCoreCellRange_succ 624 1 (checkCoreCellRange_succ 624 0 rfl cell624) cell625) cell626) cell627) cell628) cell629) cell630) cell631) cell632) cell633) cell634) cell635) cell636) cell637) cell638) cell639

#print axioms block39

end QuarticKernel.KernelCells
