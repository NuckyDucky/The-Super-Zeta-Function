import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell704 : checkCoreCellRange 704 1 = true := by
  decide +kernel

private theorem cell705 : checkCoreCellRange 705 1 = true := by
  decide +kernel

private theorem cell706 : checkCoreCellRange 706 1 = true := by
  decide +kernel

private theorem cell707 : checkCoreCellRange 707 1 = true := by
  decide +kernel

private theorem cell708 : checkCoreCellRange 708 1 = true := by
  decide +kernel

private theorem cell709 : checkCoreCellRange 709 1 = true := by
  decide +kernel

private theorem cell710 : checkCoreCellRange 710 1 = true := by
  decide +kernel

private theorem cell711 : checkCoreCellRange 711 1 = true := by
  decide +kernel

private theorem cell712 : checkCoreCellRange 712 1 = true := by
  decide +kernel

private theorem cell713 : checkCoreCellRange 713 1 = true := by
  decide +kernel

private theorem cell714 : checkCoreCellRange 714 1 = true := by
  decide +kernel

private theorem cell715 : checkCoreCellRange 715 1 = true := by
  decide +kernel

private theorem cell716 : checkCoreCellRange 716 1 = true := by
  decide +kernel

private theorem cell717 : checkCoreCellRange 717 1 = true := by
  decide +kernel

private theorem cell718 : checkCoreCellRange 718 1 = true := by
  decide +kernel

private theorem cell719 : checkCoreCellRange 719 1 = true := by
  decide +kernel

theorem block44 : checkCoreCellRange 704 16 = true :=
  checkCoreCellRange_succ 704 15 (checkCoreCellRange_succ 704 14 (checkCoreCellRange_succ 704 13 (checkCoreCellRange_succ 704 12 (checkCoreCellRange_succ 704 11 (checkCoreCellRange_succ 704 10 (checkCoreCellRange_succ 704 9 (checkCoreCellRange_succ 704 8 (checkCoreCellRange_succ 704 7 (checkCoreCellRange_succ 704 6 (checkCoreCellRange_succ 704 5 (checkCoreCellRange_succ 704 4 (checkCoreCellRange_succ 704 3 (checkCoreCellRange_succ 704 2 (checkCoreCellRange_succ 704 1 (checkCoreCellRange_succ 704 0 rfl cell704) cell705) cell706) cell707) cell708) cell709) cell710) cell711) cell712) cell713) cell714) cell715) cell716) cell717) cell718) cell719

#print axioms block44

end QuarticKernel.KernelCells
