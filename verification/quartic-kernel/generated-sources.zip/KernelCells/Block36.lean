import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell576 : checkCoreCellRange 576 1 = true := by
  decide +kernel

private theorem cell577 : checkCoreCellRange 577 1 = true := by
  decide +kernel

private theorem cell578 : checkCoreCellRange 578 1 = true := by
  decide +kernel

private theorem cell579 : checkCoreCellRange 579 1 = true := by
  decide +kernel

private theorem cell580 : checkCoreCellRange 580 1 = true := by
  decide +kernel

private theorem cell581 : checkCoreCellRange 581 1 = true := by
  decide +kernel

private theorem cell582 : checkCoreCellRange 582 1 = true := by
  decide +kernel

private theorem cell583 : checkCoreCellRange 583 1 = true := by
  decide +kernel

private theorem cell584 : checkCoreCellRange 584 1 = true := by
  decide +kernel

private theorem cell585 : checkCoreCellRange 585 1 = true := by
  decide +kernel

private theorem cell586 : checkCoreCellRange 586 1 = true := by
  decide +kernel

private theorem cell587 : checkCoreCellRange 587 1 = true := by
  decide +kernel

private theorem cell588 : checkCoreCellRange 588 1 = true := by
  decide +kernel

private theorem cell589 : checkCoreCellRange 589 1 = true := by
  decide +kernel

private theorem cell590 : checkCoreCellRange 590 1 = true := by
  decide +kernel

private theorem cell591 : checkCoreCellRange 591 1 = true := by
  decide +kernel

theorem block36 : checkCoreCellRange 576 16 = true :=
  checkCoreCellRange_succ 576 15 (checkCoreCellRange_succ 576 14 (checkCoreCellRange_succ 576 13 (checkCoreCellRange_succ 576 12 (checkCoreCellRange_succ 576 11 (checkCoreCellRange_succ 576 10 (checkCoreCellRange_succ 576 9 (checkCoreCellRange_succ 576 8 (checkCoreCellRange_succ 576 7 (checkCoreCellRange_succ 576 6 (checkCoreCellRange_succ 576 5 (checkCoreCellRange_succ 576 4 (checkCoreCellRange_succ 576 3 (checkCoreCellRange_succ 576 2 (checkCoreCellRange_succ 576 1 (checkCoreCellRange_succ 576 0 rfl cell576) cell577) cell578) cell579) cell580) cell581) cell582) cell583) cell584) cell585) cell586) cell587) cell588) cell589) cell590) cell591

#print axioms block36

end QuarticKernel.KernelCells
