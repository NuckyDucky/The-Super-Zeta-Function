import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell320 : checkCoreCellRange 320 1 = true := by
  decide +kernel

private theorem cell321 : checkCoreCellRange 321 1 = true := by
  decide +kernel

private theorem cell322 : checkCoreCellRange 322 1 = true := by
  decide +kernel

private theorem cell323 : checkCoreCellRange 323 1 = true := by
  decide +kernel

private theorem cell324 : checkCoreCellRange 324 1 = true := by
  decide +kernel

private theorem cell325 : checkCoreCellRange 325 1 = true := by
  decide +kernel

private theorem cell326 : checkCoreCellRange 326 1 = true := by
  decide +kernel

private theorem cell327 : checkCoreCellRange 327 1 = true := by
  decide +kernel

private theorem cell328 : checkCoreCellRange 328 1 = true := by
  decide +kernel

private theorem cell329 : checkCoreCellRange 329 1 = true := by
  decide +kernel

private theorem cell330 : checkCoreCellRange 330 1 = true := by
  decide +kernel

private theorem cell331 : checkCoreCellRange 331 1 = true := by
  decide +kernel

private theorem cell332 : checkCoreCellRange 332 1 = true := by
  decide +kernel

private theorem cell333 : checkCoreCellRange 333 1 = true := by
  decide +kernel

private theorem cell334 : checkCoreCellRange 334 1 = true := by
  decide +kernel

private theorem cell335 : checkCoreCellRange 335 1 = true := by
  decide +kernel

theorem block20 : checkCoreCellRange 320 16 = true :=
  checkCoreCellRange_succ 320 15 (checkCoreCellRange_succ 320 14 (checkCoreCellRange_succ 320 13 (checkCoreCellRange_succ 320 12 (checkCoreCellRange_succ 320 11 (checkCoreCellRange_succ 320 10 (checkCoreCellRange_succ 320 9 (checkCoreCellRange_succ 320 8 (checkCoreCellRange_succ 320 7 (checkCoreCellRange_succ 320 6 (checkCoreCellRange_succ 320 5 (checkCoreCellRange_succ 320 4 (checkCoreCellRange_succ 320 3 (checkCoreCellRange_succ 320 2 (checkCoreCellRange_succ 320 1 (checkCoreCellRange_succ 320 0 rfl cell320) cell321) cell322) cell323) cell324) cell325) cell326) cell327) cell328) cell329) cell330) cell331) cell332) cell333) cell334) cell335

#print axioms block20

end QuarticKernel.KernelCells
