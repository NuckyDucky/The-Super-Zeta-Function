import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell784 : checkCoreCellRange 784 1 = true := by
  decide +kernel

private theorem cell785 : checkCoreCellRange 785 1 = true := by
  decide +kernel

private theorem cell786 : checkCoreCellRange 786 1 = true := by
  decide +kernel

private theorem cell787 : checkCoreCellRange 787 1 = true := by
  decide +kernel

private theorem cell788 : checkCoreCellRange 788 1 = true := by
  decide +kernel

private theorem cell789 : checkCoreCellRange 789 1 = true := by
  decide +kernel

private theorem cell790 : checkCoreCellRange 790 1 = true := by
  decide +kernel

private theorem cell791 : checkCoreCellRange 791 1 = true := by
  decide +kernel

private theorem cell792 : checkCoreCellRange 792 1 = true := by
  decide +kernel

private theorem cell793 : checkCoreCellRange 793 1 = true := by
  decide +kernel

private theorem cell794 : checkCoreCellRange 794 1 = true := by
  decide +kernel

private theorem cell795 : checkCoreCellRange 795 1 = true := by
  decide +kernel

private theorem cell796 : checkCoreCellRange 796 1 = true := by
  decide +kernel

private theorem cell797 : checkCoreCellRange 797 1 = true := by
  decide +kernel

private theorem cell798 : checkCoreCellRange 798 1 = true := by
  decide +kernel

private theorem cell799 : checkCoreCellRange 799 1 = true := by
  decide +kernel

theorem block49 : checkCoreCellRange 784 16 = true :=
  checkCoreCellRange_succ 784 15 (checkCoreCellRange_succ 784 14 (checkCoreCellRange_succ 784 13 (checkCoreCellRange_succ 784 12 (checkCoreCellRange_succ 784 11 (checkCoreCellRange_succ 784 10 (checkCoreCellRange_succ 784 9 (checkCoreCellRange_succ 784 8 (checkCoreCellRange_succ 784 7 (checkCoreCellRange_succ 784 6 (checkCoreCellRange_succ 784 5 (checkCoreCellRange_succ 784 4 (checkCoreCellRange_succ 784 3 (checkCoreCellRange_succ 784 2 (checkCoreCellRange_succ 784 1 (checkCoreCellRange_succ 784 0 rfl cell784) cell785) cell786) cell787) cell788) cell789) cell790) cell791) cell792) cell793) cell794) cell795) cell796) cell797) cell798) cell799

#print axioms block49

end QuarticKernel.KernelCells
