import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell800 : checkCoreCellRange 800 1 = true := by
  decide +kernel

private theorem cell801 : checkCoreCellRange 801 1 = true := by
  decide +kernel

private theorem cell802 : checkCoreCellRange 802 1 = true := by
  decide +kernel

private theorem cell803 : checkCoreCellRange 803 1 = true := by
  decide +kernel

private theorem cell804 : checkCoreCellRange 804 1 = true := by
  decide +kernel

private theorem cell805 : checkCoreCellRange 805 1 = true := by
  decide +kernel

private theorem cell806 : checkCoreCellRange 806 1 = true := by
  decide +kernel

private theorem cell807 : checkCoreCellRange 807 1 = true := by
  decide +kernel

private theorem cell808 : checkCoreCellRange 808 1 = true := by
  decide +kernel

private theorem cell809 : checkCoreCellRange 809 1 = true := by
  decide +kernel

private theorem cell810 : checkCoreCellRange 810 1 = true := by
  decide +kernel

private theorem cell811 : checkCoreCellRange 811 1 = true := by
  decide +kernel

private theorem cell812 : checkCoreCellRange 812 1 = true := by
  decide +kernel

private theorem cell813 : checkCoreCellRange 813 1 = true := by
  decide +kernel

private theorem cell814 : checkCoreCellRange 814 1 = true := by
  decide +kernel

private theorem cell815 : checkCoreCellRange 815 1 = true := by
  decide +kernel

theorem block50 : checkCoreCellRange 800 16 = true :=
  checkCoreCellRange_succ 800 15 (checkCoreCellRange_succ 800 14 (checkCoreCellRange_succ 800 13 (checkCoreCellRange_succ 800 12 (checkCoreCellRange_succ 800 11 (checkCoreCellRange_succ 800 10 (checkCoreCellRange_succ 800 9 (checkCoreCellRange_succ 800 8 (checkCoreCellRange_succ 800 7 (checkCoreCellRange_succ 800 6 (checkCoreCellRange_succ 800 5 (checkCoreCellRange_succ 800 4 (checkCoreCellRange_succ 800 3 (checkCoreCellRange_succ 800 2 (checkCoreCellRange_succ 800 1 (checkCoreCellRange_succ 800 0 rfl cell800) cell801) cell802) cell803) cell804) cell805) cell806) cell807) cell808) cell809) cell810) cell811) cell812) cell813) cell814) cell815

#print axioms block50

end QuarticKernel.KernelCells
