import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell432 : checkCoreCellRange 432 1 = true := by
  decide +kernel

private theorem cell433 : checkCoreCellRange 433 1 = true := by
  decide +kernel

private theorem cell434 : checkCoreCellRange 434 1 = true := by
  decide +kernel

private theorem cell435 : checkCoreCellRange 435 1 = true := by
  decide +kernel

private theorem cell436 : checkCoreCellRange 436 1 = true := by
  decide +kernel

private theorem cell437 : checkCoreCellRange 437 1 = true := by
  decide +kernel

private theorem cell438 : checkCoreCellRange 438 1 = true := by
  decide +kernel

private theorem cell439 : checkCoreCellRange 439 1 = true := by
  decide +kernel

private theorem cell440 : checkCoreCellRange 440 1 = true := by
  decide +kernel

private theorem cell441 : checkCoreCellRange 441 1 = true := by
  decide +kernel

private theorem cell442 : checkCoreCellRange 442 1 = true := by
  decide +kernel

private theorem cell443 : checkCoreCellRange 443 1 = true := by
  decide +kernel

private theorem cell444 : checkCoreCellRange 444 1 = true := by
  decide +kernel

private theorem cell445 : checkCoreCellRange 445 1 = true := by
  decide +kernel

private theorem cell446 : checkCoreCellRange 446 1 = true := by
  decide +kernel

private theorem cell447 : checkCoreCellRange 447 1 = true := by
  decide +kernel

theorem block27 : checkCoreCellRange 432 16 = true :=
  checkCoreCellRange_succ 432 15 (checkCoreCellRange_succ 432 14 (checkCoreCellRange_succ 432 13 (checkCoreCellRange_succ 432 12 (checkCoreCellRange_succ 432 11 (checkCoreCellRange_succ 432 10 (checkCoreCellRange_succ 432 9 (checkCoreCellRange_succ 432 8 (checkCoreCellRange_succ 432 7 (checkCoreCellRange_succ 432 6 (checkCoreCellRange_succ 432 5 (checkCoreCellRange_succ 432 4 (checkCoreCellRange_succ 432 3 (checkCoreCellRange_succ 432 2 (checkCoreCellRange_succ 432 1 (checkCoreCellRange_succ 432 0 rfl cell432) cell433) cell434) cell435) cell436) cell437) cell438) cell439) cell440) cell441) cell442) cell443) cell444) cell445) cell446) cell447

#print axioms block27

end QuarticKernel.KernelCells
