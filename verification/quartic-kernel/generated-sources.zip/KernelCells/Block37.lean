import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell592 : checkCoreCellRange 592 1 = true := by
  decide +kernel

private theorem cell593 : checkCoreCellRange 593 1 = true := by
  decide +kernel

private theorem cell594 : checkCoreCellRange 594 1 = true := by
  decide +kernel

private theorem cell595 : checkCoreCellRange 595 1 = true := by
  decide +kernel

private theorem cell596 : checkCoreCellRange 596 1 = true := by
  decide +kernel

private theorem cell597 : checkCoreCellRange 597 1 = true := by
  decide +kernel

private theorem cell598 : checkCoreCellRange 598 1 = true := by
  decide +kernel

private theorem cell599 : checkCoreCellRange 599 1 = true := by
  decide +kernel

private theorem cell600 : checkCoreCellRange 600 1 = true := by
  decide +kernel

private theorem cell601 : checkCoreCellRange 601 1 = true := by
  decide +kernel

private theorem cell602 : checkCoreCellRange 602 1 = true := by
  decide +kernel

private theorem cell603 : checkCoreCellRange 603 1 = true := by
  decide +kernel

private theorem cell604 : checkCoreCellRange 604 1 = true := by
  decide +kernel

private theorem cell605 : checkCoreCellRange 605 1 = true := by
  decide +kernel

private theorem cell606 : checkCoreCellRange 606 1 = true := by
  decide +kernel

private theorem cell607 : checkCoreCellRange 607 1 = true := by
  decide +kernel

theorem block37 : checkCoreCellRange 592 16 = true :=
  checkCoreCellRange_succ 592 15 (checkCoreCellRange_succ 592 14 (checkCoreCellRange_succ 592 13 (checkCoreCellRange_succ 592 12 (checkCoreCellRange_succ 592 11 (checkCoreCellRange_succ 592 10 (checkCoreCellRange_succ 592 9 (checkCoreCellRange_succ 592 8 (checkCoreCellRange_succ 592 7 (checkCoreCellRange_succ 592 6 (checkCoreCellRange_succ 592 5 (checkCoreCellRange_succ 592 4 (checkCoreCellRange_succ 592 3 (checkCoreCellRange_succ 592 2 (checkCoreCellRange_succ 592 1 (checkCoreCellRange_succ 592 0 rfl cell592) cell593) cell594) cell595) cell596) cell597) cell598) cell599) cell600) cell601) cell602) cell603) cell604) cell605) cell606) cell607

#print axioms block37

end QuarticKernel.KernelCells
