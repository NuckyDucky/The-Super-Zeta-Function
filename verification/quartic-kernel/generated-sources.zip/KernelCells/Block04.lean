import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell64 : checkCoreCellRange 64 1 = true := by
  decide +kernel

private theorem cell65 : checkCoreCellRange 65 1 = true := by
  decide +kernel

private theorem cell66 : checkCoreCellRange 66 1 = true := by
  decide +kernel

private theorem cell67 : checkCoreCellRange 67 1 = true := by
  decide +kernel

private theorem cell68 : checkCoreCellRange 68 1 = true := by
  decide +kernel

private theorem cell69 : checkCoreCellRange 69 1 = true := by
  decide +kernel

private theorem cell70 : checkCoreCellRange 70 1 = true := by
  decide +kernel

private theorem cell71 : checkCoreCellRange 71 1 = true := by
  decide +kernel

private theorem cell72 : checkCoreCellRange 72 1 = true := by
  decide +kernel

private theorem cell73 : checkCoreCellRange 73 1 = true := by
  decide +kernel

private theorem cell74 : checkCoreCellRange 74 1 = true := by
  decide +kernel

private theorem cell75 : checkCoreCellRange 75 1 = true := by
  decide +kernel

private theorem cell76 : checkCoreCellRange 76 1 = true := by
  decide +kernel

private theorem cell77 : checkCoreCellRange 77 1 = true := by
  decide +kernel

private theorem cell78 : checkCoreCellRange 78 1 = true := by
  decide +kernel

private theorem cell79 : checkCoreCellRange 79 1 = true := by
  decide +kernel

theorem block4 : checkCoreCellRange 64 16 = true :=
  checkCoreCellRange_succ 64 15 (checkCoreCellRange_succ 64 14 (checkCoreCellRange_succ 64 13 (checkCoreCellRange_succ 64 12 (checkCoreCellRange_succ 64 11 (checkCoreCellRange_succ 64 10 (checkCoreCellRange_succ 64 9 (checkCoreCellRange_succ 64 8 (checkCoreCellRange_succ 64 7 (checkCoreCellRange_succ 64 6 (checkCoreCellRange_succ 64 5 (checkCoreCellRange_succ 64 4 (checkCoreCellRange_succ 64 3 (checkCoreCellRange_succ 64 2 (checkCoreCellRange_succ 64 1 (checkCoreCellRange_succ 64 0 rfl cell64) cell65) cell66) cell67) cell68) cell69) cell70) cell71) cell72) cell73) cell74) cell75) cell76) cell77) cell78) cell79

#print axioms block4

end QuarticKernel.KernelCells
