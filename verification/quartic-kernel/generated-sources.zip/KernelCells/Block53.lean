import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell848 : checkCoreCellRange 848 1 = true := by
  decide +kernel

private theorem cell849 : checkCoreCellRange 849 1 = true := by
  decide +kernel

private theorem cell850 : checkCoreCellRange 850 1 = true := by
  decide +kernel

private theorem cell851 : checkCoreCellRange 851 1 = true := by
  decide +kernel

private theorem cell852 : checkCoreCellRange 852 1 = true := by
  decide +kernel

private theorem cell853 : checkCoreCellRange 853 1 = true := by
  decide +kernel

private theorem cell854 : checkCoreCellRange 854 1 = true := by
  decide +kernel

private theorem cell855 : checkCoreCellRange 855 1 = true := by
  decide +kernel

private theorem cell856 : checkCoreCellRange 856 1 = true := by
  decide +kernel

private theorem cell857 : checkCoreCellRange 857 1 = true := by
  decide +kernel

private theorem cell858 : checkCoreCellRange 858 1 = true := by
  decide +kernel

private theorem cell859 : checkCoreCellRange 859 1 = true := by
  decide +kernel

private theorem cell860 : checkCoreCellRange 860 1 = true := by
  decide +kernel

private theorem cell861 : checkCoreCellRange 861 1 = true := by
  decide +kernel

private theorem cell862 : checkCoreCellRange 862 1 = true := by
  decide +kernel

private theorem cell863 : checkCoreCellRange 863 1 = true := by
  decide +kernel

theorem block53 : checkCoreCellRange 848 16 = true :=
  checkCoreCellRange_succ 848 15 (checkCoreCellRange_succ 848 14 (checkCoreCellRange_succ 848 13 (checkCoreCellRange_succ 848 12 (checkCoreCellRange_succ 848 11 (checkCoreCellRange_succ 848 10 (checkCoreCellRange_succ 848 9 (checkCoreCellRange_succ 848 8 (checkCoreCellRange_succ 848 7 (checkCoreCellRange_succ 848 6 (checkCoreCellRange_succ 848 5 (checkCoreCellRange_succ 848 4 (checkCoreCellRange_succ 848 3 (checkCoreCellRange_succ 848 2 (checkCoreCellRange_succ 848 1 (checkCoreCellRange_succ 848 0 rfl cell848) cell849) cell850) cell851) cell852) cell853) cell854) cell855) cell856) cell857) cell858) cell859) cell860) cell861) cell862) cell863

#print axioms block53

end QuarticKernel.KernelCells
