import QuarticCellChecker

namespace QuarticKernel.KernelCells

set_option maxRecDepth 18000
set_option maxHeartbeats 4000000

private theorem cell192 : checkCoreCellRange 192 1 = true := by
  decide +kernel

private theorem cell193 : checkCoreCellRange 193 1 = true := by
  decide +kernel

private theorem cell194 : checkCoreCellRange 194 1 = true := by
  decide +kernel

private theorem cell195 : checkCoreCellRange 195 1 = true := by
  decide +kernel

private theorem cell196 : checkCoreCellRange 196 1 = true := by
  decide +kernel

private theorem cell197 : checkCoreCellRange 197 1 = true := by
  decide +kernel

private theorem cell198 : checkCoreCellRange 198 1 = true := by
  decide +kernel

private theorem cell199 : checkCoreCellRange 199 1 = true := by
  decide +kernel

private theorem cell200 : checkCoreCellRange 200 1 = true := by
  decide +kernel

private theorem cell201 : checkCoreCellRange 201 1 = true := by
  decide +kernel

private theorem cell202 : checkCoreCellRange 202 1 = true := by
  decide +kernel

private theorem cell203 : checkCoreCellRange 203 1 = true := by
  decide +kernel

private theorem cell204 : checkCoreCellRange 204 1 = true := by
  decide +kernel

private theorem cell205 : checkCoreCellRange 205 1 = true := by
  decide +kernel

private theorem cell206 : checkCoreCellRange 206 1 = true := by
  decide +kernel

private theorem cell207 : checkCoreCellRange 207 1 = true := by
  decide +kernel

theorem block12 : checkCoreCellRange 192 16 = true :=
  checkCoreCellRange_succ 192 15 (checkCoreCellRange_succ 192 14 (checkCoreCellRange_succ 192 13 (checkCoreCellRange_succ 192 12 (checkCoreCellRange_succ 192 11 (checkCoreCellRange_succ 192 10 (checkCoreCellRange_succ 192 9 (checkCoreCellRange_succ 192 8 (checkCoreCellRange_succ 192 7 (checkCoreCellRange_succ 192 6 (checkCoreCellRange_succ 192 5 (checkCoreCellRange_succ 192 4 (checkCoreCellRange_succ 192 3 (checkCoreCellRange_succ 192 2 (checkCoreCellRange_succ 192 1 (checkCoreCellRange_succ 192 0 rfl cell192) cell193) cell194) cell195) cell196) cell197) cell198) cell199) cell200) cell201) cell202) cell203) cell204) cell205) cell206) cell207

#print axioms block12

end QuarticKernel.KernelCells
