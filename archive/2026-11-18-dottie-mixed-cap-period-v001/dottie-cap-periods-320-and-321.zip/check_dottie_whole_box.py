"""Whole-rectangle tangent lifts of the two periodic Phase 3K orbits.

python check_dottie_whole_box.py PATH_TO_PHASE3K PATH_TO_PROTOCOL_JSON
Use python-flint 0.9.0 and assertions. The imported published runner is hash-checked.
"""
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

from flint import acb, arb, ctx


def load_runner(path):
    expected = "5294403f7dd3fe3e1cba73e0bd99de2feb2cd782217513bff5bf61176026a3a3"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    spec = importlib.util.spec_from_file_location("phase3k", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lift_on_disk(runner, rate, center, radius):
    # Derivative of g_R(z) = exp(R exp(-R z)) at each step.
    # The chosen additive logs of the constant factors are principal.
    total = runner.SCALAR_PERIOD * (rate.log() + (-rate).log())
    for _ in range(runner.SCALAR_PERIOD):
        error = arb(0, radius.upper())
        disk_enclosure = center + acb(error, error)
        inner_log = -rate * disk_enclosure
        total += inner_log + rate * inner_log.exp()
        center, radius, _ = runner.disk_step(rate, center, radius)
    return total.imag / arb.pi()


def run(directory, protocol):
    runner = load_runner(directory / "certify_directed_continuation.py")
    data = protocol.read_bytes()
    assert hashlib.sha256(data).hexdigest() == "26007a2e0f65a12abd39485347976dfb28c018c4736a659500d0d7fa0672183f"
    plan = json.loads(data)
    for bits in (768, 1024):
        ctx.prec = bits
        record = runner.certify_continuation_case("off_axis_side")
        old = json.loads((directory / f"directed_continuation_{bits}.json").read_bytes())
        assert record["all_gates_pass"] and record == old["continuation"]["off_axis_side"]
        axes = record["exact_parameter_domain"]
        def interior(value, axis):
            return Fraction(axes[axis]["lower"]) < value < Fraction(axes[axis]["upper"])
        assert interior(Fraction(plan["y"]), "imag")
        assert len(plan["witnesses"]) == 32
        assert all(interior(-Fraction(row["x"]), "real") for row in plan["witnesses"])
        parameter = runner.parameter_box(runner.SIDE_POINT_PARAMETER,
                                         runner.SIDE_BOX_REAL_HALFWIDTH,
                                         runner.SIDE_BOX_IMAG_HALFWIDTH)
        radius = runner.exact_arb(runner.SIDE_CONTINUATION_DISK_RADIUS)
        p_center = runner.point(runner.SIDE_POINT_UPPER)
        q_center = runner.point(runner.SIDE_POINT_LOWER)
        cap_distance = abs(1 - q_center)
        assert cap_distance < runner.exact_arb("0.009218") < radius
        # The first half-step sends the full P trap into the Q trap.
        half_value = (-parameter * p_center).exp()
        half_diameter_bound = abs(half_value) * (abs(parameter) * radius).expm1()
        assert abs(half_value - q_center) + half_diameter_bound < runner.exact_arb("0.005111") < radius
        print(bits, "Q cap distance:", cap_distance.str(28))
        for name, rate, center, lo, hi in (
                ("P", parameter, p_center, "1.438", "1.750"),
                ("Q", -parameter, q_center, "1.349", "1.839")):
            ratio = lift_on_disk(runner, rate, center, radius)
            assert 1 < runner.exact_arb(lo) < ratio < runner.exact_arb(hi) < 3
            print(bits, name, "Im(lift)/pi enclosed by", lo, hi, "hence winding +1")


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    run(Path(sys.argv[1]), Path(sys.argv[2]))
