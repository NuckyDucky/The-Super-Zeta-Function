"""Post-audit cap capture on the negative flank of the Phase 3K box.

Run with python-flint 0.9.0 and assertions enabled:
  python check_dottie_cap_321.py PHASE3K_DIRECTORY PROTOCOL_JSON [--output FILE]
Keep check_dottie_whole_box.py alongside this file for its hash-checked loader.
Only the 14 previously unresolved offsets are tested. Orbit time means scalar
iterations of g_L(z)=exp(L exp(-Lz)). The published prediction scores are fixed.

For |z-1| <= 2R, R=10^-300, propagate directed disks to z_319 and enclose
b=L exp(-L z_319). Then z_320=exp(b) and
Re(-L z_320)=exp(Re b) Re(-L exp(i Im b)). A sufficiently negative real
part proves a strict return near 1 at step 321. The Cauchy estimate on a
circle of radius R bounds the derivative on |z-1| <= R. Disjointness from
the cap disk at times 3 and 107 excludes every proper divisor of 321.
"""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import time

import flint
from flint import acb, arb, ctx, fmpq

from check_dottie_whole_box import load_runner


UNRESOLVED = (4, 5, 6, 11, 12, 13, 18, 19, 20, 21, 25, 26, 27, 28)
PROTOCOL_SHA = "26007a2e0f65a12abd39485347976dfb28c018c4736a659500d0d7fa0672183f"


def inspect_cap(runner, rate, radius):
    assert abs(rate) < 1
    center, error = acb(1), 2 * radius
    gaps = {}
    for step in range(1, 320):
        center, error, _ = runner.disk_step(rate, center, error)
        if step in (3, 107):
            # Measures the distance from the full enclosing disk to D(1,R).
            gap = (abs(center - 1) - error - radius).lower()
            assert gap > runner.exact_arb("0.939")
            gaps[str(step)] = gap.str(24)

    inner = (-rate * center).exp()
    b_error = (abs(rate) * abs(inner) * (abs(rate) * error).expm1()).upper()
    b = rate * inner + acb(arb(0, b_error), arb(0, b_error))
    d = (-rate * acb(b.imag.cos(), b.imag.sin())).real
    assert b.real > runner.exact_arb("1e177")
    threshold = runner.exact_arb("0.01")
    if d < -threshold:
        outcome = "captured at primitive scalar period 321"
        # Upper bound on Re(-L z_320) follows by monotonicity and Re b > 12.
        assert threshold * arb(12).exp() > 1000
    elif d > threshold:
        outcome = "positive direction at step 320; capture unresolved"
    else:
        raise ArithmeticError("The interval does not resolve the direction.")
    return {
        "outcome": outcome,
        "log_abs_at_320": b.real.str(24),
        "direction_at_320": d.str(24),
        "proper_divisor_gap_lower": gaps,
    }


def run(directory, protocol):
    data = protocol.read_bytes()
    assert hashlib.sha256(data).hexdigest() == PROTOCOL_SHA
    plan = json.loads(data)
    xs = {row["j"]: Fraction(row["x"]) for row in plan["witnesses"]}
    runner = load_runner(directory / "certify_directed_continuation.py")
    passes = []
    for bits in (1024, 2048):
        start = time.perf_counter()
        ctx.prec = bits
        radius = runner.exact_arb("1e-300")
        # |exp(w)-1| <= exp(|w|)-1, using |L|<1 and |exp(-L z_320)|<exp(-1000).
        return_bound = (-arb(1000)).exp().expm1().upper()
        assert return_bound < radius / 4
        height = runner.exact_arb(plan["y"])
        cap_distance = abs(1 - runner.point(runner.SIDE_POINT_LOWER))
        assert cap_distance < runner.exact_arb("0.009218") < runner.exact_arb(
            runner.SIDE_CONTINUATION_DISK_RADIUS
        )
        cases = []
        for j in UNRESOLVED:
            x = xs[j]
            rate = acb(-arb(fmpq(x.numerator, x.denominator)), height)
            cases.append({"j": j, **inspect_cap(runner, rate, radius)})
        captured = [row["j"] for row in cases if row["outcome"].startswith("captured")]
        assert captured == [4, 6, 12, 13, 19, 28]
        passes.append({
            "precision_bits": bits,
            "elapsed_seconds": round(time.perf_counter() - start, 4),
            "negative_flank_P_primitive_321": captured,
            "negative_flank_Q_cap_distance_to_uniform_320_trap_center": cap_distance.str(24),
            "return_radius_upper_for_captured_P": return_bound.str(24),
            "cauchy_derivative_upper_on_inner_cap_disk": (return_bound / radius).upper().str(24),
            "cases": cases,
        })
    return {
        "protocol_sha256": PROTOCOL_SHA,
        "python_flint": flint.__version__,
        "flint": flint.__FLINT_VERSION__,
        "cap": "1",
        "inner_disk_radius": "1e-300",
        "outer_disk_radius": "2e-300",
        "checks": passes,
    }


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase3k_directory", type=Path)
    parser.add_argument("protocol", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.phase3k_directory, args.protocol)
    payload = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(payload, encoding="utf-8")
    else:
        print(payload, end="")
