"""Independent rectangular-ball check of the six period-321 cap traps.

Usage: python check_cap_321_rectangles.py PATH_TO_PROTOCOL_JSON
Uses whole starting disks and exact rational parameters. No Riemann zeta evaluations.
"""
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import sys

from flint import acb, arb, ctx, fmpq


def exact(text):
    r = Fraction(text)
    return arb(fmpq(r.numerator, r.denominator))


def cap_return(parameter, radius):
    # The square covers the doubled disk; the full images through step 319
    # are propagated by rectangular arithmetic, with no midpoint recentering.
    error = arb(0, (2 * radius).upper())
    z = acb(1) + acb(error, error)
    for step in range(1, 320):
        z = (parameter * (-parameter * z).exp()).exp()
        if step in (3, 107):
            assert abs(z - 1) > exact("0.939")
    b = parameter * (-parameter * z).exp()
    # z_320 = exp(b), Re(-L*z_320) = exp(Re b) * direction.
    direction = -parameter.real * b.imag.cos() + parameter.imag * b.imag.sin()
    assert b.real > exact("1e177")
    if direction < exact("-0.01"):
        assert b.real > 20 and arb(20).exp() / 100 > 2000
        assert abs(parameter) < 1
        # Re(-L*z_320) < -2000, hence |z_321-1| < exp(exp(-2000))-1.
        assert (-arb(2000)).exp().expm1() < radius / 4
        return True
    assert direction > exact("0.01")
    return False


def check(path):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == "26007a2e0f65a12abd39485347976dfb28c018c4736a659500d0d7fa0672183f"
    plan = json.loads(raw)
    unresolved = {4, 5, 6, 11, 12, 13, 18, 19, 20, 21, 25, 26, 27, 28}
    for bits in (2048, 3072):
        ctx.prec = bits
        successes = []
        for row in plan["witnesses"]:
            if row["j"] in unresolved:
                parameter = acb(-exact(row["x"]), exact(plan["y"]))
                if cap_return(parameter, exact("1e-500")):
                    successes.append(row["j"])
        assert successes == [4, 6, 12, 13, 19, 28]
        print(bits, "bits; primitive period 321 in negative-flank P:", successes)


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    check(Path(sys.argv[1]))
