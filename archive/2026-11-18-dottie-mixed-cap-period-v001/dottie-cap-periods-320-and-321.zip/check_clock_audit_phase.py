"""Check the 32-input audit from the public Super Zeta repository.

Run with python-flint 0.9.0: python check_clock_audit_phase.py PATH_TO_REPO
Reads the archived zero indices. Computes fresh log-gamma enclosures, no zero searches.
"""
import hashlib
import json
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

from flint import acb, arb, ctx, fmpq


def exact(text):
    value = Fraction(text)
    return arb(fmpq(value.numerator, value.denominator))


def rank_tail(groups, threshold):
    coeffs = [1]
    for _ in range(groups):
        layer = [0] * (len(coeffs) + 2)
        for k, value in enumerate(coeffs):
            for rank in (0, 1, 2):
                layer[k + rank] += value
        coeffs = layer
    return Fraction(sum(coeffs[threshold:]), 3 ** groups)


def theta(height):
    return acb(arb(1) / 4, height / 2).lgamma().imag - height * arb.pi().log() / 2


def load_json(path, expected):
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    return json.loads(data)


def check(repo):
    ctx.prec = 256
    root = repo / "archive"
    scores = root / "2026-11-18-clock-proximity-results-v001"
    plan_file = root / "2026-11-18-clock-local-controls-protocol-v001/protocol.json"
    plan = load_json(plan_file, "26007a2e0f65a12abd39485347976dfb28c018c4736a659500d0d7fa0672183f")
    results = load_json(scores / "results.json", "440c9f511af40ebbcfa5f49b3c6521bd264189bd0382d177a27438fd89a043f0")
    orbits = load_json(scores / "orbits.json", results["orbits_sha256"])
    histogram = Counter()
    vote_pairs = Counter()
    unresolved = []
    increments = []
    phases = set()
    print("Illustrative independent rank model:", rank_tail(18, 20), rank_tail(32, 33))
    for plan_row, result, orbit in zip(plan["witnesses"], results["rows"], orbits["rows"], strict=True):
        j = plan_row["j"]
        assert j == result["j"] == orbit["j"]
        if orbit["status"] != "certified":
            assert result["votes"] == ["unresolved", "unresolved"]
            unresolved.append(j)
            continue
        marks = tuple((mark["side"], mark["phase"], mark["k"]) for mark in orbit["marks"])
        phases.add(marks)
        vote_pairs[tuple(result["votes"])] += 1
        x, y = exact(plan_row["x"]), exact(plan["y"])
        height = arb.pi() / (80 * ((x / y) ** 2).log1p())
        step = 8 * arb.pi() / (height / (2 * arb.pi())).log()
        heights = (height - step, height, height + step)
        locations = [result["locations"][name] for name in ("left", "clock", "right")]
        assert all(h.overlaps(arb(loc["center"])) for h, loc in zip(heights, locations))
        angles = [theta(h) for h in heights]
        counts = []
        for i in (0, 1):
            residual = angles[i+1] - angles[i] - 4 * arb.pi()
            assert abs(residual) < exact("4.8e-14")
            increments.append(residual)
            counts.append(locations[i+1]["N"] - locations[i]["N"])
        histogram.update(counts)
        if j in (17, 23):
            print(j, counts, result["votes"], [loc["distance"] for loc in locations])
    assert len(increments) == 36 and len(phases) == 1
    print("Triplet votes:", vote_pairs, "unresolved inputs:", unresolved)
    print("Windings (side, phase, k):", phases.pop())
    print("Archived zero counts between neighboring centers:", dict(sorted(histogram.items())))
    largest = max((abs(value).upper() for value in increments), key=float)
    print("Largest bound on absolute theta residual (radians):", largest.str(25))


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    check(Path(sys.argv[1]))
