#!/usr/bin/env python3
"""Independent directed continuation certificates for the Phase 3K cycles.

The decimal inputs below are copied literally from the Phase 3K candidate
records.  No candidate code or result file is imported.  All decimal values
are parsed as exact rationals, and all transcendental work is performed with
outward-rounded Arb/ACB arithmetic.

There are two layers:

1. Recompute the radius-1e-100 point trapping disks and primitive-period
   exclusions at the two exact candidate parameters.
2. Enclose the same scalar return cycles uniformly on one real-y interval and
   one genuinely two-dimensional complex-L box.

The proof concerns local attracting periodic orbits only.  Cap marking,
component topology, and center/minimizer status are deliberately excluded.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
VENDOR = ROOT / "work" / "phase3c_phys_even_agent" / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

import flint  # noqa: E402
from flint import acb, arb, ctx, fmpq  # noqa: E402


SCALAR_PERIOD = 320
PAIRED_PERIOD = 640
PROPER_DIVISORS = [
    divisor
    for divisor in range(1, SCALAR_PERIOD)
    if SCALAR_PERIOD % divisor == 0
]

# Exact point inputs from Phase 3K.  They are inputs to this independent
# checker, not imported assertions.
REAL_POINT_PARAMETER = {"real": "0", "imag": "0.5098930233215867"}
REAL_POINT_UPPER = {
    "real": (
        "0.9999996034350764449934984731487192190650492742771112156224878231833240620969743881749190567758854070263828923298486599100034104044"
    ),
    "imag": (
        "-0.0000001191519344021400351588601191161565614732733443814413725778806332475534499140895987336122841516489922291358046225827550586563764468"
    ),
}

SIDE_POINT_PARAMETER = {
    "real": "-0.00000004749479070945369",
    "imag": "0.509892982511772",
}
SIDE_POINT_UPPER = {
    "real": (
        "0.01806608806132350122964050606781642623651203527510126829664988070350433037612272322735592991559679110343928762047679748231979437851"
    ),
    "imag": (
        "-0.0007177231495822915491777663873588290392930970577224765092716366018790182410876642705838430564295807363338521166682360253151650926925"
    ),
}
SIDE_POINT_LOWER = {
    "real": (
        "0.9995916932728882721152642574456856655322386151180761940248424659865711774918076100814854432519877487642001474163848785720621106885"
    ),
    "imag": (
        "-0.009208270792439933288772854645973093572916297958550958763264130738517635842519147922444510756987008331168763294194678463746690491233"
    ),
}

POINT_RADIUS = "1e-100"

# Uniform continuation domains.  These are exact rational boxes.
REAL_Y_HALFWIDTH = "4e-10"
REAL_CONTINUATION_DISK_RADIUS = "7e-4"
SIDE_BOX_REAL_HALFWIDTH = "3e-10"
SIDE_BOX_IMAG_HALFWIDTH = "3e-10"
SIDE_CONTINUATION_DISK_RADIUS = "1e-2"


def decimal_q(text: str) -> fmpq:
    """Parse a finite decimal/scientific string as an exact rational."""

    match = re.fullmatch(
        r"([+-]?)(\d+)(?:\.(\d*))?(?:[eE]([+-]?\d+))?", text
    )
    if match is None:
        raise ValueError(f"not an exact finite decimal: {text}")
    sign, whole, fraction, exponent = match.groups()
    fraction = fraction or ""
    numerator = int(whole + fraction)
    if sign == "-":
        numerator = -numerator
    scale = len(fraction) - int(exponent or "0")
    if scale >= 0:
        return fmpq(numerator, 10**scale)
    return fmpq(numerator * 10 ** (-scale), 1)


def exact_arb(text: str) -> arb:
    return arb(decimal_q(text))


def point(record: dict[str, str]) -> acb:
    return acb(exact_arb(record["real"]), exact_arb(record["imag"]))


def parameter_box(
    center: dict[str, str], real_halfwidth: str, imag_halfwidth: str
) -> acb:
    return acb(
        arb(decimal_q(center["real"]), decimal_q(real_halfwidth)),
        arb(decimal_q(center["imag"]), decimal_q(imag_halfwidth)),
    )


def lower(value: arb, digits: int = 120) -> str:
    return value.lower().str(digits, radius=False)


def upper(value: arb, digits: int = 120) -> str:
    return value.upper().str(digits, radius=False)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def disk_step(
    parameter: acb, center: acb, radius: arb
) -> tuple[acb, arb, arb]:
    """Enclose g_L(D(center,radius)) by a new Euclidean disk.

    For g_L(z) = exp(L exp(-L z)), write u_c = exp(-L c).  Uniformly for
    |z-c| <= r,

      |exp(-Lz) - u_c| <= |u_c| (exp(|L|r) - 1),

    and

      |g'_L(z)| <= |L|^2 exp(Re(-Lc)+|L|r)
                         exp(Re(Lu_c)+|L| |u-u_c|).

    The ACB balls in the center calculation also enclose parameter-box and
    rounding uncertainty.  The returned radius adds that center uncertainty
    to the mean-value derivative majorant.
    """

    abs_parameter = abs(parameter).upper()

    inner_argument = -parameter * center
    inner_center = inner_argument.exp()
    inner_sup = (inner_argument.real.upper() + abs_parameter * radius).exp().upper()
    inner_variation = (
        abs(inner_center).upper() * ((abs_parameter * radius).exp() - 1)
    ).upper()

    outer_argument = parameter * inner_center
    next_center_ball = outer_argument.exp()
    outer_sup = (
        outer_argument.real.upper() + abs_parameter * inner_variation
    ).exp().upper()
    derivative_sup = (abs_parameter**2 * inner_sup * outer_sup).upper()

    next_center = next_center_ball.mid()
    next_radius = (
        derivative_sup * radius + next_center_ball.rad().upper()
    ).upper()
    return next_center, next_radius, derivative_sup


def native_sample_crosscheck(
    parameter: acb,
    center: acb,
    radius: arb,
    next_center: acb,
    next_radius: arb,
) -> bool:
    """Diagnostic native-ACB checks at eight exact points in the disk.

    Cardinal boundary points and four diagonal interior points are evaluated
    without the analytic majorant.  This does not replace the all-disk proof;
    it is an independent implementation check for sign/order/rounding errors.
    Comparing a whole native ACB square would be invalid as a cross-check here:
    two correct interval supersets need not contain one another.
    """

    half = radius / 2
    offsets = [
        acb(radius, 0),
        acb(-radius, 0),
        acb(0, radius),
        acb(0, -radius),
        acb(half, half),
        acb(half, -half),
        acb(-half, half),
        acb(-half, -half),
    ]
    for offset in offsets:
        sample = center.mid() + offset
        native_image = (parameter * ((-parameter * sample).exp())).exp()
        if not abs(native_image - next_center).upper() <= next_radius.upper():
            return False
    return True


def propagate(
    parameter: acb,
    start_center: acb,
    start_radius: arb,
    native_crosscheck: bool,
) -> dict:
    centers = [start_center]
    radii = [start_radius]
    derivative_product = arb(1)
    maximum_radius = start_radius
    maximum_radius_index = 0
    crosschecks = []

    center = start_center
    radius = start_radius
    for index in range(1, SCALAR_PERIOD + 1):
        next_center, next_radius, derivative_sup = disk_step(
            parameter, center, radius
        )
        if native_crosscheck:
            crosschecks.append(
                native_sample_crosscheck(
                    parameter,
                    center,
                    radius,
                    next_center,
                    next_radius,
                )
            )
        derivative_product = (derivative_product * derivative_sup).upper()
        center, radius = next_center, next_radius
        centers.append(center)
        radii.append(radius)
        if radius > maximum_radius:
            maximum_radius = radius
            maximum_radius_index = index

    return {
        "centers": centers,
        "radii": radii,
        "return_derivative": derivative_product,
        "maximum_radius": maximum_radius,
        "maximum_radius_index": maximum_radius_index,
        "native_subset_crosschecks": crosschecks,
    }


def certify_channel(
    parameter: acb,
    start_center: acb,
    start_radius: arb,
    native_crosscheck: bool = False,
) -> dict:
    orbit = propagate(
        parameter,
        start_center,
        start_radius,
        native_crosscheck=native_crosscheck,
    )
    returned_center = orbit["centers"][-1]
    returned_radius = orbit["radii"][-1]
    return_lhs = (
        abs(returned_center - start_center).upper() + returned_radius
    ).upper()
    inclusion_slack = (start_radius.lower() - return_lhs).lower()

    divisor_rows = []
    for divisor in PROPER_DIVISORS:
        divisor_margin = (
            abs(orbit["centers"][divisor] - start_center).lower()
            - orbit["radii"][divisor].upper()
            - start_radius.upper()
        ).lower()
        divisor_rows.append(
            {
                "divisor": divisor,
                "disjointness_margin_lower": lower(divisor_margin),
                "excluded": bool(divisor_margin > 0),
            }
        )

    derivative_upper = orbit["return_derivative"].upper()
    native_checks = orbit["native_subset_crosschecks"]
    gates = {
        "return_disk_strictly_invariant": bool(inclusion_slack > 0),
        "return_derivative_strictly_below_one": bool(derivative_upper < 1),
        "all_proper_divisors_excluded": all(
            row["excluded"] for row in divisor_rows
        ),
        "native_eight_point_crosscheck_all_steps": (
            all(native_checks) if native_crosscheck else True
        ),
    }
    return {
        "starting_radius": upper(start_radius),
        "return_lhs_upper": upper(return_lhs),
        "inclusion_slack_lower": lower(inclusion_slack),
        "return_radius_upper": upper(returned_radius),
        "maximum_intermediate_radius_upper": upper(orbit["maximum_radius"]),
        "maximum_intermediate_radius_index": orbit["maximum_radius_index"],
        "return_derivative_upper": upper(derivative_upper),
        "proper_divisor_exclusions": divisor_rows,
        "native_eight_point_crosscheck_step_count": len(native_checks),
        "proof_gates": gates,
        "all_gates_pass": all(gates.values()),
    }


def paired_period_logic() -> dict:
    divisors_640 = [
        value for value in range(1, PAIRED_PERIOD + 1) if PAIRED_PERIOD % value == 0
    ]
    candidates = [
        value
        for value in divisors_640
        if value // math.gcd(value, 2) == SCALAR_PERIOD
    ]
    return {
        "identity": "F_L^2=(g_L,g_-L), hence F_L^640=(g_L^320,g_-L^320)",
        "primitive_period_equation": "r/gcd(r,2)=320 with r dividing 640",
        "enumerated_candidates": candidates,
        "unique_candidate_is_640": candidates == [640],
    }


def pair_certificate(upper_channel: dict, lower_channel: dict) -> dict:
    logic = paired_period_logic()
    gates = {
        "both_scalar_return_disks_strictly_invariant": (
            upper_channel["proof_gates"]["return_disk_strictly_invariant"]
            and lower_channel["proof_gates"]["return_disk_strictly_invariant"]
        ),
        "both_scalar_returns_contract": (
            upper_channel["proof_gates"]["return_derivative_strictly_below_one"]
            and lower_channel["proof_gates"]["return_derivative_strictly_below_one"]
        ),
        "both_scalar_cycles_have_primitive_period_320": (
            upper_channel["proof_gates"]["all_proper_divisors_excluded"]
            and lower_channel["proof_gates"]["all_proper_divisors_excluded"]
        ),
        "paired_period_enumeration_has_unique_value_640": logic[
            "unique_candidate_is_640"
        ],
    }
    return {
        "logic": logic,
        "proof_gates": gates,
        "all_gates_pass": all(gates.values()),
    }


def conjugate_real_upper() -> acb:
    return acb(exact_arb(REAL_POINT_UPPER["real"]), -exact_arb(REAL_POINT_UPPER["imag"]))


def certify_point_case(case_name: str) -> dict:
    radius = exact_arb(POINT_RADIUS)
    if case_name == "real_secondary":
        parameter = point(REAL_POINT_PARAMETER)
        upper_center = point(REAL_POINT_UPPER)
        lower_center = conjugate_real_upper()
    elif case_name == "off_axis_side":
        parameter = point(SIDE_POINT_PARAMETER)
        upper_center = point(SIDE_POINT_UPPER)
        lower_center = point(SIDE_POINT_LOWER)
    else:
        raise ValueError(case_name)

    upper_channel = certify_channel(
        parameter, upper_center, radius, native_crosscheck=True
    )
    lower_channel = certify_channel(
        -parameter, lower_center, radius, native_crosscheck=True
    )
    pair = pair_certificate(upper_channel, lower_channel)
    gates = {
        "upper_channel_passes": upper_channel["all_gates_pass"],
        "lower_channel_passes": lower_channel["all_gates_pass"],
        "paired_inference_passes": pair["all_gates_pass"],
    }
    return {
        "case": case_name,
        "exact_parameter": (
            REAL_POINT_PARAMETER if case_name == "real_secondary" else SIDE_POINT_PARAMETER
        ),
        "exact_input_radius": POINT_RADIUS,
        "upper": upper_channel,
        "lower": lower_channel,
        "pair_certificate": pair,
        "proof_gates": gates,
        "all_gates_pass": all(gates.values()),
    }


def certify_continuation_case(case_name: str) -> dict:
    if case_name == "real_secondary":
        parameter = parameter_box(
            REAL_POINT_PARAMETER, "0", REAL_Y_HALFWIDTH
        )
        upper_center = point(REAL_POINT_UPPER)
        lower_center = conjugate_real_upper()
        radius = exact_arb(REAL_CONTINUATION_DISK_RADIUS)
        domain = {
            "real": {"center": "0", "halfwidth": "0"},
            "imag": {
                "center": REAL_POINT_PARAMETER["imag"],
                "halfwidth": REAL_Y_HALFWIDTH,
                "lower": "0.5098930229215867",
                "upper": "0.5098930237215867",
            },
            "dimension": 1,
        }
        radius_text = REAL_CONTINUATION_DISK_RADIUS
    elif case_name == "off_axis_side":
        parameter = parameter_box(
            SIDE_POINT_PARAMETER,
            SIDE_BOX_REAL_HALFWIDTH,
            SIDE_BOX_IMAG_HALFWIDTH,
        )
        upper_center = point(SIDE_POINT_UPPER)
        lower_center = point(SIDE_POINT_LOWER)
        radius = exact_arb(SIDE_CONTINUATION_DISK_RADIUS)
        domain = {
            "real": {
                "center": SIDE_POINT_PARAMETER["real"],
                "halfwidth": SIDE_BOX_REAL_HALFWIDTH,
                "lower": "-0.00000004779479070945369",
                "upper": "-0.00000004719479070945369",
            },
            "imag": {
                "center": SIDE_POINT_PARAMETER["imag"],
                "halfwidth": SIDE_BOX_IMAG_HALFWIDTH,
                "lower": "0.509892982211772",
                "upper": "0.509892982811772",
            },
            "dimension": 2,
        }
        radius_text = SIDE_CONTINUATION_DISK_RADIUS
    else:
        raise ValueError(case_name)

    upper_channel = certify_channel(parameter, upper_center, radius)
    lower_channel = certify_channel(-parameter, lower_center, radius)
    pair = pair_certificate(upper_channel, lower_channel)
    point_radius = decimal_q(POINT_RADIUS)
    continuation_radius = decimal_q(radius_text)
    gates = {
        "parameter_domain_is_nonzero": (
            decimal_q(domain["real"]["halfwidth"]) > 0
            or decimal_q(domain["imag"]["halfwidth"]) > 0
        ),
        "requested_parameter_dimension": (
            domain["dimension"] == (1 if case_name == "real_secondary" else 2)
        ),
        "original_point_disk_is_strictly_contained": continuation_radius > point_radius,
        "upper_uniform_channel_passes": upper_channel["all_gates_pass"],
        "lower_uniform_channel_passes": lower_channel["all_gates_pass"],
        "uniform_paired_period_inference_passes": pair["all_gates_pass"],
    }
    return {
        "case": case_name,
        "exact_parameter_domain": domain,
        "common_starting_disk_radius": radius_text,
        "anchor_statement": (
            "At the box center, the radius-1e-100 certified point disk lies "
            "strictly inside this common disk. Uniform contraction makes the "
            "box family the unique continuation of that anchored cycle inside "
            "the common disk."
        ),
        "upper": upper_channel,
        "lower": lower_channel,
        "pair_certificate": pair,
        "proof_gates": gates,
        "all_gates_pass": all(gates.values()),
    }


def build(bits: int) -> dict:
    ctx.prec = bits
    print(f"[{bits} bits] red-team point disks: real secondary", flush=True)
    real_point = certify_point_case("real_secondary")
    print(f"[{bits} bits] red-team point disks: off-axis side", flush=True)
    side_point = certify_point_case("off_axis_side")
    print(f"[{bits} bits] interval continuation: real y", flush=True)
    real_continuation = certify_continuation_case("real_secondary")
    print(f"[{bits} bits] interval continuation: complex L box", flush=True)
    side_continuation = certify_continuation_case("off_axis_side")

    gates = {
        "real_point_red_team_passes": real_point["all_gates_pass"],
        "side_point_red_team_passes": side_point["all_gates_pass"],
        "real_interval_continuation_passes": real_continuation["all_gates_pass"],
        "side_2d_box_continuation_passes": side_continuation["all_gates_pass"],
    }
    return {
        "schema": "phase3k-independent-directed-continuation-v1",
        "status": "DIRECTED_INTERVAL_CERTIFICATE" if all(gates.values()) else "FAILED",
        "precision_bits": bits,
        "software": {
            "python_flint": flint.__version__,
            "flint": flint.__FLINT_VERSION__,
        },
        "map": {
            "scalar": "g_L(z)=exp(L exp(-L z))",
            "paired": "F_L(P,M)=(exp(LM),exp(-LP))",
            "identity": "F_L^2=(g_L,g_-L)",
        },
        "scalar_period": SCALAR_PERIOD,
        "paired_period": PAIRED_PERIOD,
        "point_red_team": {
            "real_secondary": real_point,
            "off_axis_side": side_point,
        },
        "continuation": {
            "real_secondary": real_continuation,
            "off_axis_side": side_continuation,
        },
        "proof_gates": gates,
        "all_gates_pass": all(gates.values()),
        "claim_boundary": (
            "For every L in the stated domains, this certifies one locally unique "
            "primitive attracting F_L-period-640 product orbit in the stated "
            "product disks, continuously anchored to the Phase 3K point orbit. "
            "It does not certify cap marking, access words, component topology, "
            "separation from other components outside the disks, or physical-"
            "center/multiplier-minimizer status."
        ),
        "source_sha256": sha256(Path(__file__).resolve()),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--precision", type=int, choices=[768, 1024], required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    result = build(args.precision)
    destination = args.output or HERE / f"directed_continuation_{args.precision}.json"
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"{'PASS' if result['all_gates_pass'] else 'FAIL'} {destination}")
    return 0 if result["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
