# Phase 3K independent directed continuation

## Outcome

The two Phase 3K radius-`1e-100` candidate certificates survive an independent
Arb/ACB replay at both 768 and 1024 bits.  The replay imports neither candidate
runner nor candidate result records; all finite decimals are copied literally
and parsed as exact rationals.

Both candidates also continue on explicit nonzero parameter domains:

| Family | Certified parameter domain | Common scalar disks | Worst return derivative | Smallest inclusion slack |
|---|---|---:|---:|---:|
| Real secondary cycle | `Re L = 0`, `Im L in [0.5098930229215867, 0.5098930237215867]` | radius `7e-4` in both channels | `0.059059329018164` | `0.00041813959038358` |
| Off-axis side cycle | `Re L in [-0.00000004779479070945369, -0.00000004719479070945369]`, `Im L in [0.509892982211772, 0.509892982811772]` | radius `1e-2` in both channels | `0.472385945224984` | `0.00205179572299798` |

Thus the first domain has full real-y width `8e-10`.  The second is a genuine
two-dimensional complex-`L` rectangle of width `6e-10` in each coordinate.

For every parameter in each domain, the scalar maps `g_L` and `g_-L` have a
unique attracting fixed point of their 320th iterates inside the stated disks.
All proper divisors of 320 are uniformly excluded.  Their product therefore
gives a primitive attracting `F_L`-period-640 orbit.  At each box center, the
original radius-`1e-100` disk lies strictly inside the continuation disk, so
uniform contraction anchors the family to the independently replayed Phase 3K
point orbit.

## Red-team findings

The one-step disk propagation is valid.  For

`g_L(z) = exp(L exp(-L z))`,

the runner bounds the inner exponential variation by

`|exp(-Lz)-exp(-Lc)| <= |exp(-Lc)|(exp(|L|r)-1)`

and then bounds `|g'_L|` on the full disk.  Parameter-box and floating-point
uncertainty are enclosed by native ACB balls; the next disk radius adds the
ACB center radius to the mean-value bound.  Recentring after every step is
essential.  A raw 320-fold interval expression suffers wrapping and is not a
valid substitute for the proved one-step enclosure chain.

As an implementation cross-check, every point certificate also evaluates eight
native ACB sample points per step (four cardinal boundary points and four
diagonal interior points).  All 320 steps pass in both scalar channels for both
candidates, at both precisions.  This sampling is diagnostic; the analytic
majorant is the all-disk proof.

The paired-period conclusion is correct, but the earlier shorthand based on
the *first coordinate alone* was too compressed.  A coordinate projection can
in general repeat earlier than the full pair.  The repaired argument is:

1. both scalar coordinates have primitive period 320 under `F_L^2`;
2. therefore the product point has primitive period 320 under `F_L^2`;
3. if its primitive `F_L` period is `r`, then
   `r/gcd(r,2) = 320`, with `r | 640`;
4. exact divisor enumeration leaves only `r = 640`.

No mathematical failure remains after that wording repair.

## Numerical margins

At the real continuation interval, both scalar channels have identical bounds:

- return-disk left side: `0.0002818604096164204` against radius `0.0007`;
- inclusion slack: `0.0004181395903835796`;
- return derivative: `< 0.05905932901816391`;
- smallest proper-divisor disjointness margin: `> 0.5732652237576518`.

At the off-axis two-dimensional box:

- upper-channel return left side: `< 0.007948204277002015`;
- lower-channel return left side: `< 0.007533551667093741`;
- worst inclusion slack: `> 0.002051795722997985`;
- worst return derivative: `< 0.4723859452249834`;
- smallest proper-divisor disjointness margin: `> 0.5550602134814476`.

The 768- and 1024-bit records agree in every serialized 120-digit theorem
bound.  The cold verifier passes 50 structural checks and 70 serialized proof
gates at each precision.

## Claim boundary

These are local continuation theorems for primitive attracting periodic orbits.
They do not certify cap capture/marking, access words, separation or topology of
the wider components, multiplier-minimizing center status, or membership in a
particular visible hyperzoom component.  Those require separate marked-orbit
and topology arguments.

## Reproducibility

- `certify_directed_continuation.py` SHA-256:
  `5294403f7dd3fe3e1cba73e0bd99de2feb2cd782217513bff5bf61176026a3a3`
- `verify_directed_continuation.py` SHA-256:
  `610ea075cc51ca68bb7f0116834c3697233cf7e4176036341754bcc665f684b0`
- 768-bit record SHA-256:
  `c03e7eb1ca1fc95cb178b30c921b769d8cb3c1c0cdd183e3c2154eda39aefca5`
- 1024-bit record SHA-256:
  `759b469acbf25a771cabbf09039e1715c1da866c9162a96dfc2e9a44fbcc7b4e`

Run:

```bash
python certify_directed_continuation.py --precision 768
python certify_directed_continuation.py --precision 1024
python verify_directed_continuation.py
```

